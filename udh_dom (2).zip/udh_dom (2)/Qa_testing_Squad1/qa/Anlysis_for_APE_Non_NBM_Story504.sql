-- Databricks notebook source
select * from dev_gold_intermediate.users_data_gold limit 10

-- COMMAND ----------

select * fwd_test_silver_intermediate.fwd_test_nbo_silver

-- COMMAND ----------

select * from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'payment'
