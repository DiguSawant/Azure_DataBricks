-- Databricks notebook source
select * from dev_vnb.vnb_channel_silver

-- COMMAND ----------

select * from dev_vnb.vnb_rates_silver