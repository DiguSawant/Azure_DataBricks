-- Databricks notebook source
desc table dev_silver_intermediate.users_data_silver

-- COMMAND ----------

--select * from silver_intermediate.users_data

--select *  from dev_silver_intermediate.users_data_silver limit 10

select distinct json_data_others_utmcontent  from dev_silver_intermediate.users_data_silver limit 10


-- COMMAND ----------

--Story 407 NBM Qoute

select after_product_type , count(*) from uat_silver_intermediate.users_data_silver

where  after_user_view = 'quote.quickQuestions' and after_status = 'proposal'
group by after_product_type


-- COMMAND ----------

--Story 408 NBM Health Questions

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.underwritingAnswer' and after_status = 'proposal'
group by after_product_type

-- COMMAND ----------

--Story 409 NBM Personal Info stage

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.personalDetail' and after_status = 'proposal'
group by after_product_type

-- COMMAND ----------

--story 410 summary
--USERS_VIEW → quote.proceedToPay ; STATUS → proposal

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.proceedToPay' and after_status = 'proposal'
group by after_product_type

-- COMMAND ----------

--story 411 payment stage

--USERS_VIEW → quote.payment ; STATUS → pending

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.payment' and after_status = 'pending'
group by after_product_type

-- COMMAND ----------


-- story 411 latest Query
select after_product_type, count(*) from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'pending'
group by after_product_type

-- COMMAND ----------

select product_type,sum(count),source_system  from dev_ainbo_silver.payment_silver where source_system = 'nbm' group by product_type ,source_system

--select * from ainbo_silver.payment where source_system = 'nbm' order by product_type

--select product_type,sum(count) from ainbo_silver.payment group by product_type

-- COMMAND ----------

--Story 412 sucess

--USERS_VIEW → quote.payment ; STATUS → payment

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.payment' and after_status = 'payment'
group by after_product_type

-- COMMAND ----------

--Story 412 sucess

--USERS_VIEW → quote.payment ; STATUS → payment
select after_product_type, count(*) from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'payment'
group by after_product_type

-- COMMAND ----------

select product_type,sum(count) from dev_ainbo_silver.success_silver group by product_type

-- COMMAND ----------

--story 411 payment stage

--USERS_VIEW → quote.payment ; STATUS → pending

select after_product_type , count(*) from dev_silver_intermediate.users_data_silver where  lower(after_user_view ) = 'quote.payment' and lower(after_status) = 'pending' group by after_product_type

-- COMMAND ----------

select product_type,sum(count) from dev_ainbo_silver.payment_silver group by product_type

-- COMMAND ----------

select product_type,sum(count) from ainbo_silver.success group by product_type

-- use this querry

-- COMMAND ----------

select * from ainbo_silver.success

-- COMMAND ----------



-- COMMAND ----------

 select * from dev_ainbo_silver.quote

-- COMMAND ----------

 select * from dev_ainbo_silver.health_question_silver
 
 

-- COMMAND ----------

 select * from ainbo_silver.personal_info

-- COMMAND ----------

select * from ainbo_silver.summary

-- COMMAND ----------

select * from ainbo_silver.payment


-- COMMAND ----------

select product_type,sum(count) from ainbo_silver.success group by product_type

--select * from ainbo_silver.success

-- COMMAND ----------

