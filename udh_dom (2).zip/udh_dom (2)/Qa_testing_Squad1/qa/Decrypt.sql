-- Databricks notebook source
-- MAGIC %run
-- MAGIC /Shared/udh_dom/tech_utility/aes

-- COMMAND ----------

select aes_decrypt('fPnuIwwmu+9bysV6kRf4JzL4hDNicgrCQ0sTOaApU6ZaE53PYhjeVwwdoiB8m3sdcoEn5qUo/GGqCOQo6LIP0/aInj6CPOD7HPmW2NnMFgU2l1vrnMTPrMRYVxKFTcHJzZKVRE3hwrhK78vsvPrlSn0GP3a94dZmcIYI46uNCBS+lgwYtQYeNrsFNn5sUAac3CO7ExpGFtOJaFG8lnYbTQRxDQ4po2orhwsVrtXYescuvZWplMBs9t7AjZMtp0K20m0Ue/t111OAAwbHief7dgeh5+Xy7xy38aSp4basuhaaku9J6YuBRtlMKzEkGsSg8pZkdRXyXQ6w+9YXfHkTbsJVt0lQk+mCowIjHS36ARvpuQHs0uatTvwiwW4VZuzrFy8fmmm8F8+bIlqxiSisuG56O86POv8pAxw4AELAsDp7nMwhwRYTv1f5OZzon9DeB8fZDrGQvIo7PpSTaoH8xSBrXLdro9xYDE+kvo4Yu+/8BuDYvuOX+FJLKCUtIjPqz82TmiQ+NzgPCUGbzhLtBbyAfy2QBBuEeK7VoP4EqEcSQJvBpTS1bVn+fbI0Curut73TFmo0sp8p1/LqR3dKF8neYDIsl7M05vrd8fsLR8V95tAqur/rvbGqm4PLt2K4ASoZFQO2qsA8iRdszAYY0LVijBRQtY0EuyHWeoWpGlmjGX8pcaGt22qe89qzVHlg2XJvZ0GkeJvIUPGUxxYLCtPI7ZbYwCkeWOMJ0M2oetps6uH6V+5cqkWySUfd8hscwExxQEy0AgrddkHlgF91g6d7WztMb7S6Qv01iZjFpMnGo7K4/C1FIYcaP7PPGtITWKBXRjSuvn7BWAAKRgMdLw==')as Decrypted_Value

-- COMMAND ----------

select aes_encrypt(370540) as json_data

-- COMMAND ----------

select count(1) from dev_silver_intermediate.nbo_silver 
--where ID = upper('003d8882-ac23-4b80-abb9-8214417580df')

-- COMMAND ----------

select INSIGHT_OCCUPATIONCODE from dev_silver_intermediate.nbo_silver 
where ID = upper('003d8882-ac23-4b80-abb9-8214417580df')

-- COMMAND ----------

select aes_decrypt('bVfUIU9LnKvLkQ0XYPxKdQ==')as Decrypted_Value