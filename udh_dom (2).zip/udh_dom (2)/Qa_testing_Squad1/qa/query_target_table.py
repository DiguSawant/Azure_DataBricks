# Databricks notebook source
import os
env = os.getenv("env").lower()
env = "dev"

# COMMAND ----------

# DBTITLE 1,fetch data from non-nbm dev_silver_intermediate.nosql_data_entity_silver table
spark.sql(f"""select * from {env}_silver_intermediate.nosql_data_entity_silver limit 10""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from nbm dev_silver_intermediate.users_data_silver table
spark.sql(f"""select * from {env}_silver_intermediate.users_data_silver limit 10""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from party table
spark.sql(f"""select * from {env}_party_silver.party_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from individual table
spark.sql(f"""select * from {env}_party_silver.individual_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from identity table
spark.sql(f"""select * from {env}_party_silver.identity_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from bank_account table
spark.sql(f"""select * from {env}_party_silver.bank_account_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from electronic_address table
spark.sql(f"""select * from {env}_party_silver.electronic_address_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from organisation table
spark.sql(f"""select * from {env}_party_silver.organisation_silver""").display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### AINBO Tables

# COMMAND ----------

# DBTITLE 1,fetch data from quote_silver table
spark.sql(f"""select * from {env}_ainbo_silver.quote_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from health_question table
spark.sql(f"""select * from {env}_ainbo_silver.health_question_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from personal_info_silver table
spark.sql(f"""select * from {env}_ainbo_silver.personal_info_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from summary_silver table
spark.sql(f"""select * from {env}_ainbo_silver.summary_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from payment_silver table
spark.sql(f"""select * from {env}_ainbo_silver.payment_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from success_silver table
spark.sql(f"""select * from {env}_ainbo_silver.success_silver""").display()

# COMMAND ----------

# DBTITLE 1,fetch data from product_lookup_silver table
spark.sql(f"""select * from {env}_ainbo_silver.product_lookup_silver""").display()

# COMMAND ----------

