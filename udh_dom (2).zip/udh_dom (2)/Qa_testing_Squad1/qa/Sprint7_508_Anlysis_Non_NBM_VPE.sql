-- Databricks notebook source
select * from dev_silver_intermediate.nosql_data_entity_silver
where DATAVALUE_PRODUCTID IS NOT NULL  and DATAVALUE_PRODUCTID = 'E60A1' 

-- COMMAND ----------

--Non NBM intermediate table
select ET_ENTITYSEQ, DATAVALUE_PRODUCTID,DATAVALUE_PREMIUMINFO_PAYMENTMODE,DATAVALUE_PREMIUMINFO_PREMIUM,datavalue_policyNumber,DATAVALUE_PAYMENTTYPE,DATAVALUE_ISPAYMENTCOMPLETE,UDH_INSERT_TIMESTAMP, DATAVALUE_UTMTRACKING_UTMCONTENT from dev_silver_intermediate.nosql_data_entity_silver
 where DATAVALUE_PRODUCTID IS NOT NULL  and DATAVALUE_PRODUCTID = 'E60A1'
      and datavalue_isPaymentComplete ='TRUE'

-- COMMAND ----------

select * from dev_vnb.vnb_rates_silver where product_id = 'E60A1'

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver where product_type ='E60A1'

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where product_id ='E60A1' and funnel_stage ='success'

-- COMMAND ----------

select Distinct Datavalue_partner from dev_silver_intermediate.nosql_data_entity_silver

-- COMMAND ----------

select Distinct Json_data_others_partnercode from dev_silver_intermediate.users_data_silver