-- Databricks notebook source
select * from dev_ainbo_silver.product_lookup_silver where source_system = 'nbm'

-- COMMAND ----------

--select Count(*) from dev_silver_intermediate.users_data_silver

select * from dev_silver_intermediate.users_data_silver

-- COMMAND ----------

select JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING
AFTER_PRODUCT_TYPE
json_data_others_utmcontent from dev_silver_intermediate.users_data_silver limit 5




-- COMMAND ----------

select * from dev_ainbo_silver.success_silver 
where product_type = '3CI'
--where product_type IN ('HA' ,'CI' ,'3CI','CI')

-- COMMAND ----------

select sum(CASE WHEN JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID >JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING THEN JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID *1

        WHEN JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID < JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING

        THEN JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID*12 else 0 END) from  dev_silver_intermediate.users_data_silver where JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID IS NOT NULL and AFTER_PRODUCT_TYPE='3CI' and json_data_others_utmcontent='XYZ';

-- COMMAND ----------

select AFTER_PRODUCT_TYPE, json_data_others_utmcontent, count(*) as Sucess_Cnt
from dev_silver_intermediate.users_data_silver
where 
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='3CI'
group by AFTER_PRODUCT_TYPE, json_data_others_utmcontent

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver 
where product_type = '3CI'

-- COMMAND ----------


--silver 3ci
select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where Product_id ='3CI' and funnel_stage='success'

-- COMMAND ----------

select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver_intermediate.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='3CI'




-- COMMAND ----------

select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver_intermediate.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='3CI'
and  json_data_others_utmcontent='RESPONSIVEDISPLAY-DESKTOP-MOBILE-RMKT-SITEVISITOR-BIG3PDTPAGE' 


-- COMMAND ----------

-- intermediate SI count

select AFTER_PRODUCT_TYPE, json_data_others_utmcontent, count(*) as Sucess_Cnt
from dev_silver_intermediate.users_data_silver
where 
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='SI'
group by AFTER_PRODUCT_TYPE, json_data_others_utmcontent

-- COMMAND ----------

-- intermediate SI
select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver_intermediate.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='CI'


-- COMMAND ----------

--Silver SI

select * from dev_ainbo_silver.success_silver 
where product_type = 'SI'

-- COMMAND ----------

--View SI

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where Product_id ='SI' and funnel_stage='success'

-- COMMAND ----------



-- COMMAND ----------

-- intermediate CI count

select AFTER_PRODUCT_TYPE, json_data_others_utmcontent, count(*) as Sucess_Cnt
from dev_silver_intermediate.users_data_silver
where 
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='CI'
group by AFTER_PRODUCT_TYPE, json_data_others_utmcontent

-- COMMAND ----------

-- intermediate CI
select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver_intermediate.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='CI'

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver 
where product_type = 'CI'

-- COMMAND ----------

--view CI

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where Product_id ='CI' and funnel_stage='success'

-- COMMAND ----------

-- intermediate HA
select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver_intermediate.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='HA'

-- COMMAND ----------

--silver HA
select * from dev_ainbo_silver.success_silver 
where product_type = 'HA'

-- COMMAND ----------

--view HA

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where Product_id ='HA' and funnel_stage='success'

-- COMMAND ----------

select * from dev_vnb.vnb_channel_silver

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion 

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion 