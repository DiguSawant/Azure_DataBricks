-- Databricks notebook source
select ET_ENTITYSEQ, DATAVALUE_PRODUCTID,DATAVALUE_PREMIUMINFO_PAYMENTMODE,DATAVALUE_PREMIUMINFO_PREMIUM,datavalue_policyNumber,DATAVALUE_PAYMENTTYPE,DATAVALUE_ISPAYMENTCOMPLETE,UDH_INSERT_TIMESTAMP, DATAVALUE_UTMTRACKING_UTMCONTENT,DATAVALUE_PARTNER
 from dev_silver_intermediate.nosql_data_entity_silver
 where DATAVALUE_PRODUCTID IS NOT NULL  and DATAVALUE_PRODUCTID = 'E60A1'
      and datavalue_isPaymentComplete ='TRUE'
     

-- COMMAND ----------


select * from dev_vnb.vnb_channel_silver WHERE Partner_Name in ('ECOM')

-- COMMAND ----------

select * from dev_vnb.vnb_rates_silver WHERE PRODUCT_ID='E60A1' and Digital_Channel in('DTC')

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver where PRODUCT_TYPE='E60A1' 

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where product_id ='E60A1' and funnel_stage ='success'