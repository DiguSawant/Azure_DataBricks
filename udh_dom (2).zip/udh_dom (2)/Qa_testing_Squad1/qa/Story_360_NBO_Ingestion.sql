-- Databricks notebook source
 select * from fwd_test_silver_intermediate.nbo_silver

-- COMMAND ----------

select * from fwd_test_silver_intermediate.nbo_demographic_silver

-- COMMAND ----------

select  distinct * from fwd_test_silver_intermediate.vw_demographics