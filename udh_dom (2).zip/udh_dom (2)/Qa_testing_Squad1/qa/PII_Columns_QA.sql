-- Databricks notebook source

---non nbm
select dt_entityseq,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName,datavalue_policyHolder_title,datavalue_policyHolder_jobName,datavalue_policyHolder_jobGroup,datavalue_premiumInfo_gender,datavalue_premiumInfo_birthDate,datavalue_policyHolder_status,datavalue_policyHolder_mobileNumber,datavalue_identity_idCard,datavalue_policyHolder_email,datavalue_icp_accountNumber,datavalue_icp_accountName,datavalue_addresses_current_province,datavalue_addresses_current_zip,datavalue_addresses_current_houseNumber,datavalue_addresses_current_village,datavalue_addresses_current_road,datavalue_addresses_current_subDistrict,datavalue_addresses_current_district,datavalue_addresses_workplace_province,datavalue_addresses_workplace_zip,datavalue_addresses_workplace_houseNumber,datavalue_addresses_workplace_village,datavalue_addresses_workplace_road,datavalue_addresses_workplace_subDistrict,datavalue_addresses_workplace_district,datavalue_addresses_home_province,datavalue_addresses_home_zip,datavalue_addresses_home_houseNumber,datavalue_addresses_home_village,datavalue_addresses_home_road,datavalue_addresses_home_subDistrict,datavalue_addresses_home_district from dev_silver_intermediate.nosql_data_entity_silver limit 2
-- where aes_decrypt(DT_ENTITYSEQ)='370540'



-- COMMAND ----------

select json_data_policydata_insuredlives_insuredDetails_dob,json_data_policydata_insuredlives_insuredDetails_gender,json_data_policydata_insuredlives_insuredDetails_occupationClass,json_data_policydata_insuredlives_insuredDetails_occupationName,json_data_policydata_insuredlives_insuredDetails_title,json_data_policydata_insuredlives_insuredDetails_lastName,json_data_policydata_insuredlives_insuredDetails_firstName,json_data_policydata_insuredlives_insuredDetails_fullName,json_data_policydata_insuredlives_insuredDetails_postalCode,json_data_policydata_insuredlives_insuredDetails_provinceCd,json_data_policydata_insuredlives_insuredDetails_countryOfResidence,json_data_policydata_insuredlives_insuredDetails_districtCd,json_data_policydata_insuredlives_insuredDetails_address4,json_data_policydata_insuredlives_insuredDetails_address3,json_data_policydata_insuredlives_insuredDetails_address2,json_data_policydata_insuredlives_insuredDetails_address1,after_id,json_data_frontenddata_xsell_policyholder_email,json_data_frontenddata_xsell_policyholder_fullname,json_data_frontenddata_amlrequest_idcardnumber,json_data_frontenddata_xsell_policyholder_mobile from dev_silver_intermediate.users_data_silver limit 10


-- COMMAND ----------

select * from dev_party_silver.party_silver 
--where party_id = 1090

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver where aes_decrypt(DT_ENTITYSEQ) = '411614'

-- COMMAND ----------



-- COMMAND ----------

-- MAGIC %run /Shared/udh_dom/tech_utility/aes

-- COMMAND ----------

select aes_decrypt(party_id)  from dev_party_silver.party_silver 

-- COMMAND ----------



-- COMMAND ----------

select party_id,party_name,email_address from dev_party_silver.party_silver where aes_decrypt(party_id)='370540'

-- COMMAND ----------

--select  from dev_party_silver.individual_silver limit 2
desc dev_party_silver.individual_silver


-- COMMAND ----------

-- Party silver table 
select * from dev_silver_intermediate.nosql_data_entity_silver where aes_decrypt(DT_ENTITYSEQ)='370540'

-- COMMAND ----------



-- Party Intermediate table for non-nbm
select dt_entityseq,
datavalue_policyHolder_mobileNumber,
datavalue_policyHolder_email
from dev_silver_intermediate.nosql_data_entity_silver where aes_decrypt(DT_ENTITYSEQ)='370540'


-- COMMAND ----------

-- Individual Intermediate table
select DT_ENTITYSEQ,DATAVALUE_POLICYHOLDER_FIRSTNAME,



from dev_silver_intermediate.nosql_data_entity_silver where aes_decrypt(DT_ENTITYSEQ)='370540'


-- COMMAND ----------

desc dev_silver_intermediate.nosql_data_entity_silver 

-- COMMAND ----------

select json_data_policydata_insuredlives_insuredDetails_lastName,json_data_policydata_insuredlives_insuredDetails_firstName,json_data_policydata_insuredlives_insuredDetails_fullName,json_data_frontenddata_xsell_policyholder_email,json_data_frontenddata_xsell_policyholder_fullname,--json_data_frontenddata_amlrequest_idcardnumber,json_data_frontenddata_xsell_policyholder_mobile
after_id from dev_silver_intermediate.users_data_silver limit 10

-- COMMAND ----------

select * from dev_party_silver.identity_silver whew party_id = '6nJ91tAOZ/gB21wujE5W3A=='

-- COMMAND ----------

select dt_entityseq,datavalue_identity_idCard from dev_silver_intermediate.nosql_data_entity_silver where aes_decrypt(DT_ENTITYSEQ)='370540'

-- COMMAND ----------

select json_data_policydata_insuredlives_insuredDetails_dob,json_data_policydata_insuredlives_insuredDetails_gender,json_data_policydata_insuredlives_insuredDetails_occupationClass,json_data_policydata_insuredlives_insuredDetails_occupationName,json_data_policydata_insuredlives_insuredDetails_title,json_data_policydata_insuredlives_insuredDetails_lastName,json_data_policydata_insuredlives_insuredDetails_firstName,json_data_policydata_insuredlives_insuredDetails_fullName,json_data_policydata_insuredlives_insuredDetails_postalCode,json_data_policydata_insuredlives_insuredDetails_provinceCd,json_data_policydata_insuredlives_insuredDetails_countryOfResidence,json_data_policydata_insuredlives_insuredDetails_districtCd,json_data_policydata_insuredlives_insuredDetails_address4,json_data_policydata_insuredlives_insuredDetails_address3,json_data_policydata_insuredlives_insuredDetails_address2,json_data_policydata_insuredlives_insuredDetails_address1,after_id,json_data_frontenddata_xsell_policyholder_email,json_data_frontenddata_xsell_policyholder_fullname,json_data_frontenddata_amlrequest_idcardnumber,json_data_frontenddata_xsell_policyholder_mobile from dev_silver_intermediate.users_data_silver limit 10

-- COMMAND ----------

select after_id,JSON_DATA_FRONTENDDATA_AMLREQUEST_IDCARDNUMBER from dev_silver_intermediate.users_data_silver limit 10

-- COMMAND ----------

select party_id ,bank_account_number,bank_account_name from dev_party_silver.bank_account_silver

-- COMMAND ----------

select * from dev_party_silver.bank_account_silver where aes_decrypt(party_id)='416352'

--select * from dev_party_silver.bank_account_silver where aes_decrypt(party_id)='416352'

-- COMMAND ----------

select DT_ENTITYSEQ,DATAVALUE_ICP_ACCOUNTNAME ,DATAVALUE_ICP_ACCOUNTNUMBER from 
dev_silver_intermediate.nosql_data_entity_silver
where DATAVALUE_ICP_ACCOUNTNAME IS NOT NULL and DATAVALUE_ICP_ACCOUNTNUMBER IS NOT NULL and DATAVALUE_ICP_ACCOUNTNAME != '' and DATAVALUE_ICP_ACCOUNTNUMBER  != ''
 
-- where aes_decrypt(DT_ENTITYSEQ)='370540'
--dt_entityseq ,datavalue_icp_accountNumber,datavalue_icp_accountName

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver limit 10

-- COMMAND ----------

-- Non NBM silver intermediate table
 
select party_id, phone_number
from dev_party_silver.electronic_address_silver limit 10


-- COMMAND ----------


---non nbm intermediate electronics table 
select dt_entityseq,
datavalue_policyHolder_mobileNumber
from dev_silver_intermediate.nosql_data_entity_silver
where datavalue_policyHolder_mobileNumber is not null




-- COMMAND ----------

-- non nbm silver organistaion layer
select * from dev_party_silver.organisation_silver limit 10

-- COMMAND ----------

--- NBM Intermediate table Electronics table

select after_id,
json_data_frontenddata_xsell_policyholder_mobile
from dev_silver_intermediate.users_data_silver limit 10

-- COMMAND ----------

-- non nbm silver organisation layer
select * from dev_party_silver.organisation_silver

-- COMMAND ----------

-- non nbm intermediate organisation layer
select dt_entityseq
from dev_silver_intermediate.nosql_data_entity_silver limit 10

-- COMMAND ----------

-- NBM Intermediate Orgaanistaion layer table 

select after_id
from dev_silver_intermediate.users_data_silver limit 10

-- COMMAND ----------

-- Individual silver table 
select party_id,full_name,first_name,middle_name,last_name,local_full_name,local_first_name,local_middle_name,local_last_name,salutation,occupation,occupation_class,annual_income,gender_code,
birth_date,birth_place,nationality_code,marital_status_code from dev_party_silver.individual_silver limit 100

-- COMMAND ----------

-- Non Nbm Individual Intermediate table 
select dt_entityseq,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName,datavalue_policyHolder_title,datavalue_policyHolder_jobName,datavalue_policyHolder_jobGroup,datavalue_premiumInfo_gender,datavalue_premiumInfo_birthDate,datavalue_policyHolder_status,datavalue_policyHolder_mobileNumber,datavalue_identity_idCard,datavalue_policyHolder_email,datavalue_icp_accountNumber,datavalue_icp_accountName,datavalue_addresses_current_province,datavalue_addresses_current_zip,datavalue_addresses_current_houseNumber,datavalue_addresses_current_village,datavalue_addresses_current_road,datavalue_addresses_current_subDistrict,datavalue_addresses_current_district,datavalue_addresses_workplace_province,datavalue_addresses_workplace_zip,datavalue_addresses_workplace_houseNumber,datavalue_addresses_workplace_village,datavalue_addresses_workplace_road,datavalue_addresses_workplace_subDistrict,datavalue_addresses_workplace_district,datavalue_addresses_home_province,datavalue_addresses_home_zip,datavalue_addresses_home_houseNumber,datavalue_addresses_home_village,datavalue_addresses_home_road,datavalue_addresses_home_subDistrict,datavalue_addresses_home_district from dev_silver_intermediate.nosql_data_entity_silver limit 2 

-- COMMAND ----------

select dt_entityseq,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName,datavalue_policyHolder_title,datavalue_policyHolder_jobName,datavalue_policyHolder_jobGroup,
datavalue_premiumInfo_gender,datavalue_premiumInfo_birthDate,datavalue_policyHolder_status
from dev_silver_intermediate.nosql_data_entity_silver 
where datavalue_policyHolder_firstName is not null and datavalue_policyHolder_firstName != ' '

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver limit 100

-- COMMAND ----------

desc dev_silver_intermediate.nosql_data_entity_silver 

-- COMMAND ----------

-- non nbm intermediate inidvidual
select after_id,JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_FULLNAME,JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_FIRSTNAME,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_LASTNAME,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_TITLE,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_GENDER,
JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB
from dev_silver_intermediate.users_data_silver limit 100

-- COMMAND ----------

desc dev_silver_intermediate.users_data_silver

-- COMMAND ----------

select * from 

-- COMMAND ----------

qa_initial_load_bronze.nosql_data_entity_bronze