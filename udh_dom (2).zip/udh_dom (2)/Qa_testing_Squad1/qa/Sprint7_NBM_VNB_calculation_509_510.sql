-- Databricks notebook source
select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
				JSON_DATA_OTHERS_PARTNERCODE,AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='HA'

-- COMMAND ----------

select * from  dev_ainbo_silver.success_silver 
where SOURCE_SYSTEM ='nbm' and product_type= 'HA'

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where Product_id ='HA' and funnel_stage='success'

-- COMMAND ----------

select * from dev_vnb.vnb_channel_silver

-- COMMAND ----------

select * from dev_vnb.vnb_rates_silver

-- COMMAND ----------

select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
JSON_DATA_OTHERS_PARTNERCODE,AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='SI'

-- COMMAND ----------

select * from  dev_ainbo_silver.success_silver 
where SOURCE_SYSTEM ='nbm' and product_type= 'SI'

-- COMMAND ----------

select Product_ID,Funnel_Stage,Count,APE,VNB from dev_ainbo_gold.vw_campaign_ainbo_conversion
 where Product_id ='SI' and funnel_stage='success'

-- COMMAND ----------

select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
JSON_DATA_OTHERS_PARTNERCODE,AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='CI'

-- COMMAND ----------

select PRODUCT_TYPE,UTM_CONTENT,Count,APE,VNB
 from  dev_ainbo_silver.success_silver 
where SOURCE_SYSTEM ='nbm' and product_type= 'CI'

-- COMMAND ----------

select Product_Id, UTM_CONTENT,APE,VNB from dev_ainbo_gold.vw_campaign_ainbo_conversion 
where Product_id ='CI' and funnel_stage='success' order by UTM_CONTENT desc

-- COMMAND ----------

select
JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID,
JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING,
JSON_DATA_OTHERS_PARTNERCODE,AFTER_PRODUCT_TYPE, json_data_others_utmcontent
from dev_silver.users_data_silver
Where
upper(AFTER_USER_VIEW)= upper('quote.payment') and upper(AFTER_STATUS) = upper('payment')
and AFTER_PRODUCT_TYPE ='3CI'

-- COMMAND ----------

select PRODUCT_TYPE,UTM_CONTENT,Count,APE,VNB
 from  dev_ainbo_silver.success_silver 
where SOURCE_SYSTEM ='nbm' and product_type= '3CI'

-- COMMAND ----------

select Product_Id, UTM_CONTENT,APE,VNB from dev_ainbo_gold.vw_campaign_ainbo_conversion 
where Product_id ='3CI' and funnel_stage='success' order by UTM_CONTENT desc