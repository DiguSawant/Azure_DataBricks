# Databricks notebook source
# MAGIC %md
# MAGIC ###IMPORTING REQUIRED PACKAGES

# COMMAND ----------

import unittest

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASES FOR TELESALES

# COMMAND ----------

class NBOTableUnitTesting(unittest.TestCase):

    #check if the we have all the required columns are present in intermediate table.
    def test_check_columns_for_intermediate_table(self):
        expected_columns=['FirstName','LastName','ID_Card','Gender','Email','CellPhone','PersonalStatus','LeadCreateDate','BirthDate','ExpectedProductName','Province','consent','consent_Times','Package','Promo_code','age','FullName','file_date','Remark','PartnerName','DTCCampaignId','userCRM','id','pattern','pattern_1','suffix_2','suffix_1','ActivityId','UserCRMId','Source','MediaSource','NumberOfChild','Sex','partition_date','udh_cust_find_time']
        actual_df = spark.sql('SELECT * FROM dev_telesales_silver.telesales_silver')
        self.assertTrue((actual_df.columns == expected_columns),True)
    
    #check if the we have all the required columns are present in view.
    def test_check_columns_for_view(self):
        expected_columns= ['PACKAGE','NO_RECEIVED_LEADS','NO_LEADS_PASSED','NO_POLICY_SOLD','CONVERSION_RATE','APE']
        actual_df = spark.sql('SELECT * FROM dev_telesales_gold.vw_telesales_conversion;')
        self.assertTrue((actual_df.columns == expected_columns),True)
    
    #check if the all the column names are in uppercase
    #Tables: leads_received, leads_passed_to_telesales, cust_sold_policy, sum_ape, total_leads_passed_telesales, cust_sold_sum_ape_policy
    #View: vw_telesales_conversion
    def test_column_name_is_upper(self):
        col_df = spark.sql('SELECT * FROM dev_telesales_gold.vw_telesales_conversion limit 1;')
        result = True
        for cols in col_df.columns:
            if(cols == cols.upper()):
                continue
            result = False
            break
        expected = True
        self.assertEqual(result,expected)
    

# COMMAND ----------

# MAGIC %md
# MAGIC ###EXECUTING ALL TESTCASES

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_telesales_silver.telesales_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_telesales_gold.vw_telesales_conversion;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dev_telesales_silver.leads_passed_to_telesales;