-- Databricks notebook source
--select * from silver_intermediate.users_data

--select *  from dev_silver_intermediate.users_data_silver limit 10

select distinct json_data_others_utmcontent  from dev_silver_intermediate.users_data_silver limit 10


-- COMMAND ----------

--Story 407 NBM Qoute

select after_product_type ,json_data_others_utmcontent , count(*) from dev_silver_intermediate.users_data_silver

where  after_user_view = 'quote.quickQuestions' and after_status = 'proposal'
group by after_product_type , json_data_others_utmcontent 


-- COMMAND ----------

--Story 408 NBM Health Questions

select after_product_type , distinct  json_data_others_utmcontent , count(*) from dev_silver_intermediate.users_data_silver
where  after_user_view = 'quote.underwritingAnswer' and after_status = 'proposal'
--group by after_product_type , json_data_others_utmcontent 

-- COMMAND ----------

--raghu  -- health questions

--select * from dev_silver_intermediate.users_data_silver where after_user_view = 'quote.underwritingAnswer' and after_status = 'proposal'
-- and  json_data_others_utmcontent IS NOT NULL
 
 
 SELECT
  *
FROM dev_silver_intermediate.users_data_silver
--WHERE json_data_others_utmcontent IS NOT NULL and after_user_view = 'quote.underwritingAnswer' and after_status = 'proposal'

-- COMMAND ----------

DESC dev_silver_intermediate.users_data_silver

-- COMMAND ----------

--Story 409 NBM Personal Info stage

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.personalDetail' and after_status = 'proposal'
group by after_product_type

-- COMMAND ----------

 select * from dev_ainbo_silver.vw_campaign_ainbo_conversion  
 --where utm_content IS NOT ''

-- COMMAND ----------

--story 410 summary
--USERS_VIEW → quote.proceedToPay ; STATUS → proposal

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.proceedToPay' and after_status = 'proposal'
group by after_product_type

-- COMMAND ----------

--story 411 payment stage

--USERS_VIEW → quote.payment ; STATUS → pending

select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.payment' and after_status = 'pending'
group by after_product_type

-- COMMAND ----------


-- story 411 Pramod Query
select after_product_type, count(*) from silver_intermediate.users_data where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'pending'
group by after_product_type

-- COMMAND ----------

select product_type,sum(count),source_system  from ainbo_silver.payment where source_system = 'nbm' group by product_type ,source_system

--select * from ainbo_silver.payment where source_system = 'nbm' order by product_type

--select product_type,sum(count) from ainbo_silver.payment group by product_type

-- COMMAND ----------

--Story 412 sucess -- old

--USERS_VIEW → quote.payment ; STATUS → payment

select after_product_type , json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver
where  after_user_view = 'quote.payment' and after_status = 'payment' and json_data_others_utmcontent IS NOT null
group by after_product_type ,json_data_others_utmcontent

-- COMMAND ----------

--Story 412 sucess

--USERS_VIEW → quote.payment ; STATUS → payment
select after_product_type,json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'payment' and json_data_others_utmcontent IS NOT NULL
group by after_product_type , json_data_others_utmcontent

--product_id,product_name,funnel_stage ,utm_content,sum(count)

-- COMMAND ----------

select product_type,sum(count) from dev_ainbo_silver.success_silver group by product_type

-- COMMAND ----------

--story 411 payment stage

--USERS_VIEW → quote.payment ; STATUS → pending

select after_product_type , count(*) from dev_silver_intermediate.users_data_silver where  lower(after_user_view ) = 'quote.payment' and lower(after_status) = 'pending' group by after_product_type

-- COMMAND ----------

select product_type,sum(count) from dev_ainbo_silver.payment_silver group by product_type

-- COMMAND ----------

select product_type,sum(count) from ainbo_silver.success group by product_type

-- use this querry

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver

-- COMMAND ----------

--select product_type , product_name  ,utm_content,source_system from dev_ainbo_silver.success_silver group by product_type , product_name ,utm_content,source_system order by product_type

select product_type , product_name  ,utm_content,source_system ,sum(count)  from dev_ainbo_silver.success_silver
where  product_type IN ('3CI' ,'CI')
group by product_type , product_name  ,utm_content,source_system

-- COMMAND ----------

-- 469

select * from  dev_ainbo_silver.vw_campaign_ainbo_conversion 

-- COMMAND ----------

select product_id,product_name,funnel_stage ,utm_content,sum(count) from dev_ainbo_silver.vw_campaign_ainbo_conversion 
where  product_id IN ('3CI' ,'CI') and funnel_stage = 'success' group by product_id,product_name,funnel_stage,utm_content

-- COMMAND ----------

 select * from dev_ainbo_silver.quote

-- COMMAND ----------

 select * from dev_ainbo_silver.health_question_silver 
 --where source_system != 'nbm'
 
 

-- COMMAND ----------

 select * from ainbo_silver.personal_info

-- COMMAND ----------

select * from ainbo_silver.summary

-- COMMAND ----------

select * from ainbo_silver.payment


-- COMMAND ----------

--select product_type,sum(count) from ainbo_silver.success group by product_type

select * from dev_ainbo_silver.success_silver where product_type = 'CI'

-- COMMAND ----------

-- 470 raw query for summary

--USERS_VIEW → quote.payment ; STATUS → payment
--select after_product_type,json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.proceedToPay' and lower(after_status) = 'proposal'
--and json_data_others_utmcontent IS NOT NULL
--group by after_product_type , json_data_others_utmcontent



--USERS_VIEW → quote.payment ; STATUS → payment
select after_product_type,json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver where after_user_view = 'quote.proceedToPay' and lower(after_status) = 'proposal'
and after_product_type = 'CI'
--and json_data_others_utmcontent IS NOT NULL
group by after_product_type , json_data_others_utmcontent


-- COMMAND ----------

--  470 summary in silver

select product_type , product_name  ,utm_content,source_system ,sum(count)  from dev_ainbo_silver.summary_silver
where  product_type IN ( 'CI')
group by product_type , product_name  ,utm_content,source_system




-- COMMAND ----------

-- 470 summary in view
select product_id,product_name,funnel_stage ,utm_content, source_system , sum(count) from dev_ainbo_silver.vw_campaign_ainbo_conversion 
where  product_id IN ('CI') and funnel_stage = 'summary' group by product_id,product_name,funnel_stage,utm_content, source_system

-- COMMAND ----------

-- 470 nbm payment raw

select after_product_type,json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver where  lower(after_user_view ) = 'quote.payment' and lower(after_status) = 'pending' 
and after_product_type = 'CI'
--and json_data_others_utmcontent IS NOT NULL
group by after_product_type , json_data_others_utmcontent

-- COMMAND ----------

---470 payment silver
select product_type , product_name  ,utm_content,source_system ,sum(count)  from dev_ainbo_silver.payment_silver
where  product_type IN ( 'CI')
group by product_type , product_name  ,utm_content,source_system

-- COMMAND ----------

-- 470 payment View
select product_id,product_name,funnel_stage ,utm_content, source_system , sum(count) from dev_ainbo_silver.vw_campaign_ainbo_conversion 
where  product_id IN ('CI') and funnel_stage = 'payment' group by product_id,product_name,funnel_stage,utm_content, source_system

-- COMMAND ----------

--USERS_VIEW → quote.payment ; STATUS → payment

---470 NBM sucess RAW
select after_product_type,json_data_others_utmcontent, count(*) from dev_silver_intermediate.users_data_silver where lower(after_user_view )= 'quote.payment' and lower(after_status) = 'payment' and json_data_others_utmcontent IS NOT NULL
and after_product_type IN ('3CI' ,'CI')
group by after_product_type , json_data_others_utmcontent

--product_id,product_name,funnel_stage ,utm_content,sum(count)

-- COMMAND ----------

--470 NBM  Sucess silver
select product_type , product_name  ,utm_content,source_system ,sum(count)  from dev_ainbo_silver.success_silver
where  product_type IN ('3CI' ,'CI')
group by product_type , product_name  ,utm_content,source_system

-- COMMAND ----------

-- 470 NBM sucess View

select product_id,product_name,funnel_stage ,utm_content,sum(count) from dev_ainbo_silver.vw_campaign_ainbo_conversion 
where  product_id IN ('3CI' ,'CI') and funnel_stage = 'success' group by product_id,product_name,funnel_stage,utm_content