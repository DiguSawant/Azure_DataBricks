# Databricks notebook source


# COMMAND ----------

# MAGIC %sql
# MAGIC select id, aes_decrypt(policy_id ) from delta.il_tb_agrt_policy_curr_dim

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/aes

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select Source_policy_id, aes_decrypt(source_policy_id)source_policy_main_policy_owner_id, Policy_status_code,POLICY_issue_date
# MAGIC from delta.la_tb_agrt_policy_curr_dim e 
# MAGIC where aes_decrypt(source_policy_id) in ('D70020012','D70208464')
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_ainbo_silver.vw_tb_agrt_policy_curr_dim 
# MAGIC where source_policy_id = 'D70020012'

# COMMAND ----------

# MAGIC %sql
# MAGIC D70208464

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct(DATAVALUE_POLICYNUMBER),datavalue_utmTracking_utmContent  from 
# MAGIC dev_silver_intermediate.nosql_data_entity_silver 
# MAGIC where DATAVALUE_POLICYNUMBER is not null and datavalue_utmTracking_utmContent is not null 
# MAGIC and DATAVALUE_UTMTRACKING_UTMCONTENT ='D7183038-8901-427E-93EA-4C01C6B5F2E9'

# COMMAND ----------

# MAGIC %sql
# MAGIC --%sql
# MAGIC select * from dev_ainbo_gold.vw_campaign_ainbo_demographics where source_system ='NBM'

# COMMAND ----------

# MAGIC %sql
# MAGIC select ID, OFFER_KEY,POLICY_NUMBER, POLICY_STATUS_CODE,POLICY_ISSUE_DATE,SOURCE_SYSTEM 
# MAGIC from dev_ainbo_gold.vw_campaign_ainbo_demographics 
# MAGIC where POLICY_NUMBER ='D70208464'

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from dev_ainbo_gold.vw_campaign_ainbo_demographics

# COMMAND ----------

# MAGIC %sql
# MAGIC desc table dev_ainbo_gold.vw_campaign_ainbo_demographics