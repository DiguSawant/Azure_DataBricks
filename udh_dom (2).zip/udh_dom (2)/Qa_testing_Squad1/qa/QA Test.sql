-- Databricks notebook source
-- MAGIC %sql create database qa_testing

-- COMMAND ----------

-- MAGIC %sql create table qa_testing.s3_raw_nosqlentity_test1 using json location "/mnt/fwd_test/nosql_data_entity/nosqlentity/*.json"

-- COMMAND ----------

select * from qa_testing.s3_raw_nosqlentity_test1

-- COMMAND ----------

create table qa_testing.s3_raw_nosqldata_test1 using json location "/mnt/fwd_test/nosql_data_entity/nosqldata/*.json"

-- COMMAND ----------

select * from qa_testing.s3_raw_nosqldata_test1;

-- COMMAND ----------

select * from party_silver.party where party_id = 1006793

-- COMMAND ----------

select * from party_silver.individual where party_id = 1006793

--select * from party_silver.individual

-- COMMAND ----------

 select * from party_silver.identity where party_id = 1006793
--select * from party_silver.identity

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Electronics address table

-- COMMAND ----------

select * from party_silver.electronic_address

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Bank Account table

-- COMMAND ----------

select * from party_silver.bank_account

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Organisationt table

-- COMMAND ----------

select * from party_silver.organisation

-- COMMAND ----------

