-- Databricks notebook source
-- MAGIC %fs ls "/mnt/dev/fwd_landing/bronze/ainbo/api_in/TH.DEV.ODS.AINBO.API_IN.RECO_OFFER/year=2023/month=03/day=28/"

-- COMMAND ----------

-- MAGIC  %fs cat "dbfs:/mnt/dev/fwd_landing/bronze/ainbo/api_in/TH.DEV.ODS.AINBO.API_IN.RECO_OFFER/year=2023/month=03/day=28/TH.DEV.ODS.AINBO.API_IN.RECO_OFFER+0+0000000024.bin"

-- COMMAND ----------

 select * from  dev_silver_intermediate.nbo_silver
 where OFFER_KEY = "C60F9EA2-6C7C-4612-B94D-07F4FD14B937"

-- COMMAND ----------

DESCRIBE dev_silver_intermediate.nbo_silver

-- COMMAND ----------

select OFFER_KEY from  dev_silver_intermediate.nbo_silver
 

-- COMMAND ----------

select * from dev_silver_intermediate.nbo_silver

-- COMMAND ----------

select count(*) from dev_silver_intermediate.nbo_silver

-- COMMAND ----------

DESCRIBE dev_ainbo_gold.vw_campaign_ainbo_demographics

-- COMMAND ----------

select count(*) from dev_ainbo_gold.vw_campaign_ainbo_demographics where Source_system = 'NON_NBM'
--where OFFER_KEY = '51F32356-75AB-41DC-9102-913695623F85'
--select distinct Source_system from dev_ainbo_gold.vw_campaign_ainbo_demographics 





-- COMMAND ----------

--select * from dev_ainbo_gold.vw_campaign_ainbo_demographics where Source_system = 'NON_NBM' limit 5
--select * from dev_ainbo_gold.vw_campaign_ainbo_demographics where Offer_KEY = '497FDCE1-DACA-4C8F-8CB1-029F0023BAD2'



-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver limit 3



-- COMMAND ----------

select count(*) from dev_ainbo_gold.vw_campaign_ainbo_demographics 

-- COMMAND ----------

--join of NBO and NBM
select 
 count(*)from 
      dev_silver_intermediate.nbo_silver as s
left join dev_silver_intermediate.users_data_silver as l
on
      lower(l.json_data_others_utmcontent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)    
    --users_data_silver

-- COMMAND ----------

select * from 
dev_ainbo_gold.vw_campaign_ainbo_demographics 

-- COMMAND ----------



--join of NBO and Non NBM
select 
    count(*)
from 
      dev_silver_intermediate.nbo_silver as s
left join  dev_silver_intermediate.nosql_data_entity_silver as l
on
      lower(l.datavalue_utmTracking_utmContent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)
      


-- COMMAND ----------


--non nbm simple join
select 
    *
from 
      dev_silver_intermediate.nbo_silver as s
 join  dev_silver_intermediate.nosql_data_entity_silver as l
on
      lower(l.datavalue_utmTracking_utmContent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)

-- COMMAND ----------


-- nbm simple join trial and error

select s.OFFER_KEY , l.json_data_others_utmcontent
  from 
      dev_silver_intermediate.nbo_silver as s
 join dev_silver_intermediate.users_data_silver as l
on
      lower(l.json_data_others_utmcontent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string) 

-- COMMAND ----------

select * from dev_silver_intermediate.users_data_silver limit 3
--dev_silver_intermediate.users_data_silver

-- COMMAND ----------

---Querying Non nbm for particular utm content(==>offer key of NBO)
select * from dev_silver_intermediate.nosql_data_entity_silver where datavalue_utmTracking_utmContent = '497FDCE1-DACA-4C8F-8CB1-029F0023BAD2'

-- COMMAND ----------

-----Querying NBM for particular utm content(==>offer key of NBO)

select * from dev_silver_intermediate.users_data_silver where json_data_others_utmcontent = '17A5F15D-7707-4F36-AC46-BA1688E08030'

-- COMMAND ----------



select json_data_others_utmcontent  from dev_silver_intermediate.users_data_silver where json_data_others_utmcontent IS NOT NULL

-- COMMAND ----------

select Offer_KEY from dev_ainbo_gold.vw_campaign_ainbo_demographics where Source_System = 'NBM'

-- COMMAND ----------

( select 
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.OFFER_RANKING AS RANKING,
    s.OFFER_CUSTOMERSEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.CAMPAIGN_SOURCE AS CAMPAIGN_SOURCE,
    s.CAMPAIGN_PRODUCTS AS CAMPAIGN_PRODUCTS,
    s.CAMPAIGN_MEDIUM AS MEDIUM,
    s.PROFILE_REFERENCEKEY AS REFERENCE_KEY,
    s.PROFILE_AGE AS AGE,
    s.PROFILE_MARITALSTATUS AS MARITAL_STATUS,
    s.PROFILE_HASCREDITCARD AS HAS_CREDITCARD,
    s.PROFILE_HASCHILDREN AS HAS_CHILDREN,
    s.PROFILE_NUMBEROFCHILDREN AS NUMBER_OF_CHILDREN,
    s.PROFILE_GENDER AS GENDER,
    s.PROFILE_INCOME AS INCOME,
    s.PROFILE_ADDRESS_DISTRICT AS DISTRICT,
    s.PROFILE_ADDRESS_PROVINCE AS PROVINCE,
    s.PROFILE_ADDRESS_ZIPCODE AS ZIPCODE,
    l.json_data_policies_3ci_policydetails_policyno AS POLICY_NUMBER,
    l.json_data_frontenddata_xsell_productcode AS PRODUCT_CODE,
    l.json_data_policyData_insuredLives[0].insuredDetails.dob AS DOB,
    l.json_data_frontenddata_xsell_premiumpaid AS PREMIUM,
     CASE WHEN 
     l.json_data_frontenddata_xsell_premiumpaid >    l.json_data_policyData_totalPremiums_monthly_afterGST_premium_beforeMarketingDis_beforeLoading 
     THEN 'YEARLY'
     ELSE 'MONTHLY'
     END
     AS
     BILLING_MODE,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationGroupName AS OCCUPATION_GROUP,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationName AS OCCUPATION_NAME,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationClass AS OCCUPATION_CLASS,
     l.json_data_policyData_selectedPayment_paymentTypes_paymentType AS PAYMENT_METHOD,
     l.json_data_others_promo AS PROMO_CODE,
     l.json_data_others_utmSource AS UTM_SOURCE,
     l.json_data_others_utmMedium AS UTM_MEDIUM,
     l.json_data_others_utmCampaign AS UTM_CAMPAIGN,
     'NBM' AS SOURCE_SYSTEM
from 
      dev_silver_intermediate.nbo_silver as s
left join  dev_silver_intermediate.users_data_silver as l
on
      lower(l.json_data_others_utmcontent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)      
union

select 
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.OFFER_RANKING AS RANKING,
    s.OFFER_CUSTOMERSEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.CAMPAIGN_SOURCE AS CAMPAIGN_SOURCE,
    s.CAMPAIGN_PRODUCTS AS CAMPAIGN_PRODUCTS,
    s.CAMPAIGN_MEDIUM AS MEDIUM,
    s.PROFILE_REFERENCEKEY AS REFERENCE_KEY,
    s.PROFILE_AGE AS AGE,
    s.PROFILE_MARITALSTATUS AS MARITAL_STATUS,
    s.PROFILE_HASCREDITCARD AS HAS_CREDITCARD,
    s.PROFILE_HASCHILDREN AS HAS_CHILDREN,
    s.PROFILE_NUMBEROFCHILDREN AS NUMBER_OF_CHILDREN,
    s.PROFILE_GENDER AS GENDER,
    s.PROFILE_INCOME AS INCOME,
    s.PROFILE_ADDRESS_DISTRICT AS DISTRICT,
    s.PROFILE_ADDRESS_PROVINCE AS PROVINCE,
    s.PROFILE_ADDRESS_ZIPCODE AS ZIPCODE,
    l.datavalue_policyNumber AS POLICY_NUMBER,
    l.datavalue_productId AS PRODUCT_CODE,
    l.datavalue_premiumInfo_birthDate AS DOB,
    l.datavalue_premiumInfo_premium AS PREMIUM,
    l.datavalue_premiumInfo_paymentMode AS BILLING_MODE,
    l.datavalue_policyHolder_jobGroup AS OCCUPATION_GROUP,
    l.datavalue_policyHolder_jobName AS OCCUPATION_NAME,
    NULL AS OCCUPATION_CLASS,
    l.datavalue_paymentType AS PAYMENT_METHOD,
    l.datavalue_promoCode AS PROMO_CODE,
    l.datavalue_utmTracking_utmSource AS UTM_SOURCE,
    l.datavalue_utmTracking_utmMedium AS UTM_MEDIUM,
    l.datavalue_utmTracking_utmCampaign AS UTM_CAMPAIGN,
     'NON_NBM' AS SOURCE_SYSTEM
from 
      dev_silver_intermediate.nbo_silver as s
left join dev_silver_intermediate.nosql_data_entity_silver as l
on
      lower(l.datavalue_utmTracking_utmContent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)
order by OFFER_KEY
)


except

select 
ID,
OFFER_KEY,
RANKING,
CUSTOMER_SEGMENT,
CAMPAIGN_ID,
SOURCE,
CAMPAIGN_PRODUCT,
MEDIUM,
REFERENCE_KEY,
AGE,
MARITAL_STATUS,
HAS_CREDITCARD,
HAS_CHILDREN,
NO_OF_CHILDREN,
GENDER,
INCOME,
DISTRICT,
PROVINCE,
ZIPCODE,
POLICY_NUMBER,
PRODUCT_CODE,
DOB,
Cast(PREMIUM AS BIGINT),
BILLING_MODE,
OCCUPATION_GROUP,
OCCUPATION_NAME,
OCCUPATION_CLASS,
PAYMENT_METHOD,
PROMO_CODE,
UTM_SOURCE,
UTM_MEDIUM,
UTM_CAMPAIGN,
SOURCE_SYSTEM 
From dev_ainbo_gold.vw_campaign_ainbo_demographics
order by OFFER_KEY

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_demographics

-- COMMAND ----------


DESCRIBE dev_ainbo_gold.vw_campaign_ainbo_demographics

-- COMMAND ----------

select POLICY_NUMBER,
PRODUCT_CODE,
DOB,
PREMIUM,
BILLING_MODE,
OCCUPATION_GROUP,
OCCUPATION_NAME,
OCCUPATION_CLASS,
PAYMENT_METHOD,
PROMO_CODE,
UTM_SOURCE,
UTM_MEDIUM,
UTM_CAMPAIGN,
SOURCE_SYSTEM 
From dev_ainbo_gold.vw_campaign_ainbo_demographics where source_system = "NON_NBM"

-- COMMAND ----------

select 
     l.datavalue_policyNumber AS POLICY_NUMBER,
    l.datavalue_productId AS PRODUCT_CODE,
    l.datavalue_premiumInfo_birthDate AS DOB,
    l.datavalue_premiumInfo_premium AS PREMIUM,
    l.datavalue_premiumInfo_paymentMode AS BILLING_MODE,
    l.datavalue_policyHolder_jobGroup AS OCCUPATION_GROUP,
    l.datavalue_policyHolder_jobName AS OCCUPATION_NAME,
    NULL AS OCCUPATION_CLASS,
    l.datavalue_paymentType AS PAYMENT_METHOD,
    l.datavalue_promoCode AS PROMO_CODE,
    l.datavalue_utmTracking_utmSource AS UTM_SOURCE,
    l.datavalue_utmTracking_utmMedium AS UTM_MEDIUM,
    l.datavalue_utmTracking_utmCampaign AS UTM_CAMPAIGN,
     'NON_NBM' AS SOURCE_SYSTEM
from 
      dev_silver_intermediate.nbo_silver as s
left join dev_silver_intermediate.nosql_data_entity_silver as l
on
      lower(l.datavalue_utmTracking_utmContent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string)

-- COMMAND ----------

--Query to Display NBM data records in the view

select POLICY_NUMBER,
PRODUCT_CODE,
DOB,
PREMIUM,
BILLING_MODE,
OCCUPATION_GROUP,
OCCUPATION_NAME,
OCCUPATION_CLASS,
PAYMENT_METHOD,
PROMO_CODE,
UTM_SOURCE,
UTM_MEDIUM,
UTM_CAMPAIGN,
SOURCE_SYSTEM 
From dev_ainbo_gold.vw_campaign_ainbo_demographics where source_system = "NBM"


-- COMMAND ----------

select 
     l.json_data_policies_3ci_policydetails_policyno AS POLICY_NUMBER,
    l.json_data_frontenddata_xsell_productcode AS PRODUCT_CODE,
    l.json_data_policyData_insuredLives[0].insuredDetails.dob AS DOB,
    l.json_data_frontenddata_xsell_premiumpaid AS PREMIUM,
     CASE WHEN 
     l.json_data_frontenddata_xsell_premiumpaid >    l.json_data_policyData_totalPremiums_monthly_afterGST_premium_beforeMarketingDis_beforeLoading 
     THEN 'YEARLY'
     ELSE 'MONTHLY'
     END
     AS
     BILLING_MODE,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationGroupName AS OCCUPATION_GROUP,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationName AS OCCUPATION_NAME,
     l.json_data_policyData_insuredLives[0].insuredDetails.occupationClass AS OCCUPATION_CLASS,
     l.json_data_policyData_selectedPayment_paymentTypes_paymentType AS PAYMENT_METHOD,
     l.json_data_others_promo AS PROMO_CODE,
     l.json_data_others_utmSource AS UTM_SOURCE,
     l.json_data_others_utmMedium AS UTM_MEDIUM,
     l.json_data_others_utmCampaign AS UTM_CAMPAIGN,
     'NBM' AS SOURCE_SYSTEM
from 
      dev_silver_intermediate.nbo_silver as s
left join  dev_silver_intermediate.users_data_silver as l
on
      lower(l.json_data_others_utmcontent) = lower(s.OFFER_KEY) 
      where date_format(s.udh_insert_timestamp,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string) 

-- COMMAND ----------

--qUERY TO cOMPARE nbo DATA IN VIEW WITH THE nbo INTERMITENT TABLES
(sELECT
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.OFFER_RANKING AS RANKING,
    s.OFFER_CUSTOMERSEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.CAMPAIGN_SOURCE AS CAMPAIGN_SOURCE,
    s.CAMPAIGN_PRODUCTS AS CAMPAIGN_PRODUCTS,
    s.CAMPAIGN_MEDIUM AS MEDIUM,
    s.PROFILE_REFERENCEKEY AS REFERENCE_KEY,
    s.PROFILE_AGE AS AGE,
    s.PROFILE_MARITALSTATUS AS MARITAL_STATUS,
    s.PROFILE_HASCREDITCARD AS HAS_CREDITCARD,
    s.PROFILE_HASCHILDREN AS HAS_CHILDREN,
    s.PROFILE_NUMBEROFCHILDREN AS NUMBER_OF_CHILDREN,
    s.PROFILE_GENDER AS GENDER,
    s.PROFILE_INCOME AS INCOME,
    s.PROFILE_ADDRESS_DISTRICT AS DISTRICT,
    s.PROFILE_ADDRESS_PROVINCE AS PROVINCE,
    s.PROFILE_ADDRESS_ZIPCODE AS ZIPCODE from dev_silver_intermediate.nbo_silver as s
ORDER BY S.OFFER_KEY)

EXCEPT

(SELECT ID, OFFER_KEY,RANKING,CUSTOMER_SEGMENT,CAMPAIGN_ID,SOURCE,CAMPAIGN_PRODUCT,
MEDIUM,REFERENCE_KEY,AGE,MARITAL_STATUS,HAS_CREDITCARD,HAS_CHILDREN,
NO_OF_CHILDREN,GENDER,INCOME,DISTRICT,PROVINCE,ZIPCODE
FROM dev_ainbo_gold.vw_campaign_ainbo_demographics
ORDER BY OFFER_KEY)

-- COMMAND ----------

sELECT
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.OFFER_RANKING AS RANKING,
    s.OFFER_CUSTOMERSEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.CAMPAIGN_SOURCE AS CAMPAIGN_SOURCE,
    s.CAMPAIGN_PRODUCTS AS CAMPAIGN_PRODUCTS,
    s.CAMPAIGN_MEDIUM AS MEDIUM,
    s.PROFILE_REFERENCEKEY AS REFERENCE_KEY,
    s.PROFILE_AGE AS AGE,
    s.PROFILE_MARITALSTATUS AS MARITAL_STATUS,
    s.PROFILE_HASCREDITCARD AS HAS_CREDITCARD,
    s.PROFILE_HASCHILDREN AS HAS_CHILDREN,
    s.PROFILE_NUMBEROFCHILDREN AS NUMBER_OF_CHILDREN,
    s.PROFILE_GENDER AS GENDER,
    s.PROFILE_INCOME AS INCOME,
    s.PROFILE_ADDRESS_DISTRICT AS DISTRICT,
    s.PROFILE_ADDRESS_PROVINCE AS PROVINCE,
    s.PROFILE_ADDRESS_ZIPCODE AS ZIPCODE from dev_silver_intermediate.nbo_silver as s
ORDER BY S.OFFER_KEY

-- COMMAND ----------

select OFFER_KEY, MARITAL_STATUS,GENDER,INCOME,SOURCE_SYSTEM
FROM dev_ainbo_gold.vw_campaign_ainbo_demographics WHERE OFFER_KEY =
"51F32356-75AB-41DC-9102-913695623F85"

-- COMMAND ----------

select * from  dev_silver_intermediate.nbo_silver
 where OFFER_KEY = "51F32356-75AB-41DC-9102-913695623F85"
