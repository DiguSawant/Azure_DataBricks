-- Databricks notebook source
 -- Non NBM 
select count(*)from dev_initial_load_bronze.nosql_data_entity_bronze






-- COMMAND ----------

select * from dev_initial_load_bronze.nosql_data_entity_bronze
--where udh_batch_id = '20230405'

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver

-- COMMAND ----------



-- COMMAND ----------

--select count(*)from dev_initial_load_bronze.users_data 
select count(*) from dev_initial_load_bronze.users_data where Submitted_Date >= '2023-04-04' and

Submitted_Date <= '2023-04-05'



-- COMMAND ----------

select count(*) from dev_silver_intermediate.users_data_silver
where UDH_BATCH_ID = '20230405'

-- COMMAND ----------

describe dev_silver_intermediate.users_data_silver where UDH_BATCH_ID =

-- COMMAND ----------

select count(*)
from  qa_initial_load_bronze.users_data
where
  Submitted_Date >= '2023-04-04'
  and Submitted_Date <= '2023-04-05'



-- COMMAND ----------

select count(*) from qa_silver_intermediate.users_data_silver where UDH_BATCH_ID='20230406'

-- COMMAND ----------

select max(et_systemupdateddt) from qa_initial_load_bronze.nosql_data_entity_bronze
--where UDH_BATCH_ID='20230406' and et_systemupdateddt='2023-04-06T12:38:28.170+0000'
'

-- COMMAND ----------

select distinct ET_ENTITYSEQ from qa_initial_load_bronze.nosql_data_entity_bronze 

-- COMMAND ----------

select   ET_ENTITYSEQ , count (*) from qa_silver_intermediate.nosql_data_entity_silver GROUP BY  ET_ENTITYSEQ

--where UDH_BATCH_ID='20230406'

-- COMMAND ----------

select count(*) from qa_initial_load_bronze.nosql_data_entity_bronze

-- COMMAND ----------

select aes_decrypt(Json_Data)
from  qa_initial_load_bronze.users_data where id = 9916

-- COMMAND ----------

-- MAGIC %run
-- MAGIC /Shared/udh_dom/tech_utility/aes

-- COMMAND ----------

select after_ID,json_data_frontenddata_xsell_policyholder_email,json_data_frontenddata_xsell_policyholder_fullname,json_data_frontenddata_amlrequest_idcardnumber,json_data_frontenddata_xsell_policyholder_mobile,json_data_policydata_insuredlives_insuredDetails_dob,json_data_policydata_insuredlives_insuredDetails_gender,json_data_policydata_insuredlives_insuredDetails_occupationClass,json_data_policydata_insuredlives_insuredDetails_occupationName,json_data_policydata_insuredlives_insuredDetails_title,json_data_policydata_insuredlives_insuredDetails_lastName,json_data_policydata_insuredlives_insuredDetails_firstName,json_data_policydata_insuredlives_insuredDetails_fullName,json_data_policydata_insuredlives_insuredDetails_postalCode,json_data_policydata_insuredlives_insuredDetails_provinceCd,json_data_policydata_insuredlives_insuredDetails_countryOfResidence,json_data_policydata_insuredlives_insuredDetails_districtCd,json_data_policydata_insuredlives_insuredDetails_address4,json_data_policydata_insuredlives_insuredDetails_address3,json_data_policydata_insuredlives_insuredDetails_address2,json_data_policydata_insuredlives_insuredDetails_address1 from qa_silver_intermediate.users_data_silver 
-- where after_id='KNJw/QqQAaMDCj9nzb98Dw=='



-- COMMAND ----------

select * from qa_silver_intermediate.nosql_data_entity_silver
where ET_ENTITYSEQ = 1033730

-- COMMAND ----------

select aes_decrypt(dt_datavalue) from qa_initial_load_bronze.nosql_data_entity_bronze 
where 
et_entityseq = 1033721


--qa_silver_intermediate.nosql_data_entity_silver


-- COMMAND ----------

select 
dt_entityseq,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName,datavalue_policyHolder_title,datavalue_policyHolder_jobName,datavalue_policyHolder_jobGroup,datavalue_premiumInfo_gender,datavalue_premiumInfo_birthDate,datavalue_policyHolder_status,datavalue_policyHolder_mobileNumber,datavalue_identity_idCard,datavalue_policyHolder_email,datavalue_icp_accountNumber,datavalue_icp_accountName,datavalue_addresses_current_province,datavalue_addresses_current_zip,datavalue_addresses_current_houseNumber,datavalue_addresses_current_village,datavalue_addresses_current_road,datavalue_addresses_current_subDistrict,datavalue_addresses_current_district,datavalue_addresses_workplace_province,datavalue_addresses_workplace_zip,datavalue_addresses_workplace_houseNumber,datavalue_addresses_workplace_village,datavalue_addresses_workplace_road,datavalue_addresses_workplace_subDistrict,datavalue_addresses_workplace_district,datavalue_addresses_home_province,datavalue_addresses_home_zip,datavalue_addresses_home_houseNumber,datavalue_addresses_home_village,datavalue_addresses_home_road,datavalue_addresses_home_subDistrict,datavalue_addresses_home_district
from dev_silver_intermediate.nosql_data_entity_silver
--where ET_ENTITYSEQ = 1033730
where ET_ENTITYSEQ = 1033721



-- COMMAND ----------

select 
dt_entityseq,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName,datavalue_policyHolder_title,datavalue_policyHolder_jobName,datavalue_policyHolder_jobGroup,datavalue_premiumInfo_gender,datavalue_premiumInfo_birthDate,datavalue_policyHolder_status,datavalue_policyHolder_mobileNumber,datavalue_identity_idCard,datavalue_policyHolder_email,datavalue_icp_accountNumber,datavalue_icp_accountName,datavalue_addresses_current_province,datavalue_addresses_current_zip,datavalue_addresses_current_houseNumber,datavalue_addresses_current_village,datavalue_addresses_current_road,datavalue_addresses_current_subDistrict,datavalue_addresses_current_district,datavalue_addresses_workplace_province,datavalue_addresses_workplace_zip,datavalue_addresses_workplace_houseNumber,datavalue_addresses_workplace_village,datavalue_addresses_workplace_road,datavalue_addresses_workplace_subDistrict,datavalue_addresses_workplace_district,datavalue_addresses_home_province,datavalue_addresses_home_zip,datavalue_addresses_home_houseNumber,datavalue_addresses_home_village,datavalue_addresses_home_road,datavalue_addresses_home_subDistrict,datavalue_addresses_home_district
from qa_silver_intermediate.nosql_data_entity_silver
--where ET_ENTITYSEQ = 1033730



-- COMMAND ----------

