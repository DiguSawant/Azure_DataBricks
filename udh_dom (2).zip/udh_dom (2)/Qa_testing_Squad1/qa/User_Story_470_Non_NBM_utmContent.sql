-- Databricks notebook source
-- 470 Non NBM Quote RAW

select dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent, count(*) from dev_silver_intermediate.nosql_data_entity_silver where et_application ='ECOMMERCE' and et_entityname = 'SAVESTAGE' and lower(dt_datavalue_health_hasOtherInsurance) IS NULL and lower(dt_datavalue_isOtpVerify) IS NULL and dt_datavalue_premiumInfo_birthDate IS NOT NULL and dt_datavalue_productId in ('E60A1', 'T12A')
group by dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent



--select count (*) from silver_intermediate.nosql_data_entity where et_appliactaion='ECOMMERCE' and et_entityname= 'SAVESTAGE' and dt_datavalue_healthOtherInsurance is NULL and dt_datavalue_isOtpVerify  is NULL and dt_datavalue_premiunInfo_birthDate is NOT NULL and  dt_datavalue_productId in('E60A1') 

--dt_datavalue_utmTracking_utmContent

-- COMMAND ----------

--trial Qoute

select  count(*) from dev_silver_intermediate.nosql_data_entity_silver where et_application ='ECOMMERCE' and et_entityname = 'SAVESTAGE' and lower(dt_datavalue_health_hasOtherInsurance) IS NULL and lower(dt_datavalue_isOtpVerify) IS NULL and dt_datavalue_premiumInfo_birthDate IS NOT NULL and dt_datavalue_productId in ('E60A1', 'T12A')




-- COMMAND ----------

Desc

-- COMMAND ----------

select * from dev_ainbo_silver.quote_silver where source_system = 'non_nbm'

-- COMMAND ----------

select * from dev_ainbo_silver.vw_campaign_ainbo_conversion where source_system = 'non_nbm'

-- COMMAND ----------

---RAW Summmary  Non NBM

select dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent, count(*) from dev_silver_intermediate.nosql_data_entity_silver
where dt_datavalue_policyNumber  IS NOT NULL
and dt_datavalue_paymentType IS Null
and dt_datavalue_productId = 'E60A1'
group by dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent


-- COMMAND ----------

select * from dev_ainbo_silver.summary_silver where source_system = 'non_nbm'

-- COMMAND ----------

select * from dev_ainbo_silver.vw_campaign_ainbo_conversion where source_system = 'non_nbm'
and funnel_stage = 'summary'

-- COMMAND ----------

--payment RAW

select dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent,count(*) from dev_silver_intermediate.nosql_data_entity_silver
where  dt_datavalue_paymentType IS NOT  Null
and dt_datavalue_isPaymentComplete IS Null
and dt_datavalue_policyNumber  IS NOT NULL
and dt_datavalue_productId = 'E60A1'
and et_application='ECOMMERCE'
and et_entityname= 'SAVESTAGE'
group by dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent






-- COMMAND ----------

select * from dev_ainbo_silver.payment_silver where source_system = 'non_nbm'

-- COMMAND ----------

select * from dev_ainbo_silver.vw_campaign_ainbo_conversion where source_system = 'non_nbm'
and funnel_stage = 'payment'

-- COMMAND ----------

select count(*) from dev_silver_intermediate.nosql_data_entity_silver
where  dt_datavalue_paymentType IS NOT  Null
and dt_datavalue_isPaymentComplete IS Null
and dt_datavalue_policyNumber  IS NOT NULL
and dt_datavalue_productId = 'E60A1'
and et_application='ECOMMERCE'
and et_entityname= 'SAVESTAGE'


-- COMMAND ----------


--- trial
select * from dev_silver_intermediate.nosql_data_entity_silver
where  dt_datavalue_paymentType IS NOT  Null
and dt_datavalue_isPaymentComplete IS Null
and dt_datavalue_policyNumber  IS NOT NULL
and dt_datavalue_productId = 'E60A1'


-- COMMAND ----------

--Success RAW

select dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent,count(*) from dev_silver_intermediate.nosql_data_entity_silver
where dt_datavalue_isPaymentComplete = 'true'
and dt_datavalue_productId = 'E60A1'
group by dt_datavalue_productId ,dt_datavalue_utmTracking_utmContent

-- COMMAND ----------

select * from dev_ainbo_silver.success_silver where source_system = 'non_nbm'

-- COMMAND ----------

select * from dev_ainbo_silver.vw_campaign_ainbo_conversion where source_system = 'non_nbm'
and funnel_stage = 'success'