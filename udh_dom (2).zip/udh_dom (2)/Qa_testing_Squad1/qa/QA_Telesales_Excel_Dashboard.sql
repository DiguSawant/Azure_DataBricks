-- Databricks notebook source

--Intermediate table pointing of RAW
select * from dev_telesales_silver.telesales_silver
-- where CellPhone=0915575666

-- COMMAND ----------

select package,PartnerName as  Source_System,count(*)
from dev_telesales_silver.telesales_silver
Group By package,PartnerName


-- COMMAND ----------


--Leads received
select * from dev_telesales_silver.leads_received 

-- COMMAND ----------

--Leads passed to Tele Sales
select * from dev_telesales_silver.leads_passed_to_telesales;

-- COMMAND ----------

select * from dev_telesales_silver.sum_ape

-- COMMAND ----------

select * from dev_telesales_silver.total_leads_passed_telesales

-- COMMAND ----------

select * from dev_telesales_silver.cust_sold_sum_ape_policy

-- COMMAND ----------

select * from dev_telesales_gold.vw_telesales_conversion

-- COMMAND ----------


--Leads received
select PACKAGE,sum(count) from dev_telesales_silver.leads_received GROUP BY PACKAGE;

-- COMMAND ----------

select * from sorDB_view limit 20

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####AFTER INSERTING SAMPLE4
-- MAGIC

-- COMMAND ----------

-- MAGIC %run /udh_dom/tech_utility/aes

-- COMMAND ----------


--Leads received
select * from dev_telesales_silver.leads_received 

-- COMMAND ----------

--Leads passed to Tele Sales
select * from dev_telesales_silver.leads_passed_to_telesales;

-- COMMAND ----------

select * from dev_telesales_silver.total_leads_passed_telesales

-- COMMAND ----------

select * from dev_telesales_silver.cust_sold_sum_ape_policy

-- COMMAND ----------

select * from dev_telesales_gold.vw_telesales_conversion