-- Databricks notebook source
--Story 401 Non NBM Quote in RAW
select count(*) from silver_intermediate.nosql_data_entity where et_application = 'ECOMMERCE' and et_entityname = 'SAVESTAGE' and dt_datavalue_health_hasOtherInsurance IS NULL and dt_datavalue_isOtpVerify IS NULL and dt_datavalue_premiumInfo_birthDate IS NOT NULL and dt_datavalue_productId in ('E60A1','T12A');

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver where et_application = 'ECOMMERCE' and et_entityname = 'SAVESTAGE' limit 10

-- COMMAND ----------

select * from dev_silver_intermediate.nosql_data_entity_silver

-- COMMAND ----------

select sum(count) from ainbo_silver.quote where source_system='non_nbm';

-- COMMAND ----------

select dt_entityseq,dt_dataseq,dt_datavalue_health_hasOtherInsurance,dt_datavalue_isOtpVerify ,dt_datavalue_premiumInfo_birthDate from silver_intermediate.nosql_data_entity 
where dt_datavalue_premiumInfo_birthDate IS  NOT Null 
and dt_datavalue_health_hasOtherInsurance IS Null
and dt_datavalue_isOtpVerify IS Null limit 2

-- COMMAND ----------

--story 402 Health Q

select count(*) from silver_intermediate.nosql_data_entity 
where dt_datavalue_health_height  IS NOT NULL
and dt_datavalue_health_hasOtherInsurance IS NOT NULL
and dt_datavalue_health_weight IS NOT Null
and dt_datavalue_isFatcaPass = 'false'



-- COMMAND ----------

-- story 403 personal info count

--dt_datavalue_policyHolder_mobileNumber

select count(*) from silver_intermediate.nosql_data_entity 
where dt_datavalue_policyHolder_mobileNumber  IS NOT NULL
and dt_datavalue_isOtpVerify = 'false'
and dt_datavalue_health_hasOtherInsurance IS  NULL

-- COMMAND ----------

--403 Personal Info
select dt_entityseq,dt_dataseq,dt_datavalue_health_hasOtherInsurance,dt_datavalue_isOtpVerify ,dt_datavalue_policyHolder_mobileNumber from silver_intermediate.nosql_data_entity 
where dt_datavalue_policyHolder_mobileNumber  IS NOT NULL
and dt_datavalue_isOtpVerify = 'false'
and dt_datavalue_health_hasOtherInsurance IS  NULL

-- COMMAND ----------

-- 404 Non NBM Summary
--dt_datavalue_policyNumber
--
--Policy number should not be null

---Payment Type value should be null

select count(*) from silver_intermediate.nosql_data_entity 
where dt_datavalue_policyNumber  IS NOT NULL
and dt_datavalue_paymentType IS Null




-- COMMAND ----------

--story 402 Health Q

select dt_datavalue_isFatcaPass , dt_datavalue_health_height,dt_datavalue_health_hasOtherInsurance,dt_datavalue_health_weight from silver_intermediate.nosql_data_entity 
where dt_datavalue_health_height  IS NOT NULL
--and dt_datavalue_health_hasOtherInsurance IS NOT NULL
and dt_datavalue_health_weight IS NOT Null
and dt_datavalue_isFatcaPass = 'false' 
limit 2

-- COMMAND ----------

--- 405 Payment stage
--Policy number 
--'& Payment Type should not be null

---Payment Complete flag should be null

select count(*) from silver_intermediate.nosql_data_entity 
where  dt_datavalue_paymentType IS NOT  Null
and dt_datavalue_isPaymentComplete IS Null
and dt_datavalue_policyNumber  IS NOT NULL





-- COMMAND ----------

--Story 406 Non NBM Sucess in RAW

select count(*) from silver_intermediate.nosql_data_entity 
where dt_datavalue_isPaymentComplete = 'true'


-- COMMAND ----------

 select * from dev_silver_intermediate.nosql_data_entity_silver
--where dt_datavalue_isPaymentComplete = 'true'and dt_datavalue_productId in ('E60A1','T12A');

-- COMMAND ----------

select * from ainbo_silver.health_question

-- COMMAND ----------

select * from ainbo_silver.personal_info where source_system = 'non_nbm'

-- COMMAND ----------

--select * from ainbo_silver.summary where source_system = 'non_nbm'

select * from ainbo_silver.summary 

-- COMMAND ----------

select * from ainbo_silver.payment where source_system = 'non_nbm'

-- COMMAND ----------

--select * from dev_ainbo_silver.success_silver where source_system = 'non_nbm'
select * from dev_ainbo_silver.success_silver

-- COMMAND ----------

