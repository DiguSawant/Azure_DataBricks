-- Databricks notebook source
--rahal query intermdiate fr NBM
DESC TABLE dev_silver_intermediate.users_data_silver

-- COMMAND ----------

----rahal query intermdiate fr NBM
SELECT * from  dev_silver_intermediate.users_data_silver LIMIT 10

-- COMMAND ----------

--vivek query
select * from dev_silver.users_data_silver

-- COMMAND ----------

--vivek latest for NBM

DESC TABLE dev_silver.users_data_silver

-- COMMAND ----------

SELECT * from  dev_silver.users_data_silver LIMIT 20

-- COMMAND ----------

--for Non NBM
DESC TABLE dev_silver.nosql_data_entity_silver

-- COMMAND ----------

SELECT * from  dev_silver.nosql_data_entity_silver LIMIT 100

-- COMMAND ----------

SELECT * from  dev_silver.nosql_data_entity_silver where DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_CIPACKAGE
IS NOT NULL

-- COMMAND ----------

