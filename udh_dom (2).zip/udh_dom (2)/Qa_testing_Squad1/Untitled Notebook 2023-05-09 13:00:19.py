# Databricks notebook source
select * from table 1

# COMMAND ----------

select count(*) from table 2

# COMMAND ----------

