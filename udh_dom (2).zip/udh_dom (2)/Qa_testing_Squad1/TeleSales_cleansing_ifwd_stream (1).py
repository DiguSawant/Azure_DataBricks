# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ./config

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/aes

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run ./common_utility

# COMMAND ----------

# DBTITLE 1,running notebook others_file
# MAGIC %run ./others_file

# COMMAND ----------

# DBTITLE 1,running notebook join_sorDB
# MAGIC %run ./join_sorDB

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

# DBTITLE 1,importing requireds
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,read the data from given source location
try:
    ifwd_df = spark.readStream\
                         .format("delta")\
                         .load('/mnt/fwd_test/prashant_dev_1/telesales/silver_data/udh_batch_id=20230428/')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# select columns and decrypt caloumns datavalue
try:
    ifwd_df = ifwd_df.select("ET_ENTITYSEQ","ET_ENTITYNAME","ET_INDEXKEY","ET_SORTKEY","ET_VERSIONID","ET_GUID","ET_APPLICATION","ET_SYSTEMCREATEDDT","ET_SYSTEMUPDATEDDT","DT_DATASEQ","DT_ENTITYSEQ","DT_DATAKEY","DT_DATAVALUE","DT_VERSIONID","DT_GUID").withColumn("DT_DATAVALUE", aes_decrypt("DT_DATAVALUE"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate CellPhone 
try:
    drop_df = ifwd_df.filter(col("DT_DATAKEY")=="CELLPHONE").dropDuplicates(["DT_DATAVALUE"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# rename column of drop_df to avoid ambiguity
for i in drop_df.columns:
    drop_df = drop_df.withColumnRenamed(i,i+"_1")

# COMMAND ----------

try:
    # create temporary view of ifwd_df
    ifwd_df.createOrReplaceTempView("ifwd_vw")
    #  create temporary view of drop_df
    drop_df.createOrReplaceTempView("drop_vw")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join ifwd_vw and drop_vw to select distinct record
try:
    join_df = spark.sql("""select * from ifwd_vw i join drop_vw d on i.ET_ENTITYSEQ = d.ET_ENTITYSEQ_1 where i.ET_ENTITYSEQ = d.ET_ENTITYSEQ_1""")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# query to get the selected columns
try:
    # create temp view 
    join_df.createOrReplaceTempView("temp_vw")

    # query to get data for true leads
    telesales_df = spark.sql(""" 
    SELECT * from(select  b.ET_SYSTEMCREATEDDT as LeadCreateDate
    , max( case b.DT_DATAKEY when 'USERID' then b.DT_DATAVALUE else NULL end)                         as UserId
    , max( case b.DT_DATAKEY when 'CONSENTCHECKEDDATE' then b.DT_DATAVALUE else NULL end)             as ConsentCheckedDate
    , max( case b.DT_DATAKEY when 'EMAIL' then b.DT_DATAVALUE else NULL end)                          as Email
    , max( case b.DT_DATAKEY when 'FIRSTNAME' then b.DT_DATAVALUE else NULL end)                      as FirstName
    , max( case b.DT_DATAKEY when 'CELLPHONE' then b.DT_DATAVALUE else NULL end)                      as CellPhone
    , max( case b.DT_DATAKEY when 'PARTNERNAME' then b.DT_DATAVALUE else NULL end)                    as PartnerName
    , max( case b.DT_DATAKEY when 'CONSENTCHECKBOX' then b.DT_DATAVALUE else NULL end)                as ConsentCheckBox
    , max( case b.DT_DATAKEY when 'SOURCE' then b.DT_DATAVALUE else NULL end)                         as Source
    , max( case b.DT_DATAKEY when 'DTCCAMPAIGNID' then b.DT_DATAVALUE else NULL end)                  as DTCCampaignId
    , max( case b.DT_DATAKEY when 'CONSENTVERSIONCD' then b.DT_DATAVALUE else NULL end)               as ConsentVersionCd
    , max( case b.DT_DATAKEY when 'CONSENTMSG' then b.DT_DATAVALUE else NULL end)                     as ConsentMsg
    , max( case b.DT_DATAKEY when 'LASTNAME' then b.DT_DATAVALUE else NULL end)                       as LastName
    , max( case b.DT_DATAKEY when 'REQUIREULLICENSE' then b.DT_DATAVALUE else NULL end)               as RequireULLicense
    , max( case b.DT_DATAKEY when 'BIRTHDATE' then b.DT_DATAVALUE else NULL end)               as BirthDate
    , max( case b.DT_DATAKEY when 'SEX' then b.DT_DATAVALUE else NULL end)               as Sex
    from temp_vw b group by b.ET_ENTITYSEQ, b.ET_SYSTEMCREATEDDT)
    where DTCCampaignId in ('TrueSenior-All-001-01032023', 'TrueSpecialDay-All-001-01032023', 'TrueVas-All-001-01032023')
""")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

n_schema = StructType([StructField('LeadCreateDate', TimestampType(), True), StructField('UserId', StringType(), True), StructField('ConsentCheckedDate', TimestampType(), True), StructField('Email', StringType(), True), StructField('FirstName', StringType(), True), StructField('CellPhone', IntegerType(), True), StructField('PartnerName', BooleanType(), True), StructField('ConsentCheckBox', StringType(), True), StructField('Source', IntegerType(), True), StructField('DTCCampaignId', StringType(), True), StructField('ConsentVersionCd', StringType(), True), StructField('ConsentMsg', StringType(), True), StructField('LastName', StringType(), True), StructField('RequireULLicense', StringType(), True), StructField('birthDate', StringType(), True), StructField('Sex', StringType(), True)])

# COMMAND ----------

csv_df = spark.readStream.format("csv").schema(n_schema).load("/mnt/fwd_test/prashant_dev_1/telesales/csv/")

# COMMAND ----------

csv_df.display()

# COMMAND ----------

csv_df = csv_df.filter(col("LeadCreateDate").isNotNull())

# COMMAND ----------

csv_df = csv_df.dropDuplicates(["CellPhone"])

# COMMAND ----------

# DBTITLE 1,drop if all the null fields
try:
    telesales_df = csv_df.dropna(how='all')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,trim the fileds using trim_fields function
try:
    trim_df = trim_fields(df=telesales_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,normalize the columns(replacing dot,hyphen,and spaces by underscore)
try:
    normalize_df = normalize_column_name(trim_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,drop the duplicates for given column--phone_no and name
try:
    normalize_df = normalize_df.withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-",""))\
                               .withColumn("Package",split(col("DTCCampaignId"),'-')[0])\
                                .withColumn("file_date",split(col("DTCCampaignId"),'-')[3])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,calculate the age on given column and format
# try:
#     age_df = age_calculation(df=normalize_df,column=sheet_2_dob, date_format=sheet_2_date_format)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,filter the age between 20 and 60
# try:
#     filtered_sheet_2_df = age_df.where(col(sheet_2_age).between(20, 60))
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,apply the data quality rule for phone_no and email
try:
    dq_df = normalize_df.where((udf_check_phone_number(sheet_2_phone_no, lit(mobilecode_list_str))==True))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,concating the FirstName and LastName as FullName and format column CellPhone
try:
    # file_date = extract_date(sheet_2_file_path)
    concated_sheet_2_df = dq_df.withColumn(sheet_2_fullName, concat_ws(' ',sheet_2_firstName,sheet_2_lastName))\
                                       .withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing contacted_df from others_file
try:
    # joining the dataframe to drop the matching records with contacted dataframe
    sheet_2_contacted_df = concated_sheet_2_df.join(contacted_df, concated_sheet_2_df.
                                                    FullName == contacted_df.FullName, "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing blacklist_df from others_file
try:
    # joining the dataframe to drop the matching records with blacklist dataframe
    sheet_2_blacklist_df = sheet_2_contacted_df.join(blacklist_df, (sheet_2_contacted_df.UserId == blacklist_df.national_id) 
                                                     | (sheet_2_contacted_df.FullName == blacklist_df.FullName), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# importing dnc_df from others_file
try:
    # joining the dataframe to drop the matching records with do-not-call-list dataframe 
    sheet_2_dnc_df = sheet_2_blacklist_df.join(dnc_df, (sheet_2_blacklist_df.UserId == dnc_df.national_id) 
                                               | (sheet_2_blacklist_df.FullName == dnc_df.FullName) 
                                               | (sheet_2_blacklist_df.CellPhone == dnc_df.phone_no), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_dnc_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    sheet_2_sordb = sheet_2_dnc_df.join(sorDB_Df, sheet_2_dnc_df.UserId == sorDB_Df.owner_national_id, 'anti')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read telesales data 
try:
    telesale_source_path_json = "/mnt/fwd_test/prashant_dev_1/telesales/output/data/telesales/"
    telesales_system_df = read_json(location = telesale_source_path_json, multiline=False)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # joining the dataframe to drop the matching records with teleSystem dataframe
    sheet_2_telesales_system_df = sheet_2_sordb.join(telesales_system_df, sheet_2_sordb.CellPhone == telesales_system_df.CellPhone, 'anti').withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_dnc_df and sorDB_Df
#importing the sorDB_existing_cust_check from join_sorDB notebook
try:
    sheet_2_sordb_existing_cust = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'semi').withColumn("Remark",lit("Existing FWD customer "))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write existing leads
try:
    write_stream(df=sheet_2_sordb_existing_cust,file_format="delta", mode="append", checkpoint_location="/mnt/fwd_test/prashant_dev_1/telesales/output/chk/ext_lead/", path="/mnt/fwd_test/prashant_dev_1/telesales/output/data/ext_lead/", partitioncolumn=["udh_batch_id"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_contacted_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    sheet_2_sordb_1 = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'anti').withColumn("Remark",lit("null"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write new leads
try:
    write_stream(df=sheet_2_sordb_1,file_format="delta", mode="append", checkpoint_location="/mnt/fwd_test/prashant_dev_1/telesales/output/chk/lead/", path="/mnt/fwd_test/prashant_dev_1/telesales/output/data/lead/", partitioncolumn=["udh_batch_id"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    ext_leads = spark.readStream.format("delta").load("/mnt/fwd_test/prashant_dev_1/telesales/output/data/ext_lead/")
    leads = spark.readStream.format("delta").load("/mnt/fwd_test/prashant_dev_1/telesales/output/data/lead/")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# union spark dataframe 
try:
    union_df = ext_leads.unionByName(leads, allowMissingColumns=True)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    union_df = union_df.withColumn("partition_date",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    sheet_2_parttion_df = union_df.distinct()
# #select the required column using col_standarization method
    sheet_2_standDf = col_standarization(df = sheet_2_parttion_df, columns = json_col_standarization)
    select_cols_df = sheet_2_standDf.select(*select_columns, "partition_date")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

def foreachFun(df, epoch_id):
    grouped_df = df.groupBy("partition_date")\
                    .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","BirthDate","Remark"))\
                    .alias("DTCOutToTSR"))
    write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = "/mnt/fwd_test/prashant_dev_1/telesales/output/data/telesales1/", mode="append", partitionColumn=["partition_date"])

# COMMAND ----------

try:
    select_cols_df.writeStream.outputMode("append").foreachBatch(foreachFun).option("checkpointLocation","/mnt/fwd_test/prashant_dev_1/telesales/output/chk/telesales1/010523_2").start()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# define current date and time
from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

# get current timestamp
try:
    cur_time = spark.sql("SELECT current_timestamp()").collect()[0][0]
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    normalize_df.groupBy("DTCCampaignId")\
        .count()\
        .withColumn("Package",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("SOURCE_SYSTEM",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("UDH_INSERT_TIMESTAMP",current_timestamp())\
        .withColumn("BATCH_ID",lit(curr_date))\
        .writeStream.format("delta")\
        .outputMode("complete")\
        .option("checkpointLocation","/mnt/fwd_test/prashant_dev_1/telesales/output/chk/lead_received1/")\
        .toTable("dev_telesales_silver.ifwd_leads_received")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql SELECT * from dev_telesales_silver.ifwd_leads_received

# COMMAND ----------

try:
    sheet_2_standDf.groupBy("DTCCampaignId")\
        .count()\
        .withColumn("Package",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("SOURCE_SYSTEM",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("UDH_INSERT_TIMESTAMP",current_timestamp())\
        .withColumn("BATCH_ID",lit(curr_date))\
        .writeStream.format("delta")\
        .outputMode("complete")\
        .option("checkpointLocation","/mnt/fwd_test/prashant_dev_1/telesales/output/chk/lead_passed/")\
        .toTable("dev_telesales_silver.ifwd_passed_to_telesales")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql SELECT * from dev_telesales_silver.ifwd_passed_to_telesales

# COMMAND ----------

try:
    sheet_2_standDf\
            .select("UserId","LeadCreateDate","DTCCampaignId")\
            .withColumn("Package",lit(split(col('DTCCampaignId'),'-')[0]))\
            .withColumn("UDH_CUST_FIND_TIME",lit(None).cast(TimestampType()))\
            .withColumn("SOURCE_SYSTEM",lit(split(col('DTCCampaignId'),'-')[0]))\
            .withColumn("UDH_INSERT_TIMESTAMP",current_timestamp())\
            .withColumn("BATCH_ID",lit(curr_date))\
            .writeStream.format("delta")\
            .outputMode("append")\
            .option("checkpointLocation","/mnt/fwd_test/prashant_dev_1/telesales/output/chk/total_lead_passed/")\
            .toTable("dev_telesales_silver.ifwd_total_leads_passed_telesales")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql select * from dev_telesales_silver.ifwd_total_leads_passed_telesales

# COMMAND ----------

spark.readStream.format("delta").table("dev_telesales_silver.ifwd_total_leads_passed_telesales").createOrReplaceTempView("temp_2")

# COMMAND ----------

try:
    count_cust_sold_policy = spark.sql("""
                                    select t.Package,t.DTCCampaignId as DTCCampaignId,count(*) as COUNT,
                                    cast(sum(next_premium_amt*billing_frequency_code) as DECIMAL(38,2)) as SUM
                                    from temp_2 t
                                    join sorDB_view as s
                                    on t.UserId = s.owner_national_id
                                    where s.date<=to_date(LeadCreateDate)
                                    and t.udh_cust_find_time IS NULL
                                    GROUP BY t.Package,t.DTCCampaignId
                                    """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    count_cust_sold_policy.withColumn("Package",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("SOURCE_SYSTEM",lit(split(col('DTCCampaignId'),'-')[0]))\
        .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
        .withColumn("BATCH_ID",lit(curr_date))\
        .writeStream.format("delta")\
        .outputMode("complete")\
        .option("checkpointLocation","/mnt/fwd_test/prashant_dev_1/telesales/output/chk/cust_sold_policy/")\
        .toTable("dev_telesales_silver.ifwd_cust_sold_policy_1")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql select * from dev_telesales_silver.ifwd_cust_sold_policy

# COMMAND ----------

# merge total_leased_passed using sorDB_view to get update of udh_cust_find_time if any
try:
    spark.sql(f"""
        MERGE INTO dev_telesales_silver.ifwd_total_leads_passed_telesales t 
        USING (select distinct owner_national_id from sorDB_view s join dev_telesales_silver.ifwd_total_leads_passed_telesales t on t.UserId = s.owner_national_id  where s.date>=to_date(t.LeadCreateDate)) m 
        ON t.UserId = m.owner_national_id
        WHEN MATCHED THEN UPDATE 
        SET udh_cust_find_time = '{cur_time}'
        """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql select * from dev_telesales_silver.ifwd_total_leads_passed_telesales

# COMMAND ----------

# create view telesales_conversion
spark.sql(f"""
create or replace view dev_telesales_gold.vw_telesales_conversion_ifwd as 
SELECT 
      l.Package as PACKAGE,
      sum(l.count) as NO_RECEIVED_LEADS,
      sum(p.count) as NO_LEADS_PASSED,
      sum(c.count) as NO_POLICY_SOLD,  
      cast((sum(c.count)*100/sum(p.count)) as decimal(5,2)) as CONVERSION_RATE,
      sum(c.SUM) as APE 
FROM dev_telesales_silver.ifwd_leads_received l
left JOIN dev_telesales_silver.ifwd_passed_to_telesales p
on l.Package = p.Package
left JOIN dev_telesales_silver.ifwd_cust_sold_policy c
ON l.Package = c.Package
GROUP BY l.Package
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC       l.Package as PACKAGE,
# MAGIC       sum(l.count) as NO_RECEIVED_LEADS,
# MAGIC       sum(p.count) as NO_LEADS_PASSED,
# MAGIC       sum(c.count) as NO_POLICY_SOLD,  
# MAGIC       cast((sum(c.count)*100/sum(p.count)) as decimal(5,2)) as CONVERSION_RATE,
# MAGIC       sum(c.SUM) as APE 
# MAGIC FROM dev_telesales_silver.ifwd_leads_received l
# MAGIC left JOIN dev_telesales_silver.ifwd_passed_to_telesales p
# MAGIC on l.DTCCampaignId = p.DTCCampaignId
# MAGIC left JOIN dev_telesales_silver.ifwd_cust_sold_policy c
# MAGIC ON l.DTCCampaignId = c.DTCCampaignId
# MAGIC GROUP BY l.Package

# COMMAND ----------

# MAGIC %sql select * from dev_telesales_gold.vw_telesales_conversion_ifwd

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/aes

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.la_tb_agrt_coverage_curr_dim cov
# MAGIC join delta.la_tb_agrt_policy_curr_dim pol on  aes_decrypt(cov.policy_id) = aes_decrypt(pol.policy_id)
# MAGIC join delta.la_tb_pty_identity_curr_dim ident on pol.main_policy_owner_id = aes_decrypt(ident.party_id) limit 5

# COMMAND ----------

# insert data into success table
spark.sql(f"""
select DTCCampaignId,count,t4.Package,t4.
source_system,t4.ape ,((t3.VNB_PERCENT/100)*t4.ape) as vnb from dev_silver.vnb_rates_silver as t3
join( select * from dev_silver.vnb_channel_silver as t1
join (select DTCCampaignId,package, sum(SUM) as ape
from 
      dev_telesales_silver.ifwd_cust_sold_policy
group by 
      Package
) as t2 on t1.Partner_Name=t2.DATAVALUE_PARTNER
) as t4 on t3.Digital_Channel=t4.Digital_Channel and t3.Channel = "AD" and t3.Digital_Channel="DM Non-TMB"
""")

# COMMAND ----------

# MAGIC %sql select * from dev_telesales_gold.vw_telesales_conversion