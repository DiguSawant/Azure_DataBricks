-- Databricks notebook source
select * from dev_ainbo_silver.product_lookup_silver

-- COMMAND ----------

select * from dev_silver.nbo_silver where id='5499F011-1D56-415D-BE2B-E206A3B2ABB0'