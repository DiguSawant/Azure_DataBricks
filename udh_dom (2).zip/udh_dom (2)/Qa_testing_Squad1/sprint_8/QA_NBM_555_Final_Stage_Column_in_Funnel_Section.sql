-- Databricks notebook source
select JSON_DATA_OTHERS_UTMCONTENT from dummy_ainbo.nbm_sample_data

-- COMMAND ----------

--select * from dummy_ainbo.temp_nbm_view where OFFER_KEY like '%REFERRAL-CONTENT%';

select ID,OFFER_KEY,STAGE from dummy_ainbo.temp_nbm_view where OFFER_KEY like '%REFERRAL-CONTENT%' sort by OFFER_KEY,STAGE;



-- COMMAND ----------

--select * from dummy_ainbo.nbm_final_view
select ID,OFFER_KEY,STAGE from dummy_ainbo.nbm_final_view

-- COMMAND ----------

select ID,OFFER_KEY,STAGE from dummy_ainbo.demographics_vw

-- COMMAND ----------

select * from dummy_ainbo.nbm_sample_data

-- COMMAND ----------

select * from dev_ainbo_gold.vw_campaign_ainbo_demographics
where utm_content ='5499F011-1D56-415D-BE2B-E206A3B2ABB0'

-- COMMAND ----------

select DATAVALUE_POLICYNUMBER, DATAVALUE_PAYMENTTYPE,DATAVALUE_ISPAYMENTCOMPLETE
 from dev_silver.nosql_data_entity_silver where DATAVALUE_UTMTRACKING_UTMCONTENT='5499F011-1D56-415D-BE2B-E206A3B2ABB0'

-- COMMAND ----------

select DATAVALUE_POLICYNUMBER, DATAVALUE_PAYMENTTYPE,DATAVALUE_ISPAYMENTCOMPLETE
 from dev_silver.nosql_data_entity_silver where DATAVALUE_UTMTRACKING_UTMCONTENT ='REFERRAL-CONTENT-ABC5'