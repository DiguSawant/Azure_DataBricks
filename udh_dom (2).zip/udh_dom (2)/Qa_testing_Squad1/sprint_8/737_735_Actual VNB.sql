-- Databricks notebook source
select * from dev_silver.nosql_data_entity_silver where DATAVALUE_POLICYNUMBER= 'B11015791'

-- COMMAND ----------

-- MAGIC %sql select * from dev_silver.actual_vnb_silver where POLICY_NUMBER ='B11015791'

-- COMMAND ----------



-- COMMAND ----------

-- MAGIC %sql select * from dev_ainbo_gold.vw_campaign_ainbo_conversion where policy_no ='B11015791' and source_system ='non_nbm'
-- MAGIC
-- MAGIC -- and actual_vnb=0.00

-- COMMAND ----------

-- conversion view query for NBM

 select trans_date,utm_content,policy_no,product_id,funnel_stage,ape,vnb,actual_vnb,source_system 
from dev_ainbo_gold.vw_campaign_ainbo_conversion 
where policy_no IN ('B11107545') and funnel_stage = 'SUCCESS'and source_system = 'nbm'
sort by policy_no

-- COMMAND ----------

-- conversion view query for Non NBM

 select trans_date,utm_content,policy_no,product_id,funnel_stage,ape,vnb,actual_vnb,source_system 
from dev_ainbo_gold.vw_campaign_ainbo_conversion 
where policy_no IN ('B11130822') and funnel_stage = 'SUCCESS'and source_system = 'non_nbm'
sort by policy_no

-- COMMAND ----------

-- MAGIC %sql select * from dev_silver.actual_vnb_silver where POLICY_NUMBER ='B11107501'

-- COMMAND ----------

 --config table created from excel  for nbm record
 select VNB_AF_REIN_DIVER from dev_silver.actual_vnb_silver  where POLICY_NUMBER = 'B11107545'

-- COMMAND ----------

--  non nbm  -B11130822
select VNB_AF_REIN_DIVER from dev_silver.actual_vnb_silver  where POLICY_NUMBER = 'B11130822'

-- COMMAND ----------

select sum(VNB_AF_REIN_DIVER) from dev_silver.actual_vnb_silver  where POLICY_NUMBER = 'B11130822'

-- COMMAND ----------

 select count(1) from dev_silver.actual_vnb_silver

-- COMMAND ----------

-- MAGIC %sql select POLICY_NUMBER, SUM(VNB_AF_REIN_DIVER) AS ACTUAL_VNB from dev_silver.actual_vnb_silver 
-- MAGIC where POLICY_NUMBER in  ('B11015791','B11107501')
-- MAGIC GROUP BY POLICY_NUMBER
-- MAGIC  sort by POLICY_NUMBER
-- MAGIC

-- COMMAND ----------

