-- Databricks notebook source
desc table dev_ainbo_gold.vw_campaign_ainbo_demographics

-- COMMAND ----------

---select JSON_DATA_OTHERS_UTMCONTENT from dummy_ainbo.non_nbm_sample_data

select DATAVALUE_UTMTRACKING_UTMCONTENT from  dummy_ainbo.non_nbm_sample_data

-- COMMAND ----------

select ID,OFFER_KEY,STAGE from dummy_ainbo.temp_non_nbm_view sort by OFFER_KEY,STAGE

-- COMMAND ----------

--dummy_ainbo.nbm_final_view
--non_nbm_final_view
select ID,OFFER_KEY ,STAGE from dummy_ainbo.non_nbm_final_view where OFFER_KEY like '%NON-NBM-UTM-CONTENT%'

-- COMMAND ----------

select ID,OFFER_KEY,STAGE from dummy_ainbo.demographics_vw

-- COMMAND ----------

select * from 