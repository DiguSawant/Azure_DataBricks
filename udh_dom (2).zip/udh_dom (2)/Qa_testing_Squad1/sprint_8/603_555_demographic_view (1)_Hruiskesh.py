# Databricks notebook source
# MAGIC %run /Shared/udh_dom/usecases/nbo/notebook/aes

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/common_functions

# COMMAND ----------

def add_to_16(value):
    while len(value) % 16 != 0:
        value += "\0"
    return str.encode(value)

key2 = add_to_16(aes_key).decode()

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)-timedelta(days=30)
num_parts_scan = timeinbankok.strftime("%Y-%m-%d")

# COMMAND ----------

df_nbm = spark.read.csv('/mnt/fwd_test/prashant_dev_1/demographics_view_input/',header=True)

# COMMAND ----------

df_nbm.write.mode("overwrite").saveAsTable("dummy_ainbo.nbm_sample_data")

# COMMAND ----------

# MAGIC %sql
# MAGIC select JSON_DATA_OTHERS_UTMCONTENT from dummy_ainbo.nbm_sample_data;

# COMMAND ----------

spark.sql(f"""
create or replace view dummy_ainbo.temp_nbm_view(ID,OFFER_KEY,RANKING,CUSTOMER_SEGMENT,CAMPAIGN_ID,SOURCE,CAMPAIGN_PRODUCT,MEDIUM,REFERENCE_KEY,AGE,MARITAL_STATUS,HAS_CREDITCARD,HAS_CHILDREN,NO_OF_CHILDREN,GENDER,INCOME,DISTRICT,PROVINCE,ZIPCODE,POLICY_NUMBER,PRODUCT_CODE,DOB,PREMIUM,BILLING_MODE,OCCUPATION_GROUP,OCCUPATION_NAME,OCCUPATION_CLASS,PAYMENT_METHOD,PROMO_CODE,UTM_SOURCE,UTM_MEDIUM,UTM_CAMPAIGN,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,STAGE) as
    select 
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.OFFER_RANKING AS RANKING,
    s.OFFER_CUSTOMERSEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.CAMPAIGN_SOURCE AS CAMPAIGN_SOURCE,
    replace(replace(CAST(s.CAMPAIGN_PRODUCTS as VARCHAR(10)),'[',''),']','') AS CAMPAIGN_PRODUCTS,
    s.CAMPAIGN_MEDIUM AS MEDIUM,
    s.PROFILE_REFERENCEKEY AS REFERENCE_KEY,
    case when s.PROFILE_AGE = Null or s.PROFILE_AGE ='null' or trim(s.PROFILE_AGE) ='' or s.PROFILE_AGE =0 then  s.PROFILE_AGE else cast(aes_decrypt(unbase64(s.PROFILE_AGE),'{key2}', 'ECB', 'PKCS') AS STRING) END AS AGE,
    case when  s.PROFILE_HASCREDITCARD is NULL or s.PROFILE_HASCREDITCARD ='null' or trim(s.PROFILE_HASCREDITCARD) ='' or  s.PROFILE_HASCREDITCARD=0 or PROFILE_HASCREDITCARD=1 then  s.PROFILE_HASCREDITCARD else cast(aes_decrypt(unbase64(s.PROFILE_MARITALSTATUS),'{key2}', 'ECB', 'PKCS') AS STRING) END AS MARITAL_STATUS,
    s.PROFILE_HASCREDITCARD AS HAS_CREDITCARD,
    case when  s.PROFILE_HASCHILDREN is NULL or s.PROFILE_HASCHILDREN ='null' or trim(s.PROFILE_HASCHILDREN)='' or s.PROFILE_HASCHILDREN=0 or s.PROFILE_HASCHILDREN=1 then s.PROFILE_HASCHILDREN else cast(aes_decrypt(unbase64(s.PROFILE_HASCHILDREN),'{key2}', 'ECB', 'PKCS') AS STRING) END AS HAS_CHILDREN,
    case when s.PROFILE_NUMBEROFCHILDREN is NULL or s.PROFILE_NUMBEROFCHILDREN ='null' or trim(s.PROFILE_NUMBEROFCHILDREN)='' or s.PROFILE_NUMBEROFCHILDREN=0 then s.PROFILE_NUMBEROFCHILDREN  else cast(aes_decrypt(unbase64(s.PROFILE_NUMBEROFCHILDREN),'{key2}', 'ECB', 'PKCS') AS STRING)  END AS NUMBER_OF_CHILDREN,
    case when s.PROFILE_GENDER is NULL or s.PROFILE_GENDER ='null' or trim(s.PROFILE_GENDER)='' then s.PROFILE_GENDER else cast(aes_decrypt(unbase64(s.PROFILE_GENDER),'{key2}', 'ECB', 'PKCS') AS STRING) END AS GENDER,
     case when s.PROFILE_INCOME is NULL or s.PROFILE_INCOME ='null' or trim(s.PROFILE_INCOME)='' then   s.PROFILE_INCOME else cast(aes_decrypt(unbase64(s.PROFILE_INCOME),'{key2}', 'ECB', 'PKCS') AS STRING)  END AS INCOME,
    s.PROFILE_ADDRESS_DISTRICT AS DISTRICT,
    s.PROFILE_ADDRESS_PROVINCE AS PROVINCE,
    s.PROFILE_ADDRESS_ZIPCODE AS ZIPCODE,
    l.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO AS POLICY_NUMBER,
    l.JSON_DATA_FRONTENDDATA_XSELL_PRODUCTCODE AS PRODUCT_CODE,
    case when l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB is NULL or l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB ='null' or trim(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB) ='' then l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB else cast(aes_decrypt(unbase64(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_DOB),'{key2}', 'ECB', 'PKCS') AS STRING) END AS DOB,
    l.JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID AS PREMIUM,
     CASE 
        WHEN 
            l.JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID > l.JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING 
        THEN 'YEARLY'
        WHEN 
        l.JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID < l. JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING 
        THEN 'MONTHLY'
     ELSE null
     END
     AS BILLING_MODE,
     l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONGROUPNAME AS OCCUPATION_GROUP,
     case when l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME is NULL or l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME ='null' or trim(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME)='' then  l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME else cast(aes_decrypt(unbase64(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONNAME),'{key2}', 'ECB', 'PKCS') AS STRING)  end AS OCCUPATION_NAME,
     case when l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS is NULL or l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS ='null' or trim(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS)='' then  l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS  else cast(aes_decrypt(unbase64(l.JSON_DATA_POLICYDATA_INSUREDLIVES_INSUREDDETAILS_OCCUPATIONCLASS),'{key2}', 'ECB', 'PKCS') AS STRING) end  AS OCCUPATION_CLASS,
     l.JSON_DATA_POLICYDATA_SELECTEDPAYMENT_PAYMENTTYPES_PAYMENTTYPE AS PAYMENT_METHOD,
     l.JSON_DATA_OTHERS_PROMO AS PROMO_CODE,
     l.JSON_DATA_OTHERS_UTMSOURCE AS UTM_SOURCE,
     l.JSON_DATA_OTHERS_UTMMEDIUM AS UTM_MEDIUM,
     l.JSON_DATA_OTHERS_UTMCAMPAIGN AS UTM_CAMPAIGN,
     upper(l.UDH_SOURCE_SYS) AS SOURCE_SYSTEM,
     l.UDH_INSERT_TIMESTAMP AS UDH_INSERT_TIMESTAMP,
     case when 
      l.AFTER_USER_VIEW ='QUOTE.PAYMENT' and l.AFTER_STATUS = 'PAYMENT'
      then 6
      when 
      l.AFTER_USER_VIEW = 'QUOTE.PAYMENT' and l.AFTER_STATUS = 'PENDING'
      then 5
      when 
      l.AFTER_USER_VIEW = 'QUOTE.PROCEEDTOPAY' and l.AFTER_STATUS ='PROPOSAL'
      then 4
      when 
      l.AFTER_USER_VIEW = 'QUOTE.PERSONALDETAIL' and l.AFTER_STATUS = 'PROPOSAL'
      then 3
      when
      l.AFTER_USER_VIEW = 'QUOTE.UNDERWRITINGANSWER' and l.AFTER_STATUS = 'PROPOSAL'
      then 2
      WHEN
      l.AFTER_USER_VIEW = 'QUOTE.QUICKQUESTIONS' and l.AFTER_STATUS = 'PROPOSAL'
      then 1
      end as Stage
from 
      dev_silver.nbo_silver as s
left join dummy_ainbo.nbm_sample_data as l 
on
      upper(l.JSON_DATA_OTHERS_UTMCONTENT) = upper(s.OFFER_KEY)

       and
        l.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO IS NOT NULL 
        
    where

       date_format(s.UDH_INSERT_TIMESTAMP,'yyyy-MM-dd') >= cast(date_format(date_sub(current_timestamp(),30),'yyyy-MM-dd') as string) 

          """)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.temp_nbm_view where OFFER_KEY like '%REFERRAL-CONTENT%';

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace view dummy_ainbo.nbm_final_view as 
# MAGIC select ID,t1.OFFER_KEY,RANKING,CUSTOMER_SEGMENT,CAMPAIGN_ID,SOURCE,CAMPAIGN_PRODUCT,MEDIUM,REFERENCE_KEY,AGE,MARITAL_STATUS,HAS_CREDITCARD,HAS_CHILDREN,NO_OF_CHILDREN,GENDER,
# MAGIC  INCOME,DISTRICT,PROVINCE,ZIPCODE,POLICY_NUMBER,PRODUCT_CODE,DOB,PREMIUM,BILLING_MODE,
# MAGIC  OCCUPATION_GROUP,OCCUPATION_NAME,OCCUPATION_CLASS,PAYMENT_METHOD,PROMO_CODE,UTM_SOURCE,
# MAGIC  UTM_MEDIUM,UTM_CAMPAIGN,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,
# MAGIC case 
# MAGIC when t1.stage=6
# MAGIC then 'SUCCESS'
# MAGIC when t1.stage=5
# MAGIC then 'Payment'
# MAGIC when t1.stage=4
# MAGIC then 'SUMMARY'
# MAGIC when t1.stage=3
# MAGIC then 'PERSONAL INFO'
# MAGIC when t1.stage=2
# MAGIC then 'HEALTH QUESTION'
# MAGIC when t1.stage=1
# MAGIC then 'QUOTE'
# MAGIC end as STAGE
# MAGIC from dummy_ainbo.temp_nbm_view t1
# MAGIC join
# MAGIC (
# MAGIC     SELECT max(stage)as stage,OFFER_KEY 
# MAGIC     FROM dummy_ainbo.temp_nbm_view
# MAGIC     GROUP BY OFFER_KEY
# MAGIC ) t2 on t1.stage = t2.stage where t1.OFFER_KEY = t2.OFFER_KEY

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.nbm_final_view;

# COMMAND ----------

# MAGIC %md
# MAGIC #####NON NBM

# COMMAND ----------

df_non_nbm = spark.read.csv('/mnt/fwd_test/prashant_dev_1/demographics_view_input2/',header=True)

# COMMAND ----------

df_non_nbm.write.mode("overwrite").saveAsTable("dummy_ainbo.non_nbm_sample_data")

# COMMAND ----------

spark.sql(f"""
create or replace view dummy_ainbo.temp_non_nbm_view(ID,OFFER_KEY,RANKING,CUSTOMER_SEGMENT,CAMPAIGN_ID,SOURCE,CAMPAIGN_PRODUCT,MEDIUM,REFERENCE_KEY,AGE,MARITAL_STATUS,HAS_CREDITCARD,HAS_CHILDREN,NO_OF_CHILDREN,GENDER,INCOME,DISTRICT,PROVINCE,ZIPCODE,POLICY_NUMBER,PRODUCT_CODE,DOB,PREMIUM,BILLING_MODE,OCCUPATION_GROUP,OCCUPATION_NAME,OCCUPATION_CLASS,PAYMENT_METHOD,PROMO_CODE,UTM_SOURCE,UTM_MEDIUM,UTM_CAMPAIGN,SOURCE_SYSTEM, UDH_INSERT_TIMESTAMP,STAGE) as
select DISTINCT
    s.ID AS ID,
    s.OFFER_KEY AS OFFER_KEY,
    s.RANKING AS RANKING,
    s.CUSTOMER_SEGMENT AS CUSTOMER_SEGMENT,
    s.CAMPAIGN_ID AS CAMPAIGN_ID,
    s.SOURCE AS SOURCE,
    s.CAMPAIGN_PRODUCT,
    s.MEDIUM AS MEDIUM,
    s.REFERENCE_KEY AS REFERENCE_KEY,
    s.AGE,
    s.MARITAL_STATUS,
    s.HAS_CREDITCARD AS HAS_CREDITCARD,
    s.HAS_CHILDREN,
    s.NO_OF_CHILDREN,
    s.GENDER,
    s.INCOME,
    s.DISTRICT AS DISTRICT,
    s.PROVINCE AS PROVINCE,
    s.ZIPCODE AS ZIPCODE,
    coalesce(POLICY_NUMBER,l.DATAVALUE_POLICYNUMBER) AS POLICY_NUMBER,
    coalesce(PRODUCT_CODE,l.DATAVALUE_PRODUCTID) AS PRODUCT_CODE,
    coalesce(DOB, case when l.DATAVALUE_PREMIUMINFO_BIRTHDATE is NULL or l.DATAVALUE_PREMIUMINFO_BIRTHDATE ='null' or trim(l.DATAVALUE_PREMIUMINFO_BIRTHDATE)='' then l.DATAVALUE_PREMIUMINFO_BIRTHDATE else cast(AES_decrypt(unbase64(l.DATAVALUE_PREMIUMINFO_BIRTHDATE),'{key2}', 'ECB', 'PKCS') AS STRING) END) AS DOB,
    coalesce(PREMIUM, l.DATAVALUE_PREMIUMINFO_PREMIUM) AS PREMIUM,
    coalesce(BILLING_MODE,l.DATAVALUE_PREMIUMINFO_PAYMENTMODE) AS BILLING_MODE,
    coalesce(OCCUPATION_GROUP,case when l.DATAVALUE_POLICYHOLDER_JOBGROUP is NULL or l.DATAVALUE_POLICYHOLDER_JOBGROUP ='null' or trim(l.DATAVALUE_POLICYHOLDER_JOBGROUP)='' then l.DATAVALUE_POLICYHOLDER_JOBGROUP else cast(AES_decrypt(unbase64(l.DATAVALUE_POLICYHOLDER_JOBGROUP),'{key2}', 'ECB', 'PKCS') AS STRING)  END) AS OCCUPATION_GROUP,
    coalesce(OCCUPATION_NAME,case when l.DATAVALUE_POLICYHOLDER_JOBNAME is NULL or l.DATAVALUE_POLICYHOLDER_JOBNAME ='null' or trim(l.DATAVALUE_POLICYHOLDER_JOBNAME)='' then l.DATAVALUE_POLICYHOLDER_JOBNAME else cast(AES_decrypt(unbase64(l.DATAVALUE_POLICYHOLDER_JOBNAME),'{key2}', 'ECB', 'PKCS') AS STRING) END) AS OCCUPATION_NAME,
    coalesce(OCCUPATION_CLASS,NULL) AS OCCUPATION_CLASS,
    coalesce(PAYMENT_METHOD,l.DATAVALUE_PAYMENTTYPE) AS PAYMENT_METHOD,
    coalesce(PROMO_CODE,l.DATAVALUE_PROMOCODE) AS PROMO_CODE,
    coalesce(UTM_SOURCE,l.DATAVALUE_UTMTRACKING_UTMSOURCE) AS UTM_SOURCE,
    coalesce(UTM_MEDIUM,l.DATAVALUE_UTMTRACKING_UTMMEDIUM) AS UTM_MEDIUM,
    coalesce(UTM_CAMPAIGN,l.DATAVALUE_UTMTRACKING_UTMCAMPAIGN) AS UTM_CAMPAIGN,
    coalesce(SOURCE_SYSTEM,l.UDH_SOURCE_SYS) AS  SOURCE_SYSTEM,
    s.UDH_INSERT_TIMESTAMP AS UDH_INSERT_TIMESTAMP,
    case
    WHEN
      l.et_application = 'ECOMMERCE'
      and l.et_entityname = 'SAVESTAGE' 
      and l.datavalue_isPaymentComplete = 'TRUE'
      and l.datavalue_productId in ('E60A1','T12A')
      and l.DATAVALUE_PAYMENTTYPE = 'PAY_GATEWAY'
    THEN 6
    WHEN
      l.et_application = 'ECOMMERCE'
      and l.et_entityname = 'SAVESTAGE' 
      and l.DATAVALUE_POLICYNUMBER IS NOT NULL
      and l.datavalue_paymentType IS NOT NULL
      and l.datavalue_isPaymentComplete IS NULL
      and l.datavalue_productId in ('E60A1','T12A')
    THEN 5
    WHEN
      l.et_application = 'ECOMMERCE'
      and l.et_entityname = 'SAVESTAGE' 
      and l.datavalue_policyNumber IS NOT NULL
      and l.datavalue_paymentType IS NULL
      and l.datavalue_productId in ('E60A1','T12A')
    THEN 4
    WHEN
      l.et_application = 'ECOMMERCE'
      and l.et_entityname = 'SAVESTAGE' 
      and l.datavalue_health_hasOtherInsurance IS NULL 
      and l.datavalue_isOtpVerify='FALSE' 
      and l.datavalue_policyHolder_mobileNumber IS NOT NULL 
      and l.datavalue_productId in ('E60A1','T12A')
    THEN 3
    WHEN
      l.et_application = 'ECOMMERCE' 
      and l.et_entityname = 'SAVESTAGE' 
      and l.datavalue_health_hasOtherInsurance IS NOT NULL 
      and l.datavalue_isFatcaPass='FALSE'
      and l.datavalue_productId in ('E60A1','T12A')
    THEN 2
    WHEN
      l.ET_APPLICATION = 'ECOMMERCE' 
      and ET_ENTITYNAME = 'SAVESTAGE' 
      and l.DATAVALUE_HEALTH_HASOTHERINSURANCE IS NULL 
      and l.DATAVALUE_ISOTPVERIFY IS NULL 
      and l.DATAVALUE_PREMIUMINFO_BIRTHDATE IS NOT NULL 
      and l.DATAVALUE_PRODUCTID in ('E60A1','T12A')
    THEN 1
    end AS Stage
from 
      dummy_ainbo.temp_nbm_view as s
join  dummy_ainbo.non_nbm_sample_data as l
on
      upper(l.DATAVALUE_UTMTRACKING_UTMCONTENT) = upper(s.OFFER_KEY)
and 
      l.DATAVALUE_POLICYNUMBER IS NOT NULL
""")

# COMMAND ----------

# MAGIC %sql select * from dummy_ainbo.temp_non_nbm_view

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace view dummy_ainbo.non_nbm_final_view as 
# MAGIC select ID,t1.OFFER_KEY,RANKING,CUSTOMER_SEGMENT,CAMPAIGN_ID,SOURCE,CAMPAIGN_PRODUCT,MEDIUM,REFERENCE_KEY,AGE,MARITAL_STATUS,HAS_CREDITCARD,HAS_CHILDREN,NO_OF_CHILDREN,GENDER,
# MAGIC  INCOME,DISTRICT,PROVINCE,ZIPCODE,POLICY_NUMBER,PRODUCT_CODE,DOB,PREMIUM,BILLING_MODE,
# MAGIC  OCCUPATION_GROUP,OCCUPATION_NAME,OCCUPATION_CLASS,PAYMENT_METHOD,PROMO_CODE,UTM_SOURCE,
# MAGIC  UTM_MEDIUM,UTM_CAMPAIGN,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,
# MAGIC case 
# MAGIC when t1.stage=6
# MAGIC then 'SUCCESS'
# MAGIC when t1.stage=5
# MAGIC then 'Payment'
# MAGIC when t1.stage=4
# MAGIC then 'SUMMARY'
# MAGIC when t1.stage=3
# MAGIC then 'PERSONAL INFO'
# MAGIC when t1.stage=2
# MAGIC then 'HEALTH QUESTION'
# MAGIC when t1.stage=1
# MAGIC then 'QUOTE'
# MAGIC end as STAGE
# MAGIC from dummy_ainbo.temp_non_nbm_view t1
# MAGIC join
# MAGIC (
# MAGIC     SELECT max(stage)as stage,OFFER_KEY 
# MAGIC     FROM dummy_ainbo.temp_non_nbm_view
# MAGIC     GROUP BY OFFER_KEY
# MAGIC ) t2 on t1.stage = t2.stage where t1.OFFER_KEY = t2.OFFER_KEY

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.non_nbm_final_view;

# COMMAND ----------

# MAGIC %md
# MAGIC ####UNION BOTH THE FINAL VIEWS

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.nbm_final_view

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.non_nbm_final_view

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace view dummy_ainbo.demographics_vw as select * from dummy_ainbo.nbm_final_view union select * from dummy_ainbo.non_nbm_final_view;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dummy_ainbo.demographics_vw;