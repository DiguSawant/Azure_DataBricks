# Databricks notebook source
"""
    Purpose : create unittest cases for CUBE tables
    Input : database names,table names
    Output :tables
"""

# COMMAND ----------

import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

import unittest 
class TestCheckEmail(unittest.TestCase):

#Verifying count is same at the source and the sink delta table
    def test_check_count_lead(self):
        source_count_df  = spark.sql(f"""select count(distinct JSONVALUE_ID ) from {env}_cube_fna_silver.iris_lead_cube_fna_silver
        where JSONVALUE_ID not in ('10181','10182','10183','10184','10185','11903', '13794','16249','21054','21055','21038','22039','22040','22038' ) """)
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct JSONVALUE_ID) from {env}_silver.iris_lead_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)
    
    def test_check_count_lead_agent(self):
        source_count_df  = spark.sql(f""" select count(distinct lead_id) from {env}_cube_fna_silver.cls_lead_agent_cube_fna_silver""")        
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct lead_id) from {env}_silver.cls_lead_agent_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)

    def test_check_count_lead_info(self):
        source_count_df  = spark.sql(f""" select count(distinct lead_id) from {env}_cube_fna_silver.cls_lead_info_cube_fna_silver
        where lead_id not in ('DH-00be4112-40be-44d7-b1f4-9323a43e749c', 'DH-10001', 'DH-123', 'Marketing-00be4112-40be-44d7-b1f4-9323a43e749c', 'Marketing-10001', 'DH-0000123') and government_id_num not in ('Utj6fOgudgDqsUbe8g/IfA==' ,'wer567') and lead_birth_date not in ('tR5hvhfmgyIIKncRf17Nmg==')""").dropDuplicates()
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct lead_id) from {env}_silver.cls_lead_info_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)

    def test_check_count_lead_status(self):
        source_count_df  = spark.sql(f""" select count(distinct lead_id) from {env}_cube_fna_silver.cls_lead_status_cube_fna_silver""")        
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct lead_id) from {env}_silver.cls_lead_status_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)
    
    def test_check_count_product_info(self):
        source_count_df  = spark.sql(f""" select count(distinct lead_id) from {env}_cube_fna_silver.cls_product_info_cube_fna_silver""")        
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct lead_id) from {env}_silver.cls_product_info_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)
    
    def test_check_count_product_rec(self):
        source_count_df  = spark.sql(f""" select count(distinct lead_id) from {env}_cube_fna_silver.cls_product_rec_cube_fna_silver""")        
        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql(f"""select count(distinct lead_id) from {env}_silver.cls_product_rec_cube_fna_silver """)
        target_count=target_count_df.collect()[0][0]

        self.assertEqual(source_count,target_count)


    

# COMMAND ----------

unittest.main(argv=[''],verbosity=2,exit=False)