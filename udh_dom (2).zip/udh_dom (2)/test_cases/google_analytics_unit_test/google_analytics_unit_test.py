# Databricks notebook source
from pyspark.sql.functions import *


# COMMAND ----------

# required configuration
path_prefix='/mnt/dev/fwd_landing'

google_analytics_config={
'ga':{
"parentProject":"thai-project-292010",
"project":"thai-project-292010",
"tablename":"thai-project-292010.analytics_227136479.events_",
"numPartitions":15,
"target_path":f"{path_prefix}/bronze/ga4/TH.DEV.GBQ.GA4.GOOGLE_ANALYTICS" 
}
}

config = google_analytics_config["ga"]
parentProject = config["parentProject"]
project=config["project"]
table = config["tablename"]
numPartitions = config["numPartitions"]
target_path = config["target_path"]


# COMMAND ----------

# Getting Random Event Date

import random
from datetime import datetime, timedelta ,date
start_date =datetime(2022,9,12).date()
end_date=date.today()
end_date-=timedelta(days=1)

def generate_random_date(start_date, end_date):
    time_delta = end_date - start_date

    random_days = random.randint(0, time_delta.days)

    random_date = start_date + timedelta(days=random_days)

    return random_date

random_even_date = generate_random_date(start_date, end_date)
print(random_even_date)


# COMMAND ----------

big_query_table_name='thai-project-292010.analytics_227136479.events_'+random_even_date.strftime("%Y%m%d")
#print(big_query_table_name)

# COMMAND ----------

year=random_even_date.strftime("%Y")
month=random_even_date.strftime("%m")
day=random_even_date.strftime("%d")

# COMMAND ----------

# s3 file path
bronze_s3_path=f"{target_path}/year={year}/month={month}/day={day}"
print(bronze_s3_path)

# COMMAND ----------

#Reading Data From Source Big Query
ga_df=spark.read.format("bigquery") \
                .option("parentProject", parentProject) \
                .option("project", project) \
                .option("table", big_query_table_name).load()

#Creating Table on source DataFrame
ga_df.createOrReplaceTempView("bigquery_source_table")

#Reading Data From target Bronze S3 Location
s3_df=spark.read.json(bronze_s3_path)
s3_df.createOrReplaceTempView("bronze_target_table")


# COMMAND ----------

def count_validation(source,target):
    #running count on source and atrget
    source_count=source.count()
    target_count=target.count()
    case_data = [{'source_count': source_count, 'target_count': target_count,'count_match':source_count==target_count}]
    spark.createDataFrame(case_data).display()

# COMMAND ----------

def column_match_validation(source,target):
    source_columns=source.columns
    target_columns=target.columns

    #Removing 
    # Audit('udh_batch_id','udh_insert_timestamp','udh_source_sys') columns And 
    # Partitioning('year','month','day') columns from target_columns 
    audit_columns=['udh_batch_id','udh_insert_timestamp','udh_source_sys','year','month','day']
    target_new_columns=[x for x in target.columns if x not in audit_columns]

    if set(source.columns) == set(target_new_columns):
        print('Columns are Matching')
    else:
        print("Columns are not matching "+str(set(source.columns).difference(target_new_columns)))

# COMMAND ----------

def null_count_validation(source,target):
    #Checking null count for 3 random columns 
    #picking 3 random columns names from source
    random_col_name=random.sample(source.columns,3)

    columns = [sum(col(column).isNull().cast("int")).alias(column) for column in random_col_name]
    print(columns)
    s_name='source as source'
    t_name='target as source'
    #source.selectExpr(columns+[s_name]).unionByName(target.selectExpr(columns+[t_name])).display()
    source.select(columns).unionByName(target.select(columns)).display()
    


# COMMAND ----------

null_count_validation(ga_df,s3_df)
count_validation(ga_df,s3_df)

# COMMAND ----------

column_match_validation(ga_df,s3_df)

# COMMAND ----------

ga_df.display()

# COMMAND ----------

