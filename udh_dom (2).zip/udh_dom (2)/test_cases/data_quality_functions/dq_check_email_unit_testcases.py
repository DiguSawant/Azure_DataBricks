# Databricks notebook source
# MAGIC %md 
# MAGIC ###TESTING
# MAGIC * Doc_Type              : Tech
# MAGIC * Tech Description      : data quality check_email function testing
# MAGIC * Pre_requisites        : check_email function
# MAGIC * Inputs                : column name
# MAGIC * Outputs               : boolean
# MAGIC * __author__ : 'Blazeclan'

# COMMAND ----------

# MAGIC %md ##importing data quality functions

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,UNIT TESTCASES
import unittest 
class TestCheckEmail(unittest.TestCase):

#Verifying if the Email is Empty
    def test_empty_email(self):
        result  =  python_check_email("")
        self.assertEqual(result,False)

#Verifying if the Valid Email is written we get True
    def test_valid_email(self):
        result  =  python_check_email("sheldon.cooper1-2@gmail.com")
        self.assertEqual(result,True)

#Verifying if the Invalid Email is written we get False
    def test_invalid_email(self):
        result  =  python_check_email("hrushi##@gmail")
        self.assertEqual(result,False)
        

# COMMAND ----------

# DBTITLE 1,EXECUTING TESTCASES
unittest.main(argv=[''],verbosity=2,exit=False)