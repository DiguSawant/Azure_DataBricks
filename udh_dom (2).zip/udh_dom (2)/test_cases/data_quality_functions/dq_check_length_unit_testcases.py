# Databricks notebook source
# MAGIC %md ### TESTING
# MAGIC * Doc_Type           : Tech
# MAGIC * Tech Description   : data quality check_email function testing
# MAGIC * Pre_requisites     : check_length function
# MAGIC * Inputs             : column_name,length
# MAGIC * Output             : Boolean type
# MAGIC * author             : 'Blazeclan'

# COMMAND ----------

# MAGIC %md ##importing data quality functions

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,UNIT TESTCASES
import unittest 
class TestCheckLength(unittest.TestCase):
    
#Verifying if zero length parameters are passed
    def test_no_length_parameter(self):
        with self.assertRaises(Exception) as context:
            python_check_length()
        self.assertFalse('length can not br empty or none' in str(context.exception))

#Verifying if one length parameter is passed. Length passed is not equal to the length of string.
    def test_one_length_parameter_with_different_string_length(self):
        result  =   python_check_length("EMPL",1)
        self.assertEqual(result,False)

#Verifying if one length parameter is passed. Length passed is equal to the length of string.
    def test_one_length_parameter_with_same_string_length(self):
        result  =   python_check_length("EMP",3)
        self.assertEqual(result,True)

#Verifying if two length parameters are passed.The string length is within the range mentioned.
    def test_two_length_parameter_with_string_length_in_range(self):
        result  =   python_check_length("EMPL",3,6)
        self.assertEqual(result,True)
       
 #Verifying if two length parameters are passed. The string length is Not within the range mentioned.
    def test_two_length_parameter_with_string_length_not_in_range(self):
        result  =   python_check_length("EM",3,6)
        self.assertEqual(result,False)

#Verifying if more than two length parameters are passed.
    def test_more_than_two_length_parameter(self):
        with self.assertRaises(Exception) as context:
             python_check_length()
        self.assertFalse('length should be [min,max] or [exact_value]' in str(context.exception))
        
        

# COMMAND ----------

# DBTITLE 1,EXECUTING TESTCASES
unittest.main(argv=[''],verbosity=2,exit=False)