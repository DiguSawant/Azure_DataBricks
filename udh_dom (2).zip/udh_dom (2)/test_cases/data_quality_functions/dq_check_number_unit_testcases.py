# Databricks notebook source
# MAGIC %md ### TESTING
# MAGIC * Doc_Type           : Tech
# MAGIC * Tech Description   : data quality check_email function testing
# MAGIC * Pre_requisites     : check_phone_number function
# MAGIC * Inputs             : column_name
# MAGIC * Output             : Boolean type
# MAGIC * author             : 'Blazeclan'

# COMMAND ----------

# MAGIC %md ##importing data quality functions

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,UNIT TESTCASES 
import unittest 
class TestCheckNumber(unittest.TestCase):
    
#Verifying if the Phone Number is Empty.
    def test_python_empty_number(self):
        result  =  python_check_phone_number("")
        self.assertEqual(result,False)

#Verifying the Phone Number having Country Code
    def test_python_valid_number_with_country_code(self):
        result  =  python_check_phone_number("+66-98-765-4321")
        self.assertEqual(result,True)

#Verifying the Phone Number which doesn't have Country Code
    def test_python_valid_number_without_country_code(self):
        result  =  python_check_phone_number("898-765-4321")
        self.assertEqual(result,True)

#Verifying if the Phone Number has length greater than required length.
    def test_python_invalid_number_having_length_greater(self):
        result  =  python_check_phone_number("987-654-32100")
        self.assertEqual(result,False)
    
#Verifying if the Phone Number has length smaller than required length.
    def test_python_invalid_number_having_length_smaller(self):
        result  =  python_check_phone_number("987-654-32")
        self.assertEqual(result,False)

# COMMAND ----------

# DBTITLE 1,EXECUTING TESTCASES
unittest.main(argv=[''],verbosity=2,exit=False)
