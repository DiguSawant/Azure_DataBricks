# Databricks notebook source
# MAGIC %md
# MAGIC ## IMPORTING DATA QUALITY FUNCTION

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/data_quality_functions

# COMMAND ----------

# MAGIC %md ### DATA QUALITY FUNCTIONS USECASE
# MAGIC * Doc_Type           : Tech
# MAGIC * Tech Description   : Data quality functions 
# MAGIC * Pre_requisites     : Testing Functions
# MAGIC * author             : 'Blazeclan'

# COMMAND ----------

# MAGIC %md
# MAGIC ##IMPORT REQUIRED PACKAGES

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

# COMMAND ----------

# MAGIC %md
# MAGIC ##IMPORT TEST DATA

# COMMAND ----------

#Created the dataframe using test records
df=spark.read.format("csv").option('header',True).load("/FileStore/export.csv")

# COMMAND ----------

# MAGIC %md
# MAGIC ##DATA 

# COMMAND ----------

#Displaying records used for testing
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ##CHECK_NULL TESTING FUNCTION

# COMMAND ----------

#The below dataframe is for invalid records
df_check_null_invalid_data = df.where(check_null(col("L_NAME")) == False)

#The below dataframe is for valid records
df_check_null_valid_data = df.where(check_null(col("L_NAME")) == True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Displaying Valid and Invalid Data from given Dataset.

# COMMAND ----------

print("\t\t\t\t########Valid Datasets########\n")
display(df_check_null_valid_data)

print("\n\t\t\t\t########Invalid Datasets########\n")
display(df_check_null_invalid_data)

# COMMAND ----------

# MAGIC %md
# MAGIC ##CHECK_LENGTH TESTING FUNCTION

# COMMAND ----------

#The below dataframe is for invalid records
df_invalid_data_one_parameter = df.where(check_length(col("EMPLOYEE_ID"),lit(3)) == False)

#The below dataframe is for valid records
df_valid_data_one_parameter = df.where(check_length(col("EMPLOYEE_ID"),lit(3)) == True)

#The below dataframe is for invalid records
df_invalid_data_two_parameter = df.where(check_length(col("EMPLOYEE_ID"),lit(2),lit(5)) == False)

#The below dataframe is for valid records
df_valid_data_two_parameter = df.where(check_length(col("EMPLOYEE_ID"),lit(2),lit(5)) == True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Displaying Valid and Invalid Data from given Dataset.

# COMMAND ----------

print("\t\t\t\t########Valid Datasets for exact matching length########\n")
display(df_valid_data_one_parameter)

print("\n\t\t\t\t########Invalid Datasets for non-matching length########\n")
display(df_invalid_data_one_parameter)

print("\n\t\t\t\t########Valid Datasets for the length in a range########\n")
display(df_valid_data_two_parameter)

print("\n\t\t\t\t########Invalid Datasets for the length out of range########\n")
display(df_invalid_data_two_parameter)

# COMMAND ----------

# MAGIC %md
# MAGIC ##FILTERING DATASET USING CHECK_EMAIL FUNCTION

# COMMAND ----------

#The below dataframe is for invalid records
df_check_email_invalid_data = df.filter(check_email(col("EMAIL") ) == False)

#The below dataframe is for valid records
df_check_email_valid_data = df.filter(check_email(col("EMAIL") ) == True)

# COMMAND ----------

# MAGIC %md
# MAGIC #Displaying Valid and Invalid Data from given Dataset.

# COMMAND ----------

print("\t\t\t\t########Valid Datasets########\n")
display(df_check_email_valid_data)

print("\n\t\t\t\t########Invalid Datasets########\n")
display(df_check_email_invalid_data)

# COMMAND ----------

# MAGIC %md
# MAGIC ##CHECK_PHONE_NUMBER TESTING FUNCTION

# COMMAND ----------

#The below dataframe is for invalid records
df_invalid_data = df.where(check_phone_number(col("PHONE_NUMBER")) == False)

#The below dataframe is for valid records
df_valid_data = df.where(check_phone_number(col("PHONE_NUMBER")) == True)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Displaying Valid and Invalid Data from given Dataset.

# COMMAND ----------

print("\t\t\t\t########Valid Datasets########\n")
display(df_valid_data)

print("\n\t\t\t\t########Invalid Datasets########\n")
display(df_invalid_data)

# COMMAND ----------

