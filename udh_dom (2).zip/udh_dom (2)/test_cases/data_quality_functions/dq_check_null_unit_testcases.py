# Databricks notebook source
# MAGIC %md ### TESTING
# MAGIC * Doc_Type           : Tech
# MAGIC * Tech Description   : data quality check_email function testing
# MAGIC * Pre_requisites     : check_null function
# MAGIC * Inputs             : column_name
# MAGIC * Output             : Boolean type
# MAGIC * author             : 'Blazeclan'

# COMMAND ----------

# MAGIC %md ##importing data quality functions

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,DEFINITION OF CHECK NULL TESTING FUNCTION
from pyspark.sql.types import * 
from pyspark.sql.functions import *

"""
    Purpose : check null value for given column
    Input : column name
    Output : boolean (true or false)
"""
def python_check_null(value):
    try:
        if value is None:
            status = False
        else:
            value=str(value).strip() 
            if value == "None" or value == "" or value=="null":
                status = False
            else:
                status = True
        return status
    except Exception as e:
        raise Exception(e)   
spark.udf.register("check_null", check_null)
#check_null = udf(check_null, BooleanType())
#good_df = df.where(check_nul(col("L_NAME")) == True)

# COMMAND ----------

# DBTITLE 1,UNIT TESTCASES
import unittest 

class TestCheckNull(unittest.TestCase):
    
  #verifying if  empty value is passed
    def test_python_empty_value(self):
        result=python_check_null("")
        self.assertEqual(result,False)
        
    #verifying if  valid value is passed    
    def test_python_having_value(self):
        result=python_check_null("xyz")
        self.assertEqual(result,True)
        
    #verifying if  None value is passed    
    def test_python_None_value(self):
        result=python_check_null(None)
        self.assertEqual(result,False)
        
    #verifying if  "null" value is  passed    
    def test_python_string_null_value(self):
        result=python_check_null("null")
        self.assertEqual(result,False)
        
        

# COMMAND ----------

# DBTITLE 1,EXECUTING TESTCASES
unittest.main(argv=[''],verbosity=2,exit=False)
