# Databricks notebook source
# MAGIC %md
# MAGIC ### IMPORTING SCHEMA CONVERTER FUNCTION

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/common_spark_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### TEST SCHEMA FOR TESTING

# COMMAND ----------

string_schema='StructType([StructField("APPLICATION",StringType(),True),StructField("ENTITYNAME",StringType(),True),StructField("ENTITYSEQ",StringType(),True),StructField("GUID",StringType(),True),StructField("INDEXKEY",StringType(),True),StructField("SORTKEY",StringType(),True),StructField("SYSTEMCREATEDDT",LongType(),True),StructField("SYSTEMUPDATEDDT",LongType(),True),StructField("VERSIONID",StringType(),True)])'

# COMMAND ----------

# MAGIC %md
# MAGIC ### EXPECTED OUTPUT OF SCHEMA_CONVERTER FUNCTION

# COMMAND ----------

expected_schema=StructType([StructField("APPLICATION",StringType(),True),StructField("ENTITYNAME",StringType(),True),StructField("ENTITYSEQ",StringType(),True),StructField("GUID",StringType(),True),StructField("INDEXKEY",StringType(),True),StructField("SORTKEY",StringType(),True),StructField("SYSTEMCREATEDDT",LongType(),True),StructField("SYSTEMUPDATEDDT",LongType(),True),StructField("VERSIONID",StringType(),True)])

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASE FOR SCHEMA CONVERTER FUNCTION

# COMMAND ----------

import unittest

class ConfigSchemaConverterTest(unittest.TestCase):
    
    #cheking conversion as expects 
    def test_config_schema_converter(self):
        schema=schema_converter(string_schema)
        self.assertEqual(schema,expected_schema)

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)