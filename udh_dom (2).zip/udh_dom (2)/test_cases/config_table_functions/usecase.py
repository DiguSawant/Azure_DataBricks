# Databricks notebook source
# MAGIC %md
# MAGIC ### IMPORTING UPSERT FUNCTIONS

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/common_spark_functions

# COMMAND ----------

# MAGIC %sql drop table party_b.test_config

# COMMAND ----------

# MAGIC %fs rm -r "/test/dev/config"

# COMMAND ----------

# MAGIC %md
# MAGIC ### CREATING TABLE

# COMMAND ----------

# MAGIC %sql create table party_b.test_config(config_name string,config string,created_at timestamp,updated_at timestamp,status string) using delta location "/test/dev/config"

# COMMAND ----------

party_table_config = {
        "database_name":"party_b",
		"target_table":"party",
		"partition_column":"source_system",
		"target_checkpointLocation":"/mnt/fwd_test/silver/customer/party_silver/party/checkpoint/",
        "col_stand":
    {
		"party_id":"ENTITYSEQ",
		"party_source":"$ecom$",
		"party_name":"concat_ws($ $,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName)",
		"party_type_code":"$individual$",
		"customer_flag":"$y$",
		"employee_flag":"$n$",
		"prospect_flag":"$n$",
		"agent_flag":"$y$",
		"email_address":"datavalue_policyHolder_email",
		"udh_active_flag":"$y$",
		"source_system":"$ifwd$",
		"udh_insert_date":"current_timestamp()",
		"udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,party_source,party_name,party_type_code,customer_flag,employee_flag,prospect_flag,agent_flag,email_address,udh_active_flag,source_system,udh_insert_date,udh_update_date"
	}   

# COMMAND ----------

# MAGIC %md
# MAGIC ### INSERTING TABLE

# COMMAND ----------

config_upsert("party_b.test_config","party_table_config",party_table_config)

# COMMAND ----------

# MAGIC %md
# MAGIC ### RESULT 

# COMMAND ----------

# MAGIC %sql select * from party_b.test_config

# COMMAND ----------

# MAGIC %md
# MAGIC ### INSERTING TABLE for second time for same configname

# COMMAND ----------

#changing config database name to party_c
party_table_config = {
        "database_name":"party_c",
		"target_table":"party",
		"partition_column":"source_system",
		"target_checkpointLocation":"/mnt/fwd_test/silver/customer/party_silver/party/checkpoint/",
        "col_stand":
    {
		"party_id":"ENTITYSEQ",
		"party_source":"$ecom$",
		"party_name":"concat_ws($ $,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName)",
		"party_type_code":"$individual$",
		"customer_flag":"$y$",
		"employee_flag":"$n$",
		"prospect_flag":"$n$",
		"agent_flag":"$y$",
		"email_address":"datavalue_policyHolder_email",
		"udh_active_flag":"$y$",
		"source_system":"$ifwd$",
		"udh_insert_date":"current_timestamp()",
		"udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,party_source,party_name,party_type_code,customer_flag,employee_flag,prospect_flag,agent_flag,email_address,udh_active_flag,source_system,udh_insert_date,udh_update_date"
	}   

# COMMAND ----------

config_upsert("party_b.test_config","party_table_config",party_table_config)

# COMMAND ----------

# MAGIC %md
# MAGIC ### RESULT 

# COMMAND ----------

# MAGIC %sql select * from party_b.test_config

# COMMAND ----------

# MAGIC %md
# MAGIC ### CALLING CONFIG EXTRACTOR FUNCTION

# COMMAND ----------

tableconfig=config_extractor("party_b.test_config","party_table_config")
print(tableconfig)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EXTRACTING DATA

# COMMAND ----------

print(tableconfig["database_name"])  