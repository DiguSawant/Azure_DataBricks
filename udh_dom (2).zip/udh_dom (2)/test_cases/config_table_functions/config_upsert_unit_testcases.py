# Databricks notebook source
# MAGIC %md
# MAGIC ###IMPORTING CONFIG UPSERT FUNCTION

# COMMAND ----------

# DBTITLE 0,Importing config_upsert functions
# MAGIC %run /Shared/udh_dom/tech_utility/common_spark_functions

# COMMAND ----------

# %sql 
# create table party_b.unittest_config_test_config(config_name string,config string,created_at timestamp,updated_at timestamp,status string) using delta location "/unittest/dev/config"

# COMMAND ----------

# MAGIC %md
# MAGIC ### TEST CONFIGURATION JSON

# COMMAND ----------

# DBTITLE 0,test configuration json
party_table_config = {
        "database_name":"party_b",
		"target_table":"party",
		"partition_column":"source_system",
		"target_checkpointLocation":"/mnt/fwd_test/silver/customer/party_silver/party/checkpoint/",
        "col_stand":
    {
		"party_id":"ENTITYSEQ",
		"party_source":"$ecom$",
		"party_name":"concat_ws($ $,datavalue_policyHolder_firstName,datavalue_policyHolder_lastName)",
		"party_type_code":"$individual$",
		"customer_flag":"$y$",
		"employee_flag":"$n$",
		"prospect_flag":"$n$",
		"agent_flag":"$y$",
		"email_address":"datavalue_policyHolder_email",
		"udh_active_flag":"$y$",
		"source_system":"$ifwd$",
		"udh_insert_date":"current_timestamp()",
		"udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,party_source,party_name,party_type_code,customer_flag,employee_flag,prospect_flag,agent_flag,email_address,udh_active_flag,source_system,udh_insert_date,udh_update_date"
	}   

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASES OF UPSERT FUNCTION

# COMMAND ----------

import unittest
import warnings
warnings.simplefilter("ignore", ResourceWarning)

spark.sql("truncate table party_b.unittest_config_test_config")
class ConfigUpsertTest(unittest.TestCase):
    
    #check the upsert_function by inserting first record    
    def test_config_upsert_first_record(self):
        config_upsert("party_b.unittest_config_test_config","party_table_config",party_table_config)
        row_count=spark.sql("select count(*) from party_b.unittest_config_test_config;").collect()[0][0]
        active_row_count=spark.sql("select count(*) from party_b.unittest_config_test_config where status='active';").collect()[0][0]
        
        expected_row_count=1
        expected_active_row_count=1
        rowdict={"row_count":row_count,"active_row_count":active_row_count}
        expected_rowdict={"row_count":expected_row_count,"active_row_count":expected_active_row_count}
        self.assertEqual(rowdict,expected_rowdict)
    
    #check the upsert function by inserting second record    
    def test_config_upsert_second_record(self):
        config_upsert("party_b.unittest_config_test_config","party_table_config",party_table_config)
        row_count=spark.sql("select count(*) from party_b.unittest_config_test_config;").collect()[0][0]
        active_row_count=spark.sql("select count(*) from party_b.unittest_config_test_config where status='active';").collect()[0][0]
        expected_row_count=2
        expected_active_row_count=1
        rowdict={"row_count":row_count,"active_row_count":active_row_count}
        expected_rowdict={"row_count":expected_row_count,"active_row_count":expected_active_row_count}
        self.assertEqual(rowdict,expected_rowdict)
    

   

# COMMAND ----------

# MAGIC %md
# MAGIC ### EXECUTING UNITTESTS 

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)