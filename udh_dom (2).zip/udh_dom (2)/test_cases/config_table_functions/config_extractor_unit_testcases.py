# Databricks notebook source
# MAGIC %md
# MAGIC ### IMPORTING CONFIG EXTRACT FUNCTION

# COMMAND ----------

# MAGIC %run /Shared/udh_dom/tech_utility/common_spark_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASE FOR CONFIG_EXTRACT FUNCTION

# COMMAND ----------

import unittest

class ConfigExtractorTest(unittest.TestCase):
    
    #extracting data using config_extract_function
    def test_config_extractor_function(self):
        tableconfig=config_extractor("party_b.unittest_config_test_config","party_table_config")
        actual_result_from_config_extractor=tableconfig["database_name"]
        expected_result_from_config_extractor="party_b"
        self.assertEqual(actual_result_from_config_extractor,expected_result_from_config_extractor)

# COMMAND ----------

# MAGIC %md
# MAGIC ### EXECUTING UNIT TEST CASES

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)