# Databricks notebook source
"""
    Purpose : create unittest cases for CUBE tables
    Input : database names,table names
    Output :tables
"""

# COMMAND ----------

# MAGIC %run ../../usecases/cube/config/config_cube_fna_mvp

# COMMAND ----------

import unittest 
class TestQuoteTable(unittest.TestCase):    
    #checking count of CI product in quote and silver_intermediate.users_data table
    def test_totallead_count (self):
        try:
            source_count_df = spark.sql(f"""select count(distinct JSONVALUE_ID) from {database_name}.{leads_table}
                                        where JSONVALUE_STATUS = 'A'
                                        group by created_time """)
            source_count=source_count_df.collect()[0][0]
        except Exception as e:
            source_count= 0
        
        try:
            target_count_df=spark.sql(f"""select count(distinct JSONVALUE_ID) from {env}_silver.iris_lead_cube_fna_silver
                where  JSONVALUE_STATUS = 'A'
                group by created_time """)
            target_count=target_count_df.collect()[0][0]
        except Exception as e:
            target_count= 0

        self.assertEqual(source_count,target_count)

    def test_totalSubmittedlead_count (self):
        try:
            source_count_df = spark.sql(f"""select count(distinct JSONVALUE_ID) from {database_name}.{leads_table}
                                        where  JSONVALUE_LEADSTATUSCODE == 'S'
                                        and JSONVALUE_STATUS = 'A'
                                        group by created_time """)
            source_count=source_count_df.collect()[0][0]
        except Exception as e:
            source_count= 0
        
        try:
            target_count_df=spark.sql(f"""select count(distinct JSONVALUE_ID) from {env}_silver.iris_lead_cube_fna_silver
                where  JSONVALUE_LEADSTATUSCODE == 'S' and JSONVALUE_STATUS = 'A'
                group by created_time """)
            target_count=target_count_df.collect()[0][0]
        except Exception as e:
            target_count= 0

        self.assertEqual(source_count,target_count)

    def test_totalAgent_count (self):
        try:
            source_count_df = spark.sql(f"""select count( distinct JSONVALUE_AGENTCODE) from {database_name}.{agent_table}
                                        where  created_time is not null and JSONVALUE_AGENTCODE is not null
                                         """)
            source_count=source_count_df.collect()[0][0]
        except Exception as e:
            source_count= 0
        
        try:
            target_count_df=spark.sql(f"""select count( distinct JSONVALUE_AGENTCODE) from {env}_silver.iris_lead_cube_fna_silver
                where JSONVALUE_AGENTCODE is not null
                 """)
            target_count=target_count_df.collect()[0][0]
        except Exception as e:
            target_count= 0

        self.assertEqual(source_count,target_count)

    def test_totalProduct_count (self):
        try:
            source_count_df = spark.sql(f"""select count(distinct JSONVALUE_ID) from {database_name}.{products_table}
                                        where JSONVALUE_STATUS = 'A'
                                        group by created_time """)
            source_count=source_count_df.collect()[0][0]
        except Exception as e:
            source_count= 0
        
        try:
            target_count_df=spark.sql(f"""select count(distinct JSONVALUE_ID) from {env}_silver.iris_lead_cube_fna_silver
                where  JSONVALUE_STATUS = 'A'
                group by created_time """)
            target_count=target_count_df.collect()[0][0]
        except Exception as e:
            target_count= 0

        self.assertEqual(source_count,target_count)        
        

# COMMAND ----------

unittest.main(argv=[''],verbosity=2,exit=False)