# Databricks notebook source
# MAGIC %md
# MAGIC # Test cases

# COMMAND ----------

1. This folder will contain the test cases for common Python or PySpark functions/accelerators
2. This are generic codes which are factory driven