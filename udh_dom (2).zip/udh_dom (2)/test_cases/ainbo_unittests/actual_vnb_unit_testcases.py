# Databricks notebook source
# MAGIC %md
# MAGIC ### ACTUAL VNB UNIT TESTING

# COMMAND ----------

import unittest 

# COMMAND ----------

class TestActualVnbTable(unittest.TestCase):    
    #checking rein_diver_column present in config table
    def test_vnb_af_rein_diver_column_present(self):
        df=spark.sql("""select * from dev_silver.actual_vnb_silver""")
        self.assertTrue(("VNB_AF_REIN_DIVER" in df.columns),True)
    #checking policy and actual_vnb present in config table
    def test_check_actual_vnb_policy_number_column_in_succes_table(self):
        df=spark.sql("""select * from dev_ainbo_silver.success_silver""")
        self.assertTrue(("ACTUAL_VNB" in df.columns) and ("POLICY_NO" in df.columns),True)
    #checking the actual vnb for particular policy number
    def test_check_actual_vnb_for_particular_poclicy_id(self):
        df=spark.sql("""select * from dev_ainbo_silver.success_silver""")
        actual_vnb=df.filter(df["POLICY_NO"]=='B11015791').select("ACTUAL_VNB").collect()[0][0]
        self.assertTrue((actual_vnb=='6143.00'),True)
    

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)