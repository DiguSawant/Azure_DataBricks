# Databricks notebook source
import unittest 
class TestQuoteTable(unittest.TestCase):    
    #checking count of CI product in quote and silver_intermediate.users_data table
    def test_CI_product_count (self):
        count_CI=spark.sql("""select after_product_type , count(*) from silver_intermediate.users_data 
where  after_user_view = 'quote.quickQuestions' and after_status = 'proposal' and after_product_type='3CI'
group by after_product_type""")
        print(count_CI)
        
        

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)

# COMMAND ----------

# MAGIC %sql select after_product_type , count(*) from silver_intermediate.users_data 
# MAGIC where  after_user_view = 'quote.quickQuestions' and after_status = 'proposal' and after_product_type='HA'
# MAGIC group by after_product_type

# COMMAND ----------

# MAGIC %sql select * from ainbo_silver.quote