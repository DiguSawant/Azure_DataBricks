# Databricks notebook source
# MAGIC %md
# MAGIC ###IMPORTING REQUIRED PACKAGES

# COMMAND ----------

import unittest

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASES FOR PARTY TABLE

# COMMAND ----------

class PartyTableUnitTesting(unittest.TestCase):
    
    #check if all the values in the party_id column are distinct as it is unique identifier
    def test_party_id_unique_identifier(self):
        row_count=spark.sql("select count(*) from party_silver.party;").collect()[0][0]
        expected_row_count=spark.sql("select count(DISTINCT party_id) from party_silver.party;").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in party_type_code column is individual
    def test_party_type_code_value_individual(self):
        row_count=spark.sql("select count(*) from party_silver.party;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.party where party_type_code='individual';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the flag value for customer_flag column is 'y' for all records
    def test_flag(self):
        row_count=spark.sql("select count(*) from party_silver.party;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.party where customer_flag='y';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in party_source column is ecom for all records
    def test_party_source_value_iFWD(self):
        row_count=spark.sql("select count(*) from party_silver.party;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.party where party_source='ecom';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in source_system column is iFWD for all records
    def test_source_system_value_ifwd(self):
        row_count=spark.sql("select count(*) from party_silver.party;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.party where source_system='ifwd';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)    

# COMMAND ----------

# MAGIC %md
# MAGIC ###EXECUTING ALL TESTCASES

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)