# Databricks notebook source
# MAGIC %md
# MAGIC ### IDENTITY TABLE UNITTESTING

# COMMAND ----------

import unittest 
class TestIdentityTable(unittest.TestCase):
    #checking individual_sid columns values are uniq.
    def test_check_uniq_identity_sid (self):
        row_count=spark.sql("select count(*) from party_silver.identity;").collect()[0][0]
        expected_count=spark.sql("select count(DISTINCT identity_sid) from party_silver.identity;").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
    
    #checking columns is filled with null values.
    def test_check_null_column(self):
        row_count=spark.sql("select count(*) from party_silver.identity;").collect()[0][0]
        expected_count=spark.sql("select count(*) from party_silver.identity where ident_type='null';").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
    

# COMMAND ----------

# MAGIC %md
# MAGIC ### Executing UNITTEST

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)