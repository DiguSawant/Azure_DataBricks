# Databricks notebook source
# MAGIC %sql select * from dev_silver.users_data_silver

# COMMAND ----------

# MAGIC %md
# MAGIC ### BANK ACCOUNT TABLE UNITTESTING

# COMMAND ----------


import unittest 
class TestBankAccountTable(unittest.TestCase):    
    #checking bank_account_key columns values are uniq.
    def test_check_uniq_bank_account_key (self):
        row_count=spark.sql("select count(*) from party_silver.bank_account;").collect()[0][0]
        expected_count=spark.sql("select count(DISTINCT bank_account_key) from party_silver.bank_account;").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
        
    #checking udh_active_flag filled with flag y/n.
    def test_check_udh_activ_flag_column(self):
        row_count=spark.sql("select count(*) from party_silver.bank_account;").collect()[0][0]
        expected_count=spark.sql("select count(DISTINCT bank_account_key) from party_silver.bank_account where udh_active_flag in ('y','n')  ;").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
        
    #checking columns is filled with null values.
    def test_check_null_column(self):
        row_count=spark.sql("select count(*) from party_silver.bank_account;").collect()[0][0]
        expected_count=spark.sql("select count(*) from party_silver.bank_account where bank_code='null' and bank_branch_code='null' and bank_account_type='null' and main_currency=='null';").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Executing UNITTEST

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)