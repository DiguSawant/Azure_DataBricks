# Databricks notebook source
# MAGIC %md
# MAGIC ### INDIVIDUAL TABLE UNITTESTING

# COMMAND ----------

import unittest 
class TestIndividualTable(unittest.TestCase):
    
    #checking concantination of coulmns.
    def test_concantination_of_column(self):
        first_name=spark.sql("select first_name from party_silver.individual where party_id=9598").collect()[0][0]
        last_name=spark.sql("select last_name from party_silver.individual where party_id=9598").collect()[0][0]
        full_name=spark.sql("select full_name from party_silver.individual where party_id=9598").collect()[0][0]
        expected_full_name=first_name+' '+last_name
        self.assertTrue((expected_full_name==full_name),True)
    
    #checking individual_sid columns values are uniq.
    def test_check_uniq_individual_sid (self):
        row_count=spark.sql("select count(*) from party_silver.individual;").collect()[0][0]
        expected_count=spark.sql("select count(DISTINCT individual_sid) from party_silver.individual;").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
        
    #checking udh_active_flag filled with flag y.
    def test_check_udh_activ_flag_column(self):
        row_count=spark.sql("select count(*) from party_silver.individual;").collect()[0][0]
        expected_count=spark.sql("select count(DISTINCT individual_sid) from party_silver.individual where udh_active_flag in ('y','n')  ;").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)
        
    #checking columns is filled with null values.
    def test_check_null_column(self):
        row_count=spark.sql("select count(*) from party_silver.individual;").collect()[0][0]
        expected_count=spark.sql("select count(*) from party_silver.individual where middle_name='null';").collect()[0][0]
        self.assertTrue((expected_count==row_count),True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Executing UNITTEST

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)