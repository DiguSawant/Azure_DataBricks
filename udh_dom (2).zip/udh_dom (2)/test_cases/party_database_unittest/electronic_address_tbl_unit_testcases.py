# Databricks notebook source
# MAGIC %md
# MAGIC ###IMPORTING REQUIRED PACKAGES

# COMMAND ----------

import unittest

# COMMAND ----------

# MAGIC %md
# MAGIC ### UNITTEST CASES FOR electronic_address TABLE

# COMMAND ----------

class ElectronicAddressTableUnitTesting(unittest.TestCase):
    
    #check if the value in address_type column is 'mobile' for all records
    def test_address_type_value_mobile(self):
        row_count=spark.sql("select count(*) from party_silver.electronic_address;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.electronic_address where address_type='mobile';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in phone_country_code column is '66' for all records
    def test_phone_country_code_value_66(self):
        row_count=spark.sql("select count(*) from party_silver.electronic_address;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.electronic_address where phone_country_code='66';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in contact_via_phone column is 'y' for all records
    def test_contact_via_phone_value_y(self):
        row_count=spark.sql("select count(*) from party_silver.electronic_address;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.electronic_address where contact_via_phone='y';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)
    
    #check if the value in phone_area_code column is 'null' for all records
    def test_phone_area_code_value_null(self):
        row_count=spark.sql("select count(*) from party_silver.electronic_address;").collect()[0][0]
        expected_row_count=spark.sql("select count(*) from party_silver.electronic_address where phone_area_code='null';").collect()[0][0]
        self.assertTrue(row_count == expected_row_count, True)    

# COMMAND ----------

# MAGIC %md
# MAGIC ###EXECUTING ALL TESTCASES

# COMMAND ----------

r=unittest.main(argv=[''],verbosity=2,exit=False)

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from party_silver.electronic_address;