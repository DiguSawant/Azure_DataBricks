# Databricks notebook source
# MAGIC %run "/Users/UDHBLAZECLAN07@fwd.com/jdbc batch load/common functions"

# COMMAND ----------

# MAGIC %run "/Users/UDHBLAZECLAN07@fwd.com/jdbc batch load/config"

# COMMAND ----------

non_nbmconfig=databaseconfig["nonnbm"]

# COMMAND ----------

query=""" select   a.entityseq as et_entityseq,a.entityname as et_entityname,a.indexkey as et_indexkey,a.sortkey as et_sortkey,a.versionid as  et_versionid ,a.guid as et_guid  ,a.application as  et_application,a.systemcreateddt as et_systemcreateddt ,a.systemupdateddt as et_systemupdateddt,b.dataseq as dt_dataseq,b.entityseq as dt_entityseq,b.datakey as dt_datakey_,b.datavalue as dt_datavalue ,b.versionid as dt_versionid,b.guid as dt_guid
   from JEEFramework_La.dbo.NOSQLENTITY a, 
JEEFramework_La.dbo.NOSQLDATA b 
where  a.ENTITYSEQ = b.ENTITYSEQ   """

column_check_query=""" select top 1  a.entityseq as et_entityseq,a.entityname as et_entityname,a.indexkey as et_indexkey,a.sortkey as et_sortkey,a.versionid as  et_versionid ,a.guid as et_guid  ,a.application as  et_application,a.systemcreateddt as et_systemcreateddt ,a.systemupdateddt as et_systemupdateddt,b.dataseq as dt_dataseq,b.entityseq as dt_entityseq,b.datakey as dt_datakey_,b.datavalue as dt_datavalue ,b.versionid as dt_versionid,b.guid as dt_guid,'load_date' as 'load_date'
   from JEEFramework_La.dbo.NOSQLENTITY a, 
JEEFramework_La.dbo.NOSQLDATA b 
where  a.ENTITYSEQ = b.ENTITYSEQ """


count_query="""  select count(a.entityseq) as count
   from JEEFramework_La.dbo.NOSQLENTITY a, 
JEEFramework_La.dbo.NOSQLDATA b 
where  a.ENTITYSEQ = b.ENTITYSEQ and a.systemupdateddt <= '2023-04-03T18:49:34.710' """


# COMMAND ----------

min_max_df=read_from_MSSQL(host=non_nbmconfig["host"],port=non_nbmconfig["port"],database_name=non_nbmconfig["database_name"],user_id=non_nbmconfig["username"],password=non_nbmconfig["password"],numPartitions=None,query=column_check_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

# COMMAND ----------

import unittest 
class TestCheckEmail(unittest.TestCase):

#Verifying count is same at the source and the sink delta table
    def test_check_count(self):
        source_count_df  = read_from_MSSQL(host=non_nbmconfig["host"],port=non_nbmconfig["port"],database_name=non_nbmconfig["database_name"],user_id=non_nbmconfig["username"],password=non_nbmconfig["password"],numPartitions=None,query=count_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql("select count(1) from dev_initial_load_bronze.nosql_data_entity_bronze")
        target_count=target_count_df.collect()[0][0]


        self.assertEqual(source_count,target_count)

#Verifying columns is same at the source and the sink delta table
    def test_check_columns(self):
        
        source_count_df  = read_from_MSSQL(host=non_nbmconfig["host"],port=non_nbmconfig["port"],database_name=non_nbmconfig["database_name"],user_id=non_nbmconfig["username"],password=non_nbmconfig["password"],numPartitions=None,query=column_check_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

        source_columns=source_count_df.columns

        target_count_df=spark.sql("select * from dev_initial_load_bronze.nosql_data_entity_bronze limit 1")
        target_columns=target_count_df.columns


        self.assertEqual(source_columns,target_columns)

    

# COMMAND ----------

unittest.main(argv=[''],verbosity=2,exit=False)

# COMMAND ----------

# MAGIC %sql select max(et_systemupdateddt) from dev_initial_load_bronze.nosql_data_entity_bronze