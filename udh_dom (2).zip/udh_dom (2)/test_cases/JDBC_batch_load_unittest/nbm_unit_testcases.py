# Databricks notebook source
# MAGIC %run "/Users/UDHBLAZECLAN07@fwd.com/jdbc batch load/common functions"

# COMMAND ----------

# MAGIC %run "/Users/UDHBLAZECLAN07@fwd.com/jdbc batch load/config"

# COMMAND ----------

config=databaseconfig["nbm"]

# COMMAND ----------

query="""select * from dbo.Users_Data  """

column_check_query=""" select top 1 *,'load_date' as 'load_date' from dbo.Users_Data"""


count_query="""  select count (1) as count  from NBM_FE_UAT.dbo.Users_Data where Submitted_Date <= '2023-04-03T17:16:40' """


# COMMAND ----------

min_max_df=read_from_MSSQL(host=config["host"],port=config["port"],database_name=config["database_name"],user_id=config["username"],password=config["password"],numPartitions=None,query=column_check_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

# COMMAND ----------

import unittest 
class TestCheckEmail(unittest.TestCase):

#Verifying count is same at the source and the sink delta table
    def test_check_count(self):
        source_count_df  = read_from_MSSQL(host=config["host"],port=config["port"],database_name=config["database_name"],user_id=config["username"],password=config["password"],numPartitions=None,query=count_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

        source_count=source_count_df.collect()[0][0]

        target_count_df=spark.sql("select count(1) from dev_initial_load_bronze.users_data ")
        target_count=target_count_df.collect()[0][0]


        self.assertEqual(source_count,target_count)

#Verifying columns is same at the source and the sink delta table
    def test_check_columns(self):
        
        source_count_df  = read_from_MSSQL(host=config["host"],port=config["port"],database_name=config["database_name"],user_id=config["username"],password=config["password"],numPartitions=None,query=column_check_query,table=None,lowerBound=None,upperBound=None,partitionColumn=None)

        source_columns=source_count_df.columns

        target_count_df=spark.sql("select * from dev_initial_load_bronze.users_data  limit 1")
        target_columns=target_count_df.columns


        self.assertEqual(source_columns,target_columns)

    

# COMMAND ----------

unittest.main(argv=[''],verbosity=2,exit=False)