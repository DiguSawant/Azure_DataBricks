# Databricks notebook source
# MAGIC %md
# MAGIC #**json flatten**

# COMMAND ----------

1. This folder contains all the seperate test cases for all data quality function
2. common use case for all data quality functions