# Databricks notebook source
# MAGIC %md
# MAGIC ## JSON FLATTEN
# MAGIC * Doc_Type : ETL
# MAGIC * Tech Description : This notebook is flatten the json of array type.
# MAGIC * Pre_requisites : Accepts the spark dataframe.
# MAGIC * Inputs : Spark dataframe.
# MAGIC * Output : Spark dataframe with flatten json.
# MAGIC * author : 'Blazeclan'

# COMMAND ----------

# MAGIC %md
# MAGIC ## IMPORTING JSON_FLATTEN FUNCTION

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/json_flatten

# COMMAND ----------

# MAGIC %run /Shared/tech_utility/aes

# COMMAND ----------

# DBTITLE 1,Importing notebook secret_key_env_param
# MAGIC %run /Shared/tech_utility/secret_key_env_param

# COMMAND ----------

# DBTITLE 1,Importing notebook common_spark_functions
# MAGIC %run /Shared/tech_utility/common_spark_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## DATASET

# COMMAND ----------

# DBTITLE 0,Dataset
input_path = "dbfs:/mnt/fwd_test/jeeframwork_nosqldata/TH.UAT.ODS.IFWD.dbo.NOSQLDATA/year=2023/month=02/day=06/TH.UAT.ODS.IFWD.dbo.NOSQLDATA+1+0001731586.json"
input_data_frame=read_json(location=input_path,multiline=False)

# COMMAND ----------

expected_columns=['before',
 'op',
 'transaction',
 'ts_ms',
 'after_DATAKEY',
 'after_DATASEQ',
 'after_DATAVALUE',
 'after_ENTITYSEQ',
 'after_GUID',
 'after_VERSIONID',
 'source_change_lsn',
 'source_commit_lsn',
 'source_connector',
 'source_db',
 'source_event_serial_no',
 'source_name',
 'source_schema',
 'source_sequence',
 'source_snapshot',
 'source_table',
 'source_ts_ms',
 'source_version']

# COMMAND ----------

# MAGIC %md
# MAGIC ## COLUMNS BEFORE FLATTENING

# COMMAND ----------

# DBTITLE 0,Before Flattening Columns
input_data_frame.columns

# COMMAND ----------

# MAGIC %md
# MAGIC ## COLUMNS AFTER FLATTENING

# COMMAND ----------

# DBTITLE 0,After Flattening Columns
# calling json flattening function
flattened_data_frame = flatten_all_type_json(input_data_frame)
flattened_data_frame.columns

# COMMAND ----------

print("\n\t\t\t\t#####Input DataFrame#####\n")
input_data_frame.display()

print("\n\t\t\t\t#####Output Flattened DataFrame#####\n")
flattened_data_frame.display()

# COMMAND ----------

# DBTITLE 1,Importing IFWD config
# MAGIC %run /Shared/udh_ingestion/config/ifwd_config

# COMMAND ----------

# DBTITLE 1,Fetch Values from Config
schema = config_nosql_data['bronze_l']['data_val_schema']
encrypted_parent_column = config_nosql_data['bronze_l']['encrypted_parent_column']
encrypted_column = config_nosql_data['bronze_l']['encrypted_column']
select_cols = config_nosql_data['bronze_l']['select_cols']
explode_cols = config_nosql_data['bronze_l']['explode_cols'] 
decrypted_column = encrypted_parent_column + "_" + encrypted_column 

# COMMAND ----------

decrypt_df = flattened_data_frame.select(select_cols).withColumn(encrypted_column,aes_decrypt(decrypted_column))
decrypt_df.select(col("after_DATAKEY").alias("datakey"),col("after_DATAVALUE").alias("before_encr_datavalue"),col("datavalue").alias("datavalue")).display()

# COMMAND ----------

struct_df = decrypt_df.withColumn(encrypted_column,from_json(encrypted_column, schema))

explode_colms = encrypted_column + "." + explode_cols

value_df = struct_df.withColumn(explode_cols,explode(col(explode_colms)))
value_df.display()