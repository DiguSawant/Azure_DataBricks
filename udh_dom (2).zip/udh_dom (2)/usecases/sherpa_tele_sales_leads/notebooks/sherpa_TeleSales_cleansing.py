# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ../config/config_sherpa

# COMMAND ----------

# DBTITLE 1,running aes notebook
# MAGIC %run ../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook others_file
# MAGIC %run ./others_file

# COMMAND ----------

# MAGIC %run ./join_sorDB

# COMMAND ----------

# DBTITLE 1,importing requireds
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,read the data from given source location for sheet_2
try:
   #load most recent updated file from given directory using find_most_recent_file() 
    sheet_2_file_path = find_most_recent_file(sheet_2_source_path)
    sheet_2_df = read_csv(location=sheet_2_file_path,infer_schema=False)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,drop if all the null fields
try:
    sheet_2_df = sheet_2_df.dropDuplicates().dropna(how='all')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,trim the fileds using trim_fields function
try:
    sheet_2_df = trim_fields(df=sheet_2_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,normalize the columns(replacing dot,hyphen,and spaces by underscore)
try:
    sheet_2_df = normalize_column_name(sheet_2_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,format column cellphone
try:
    sheet_2_df = sheet_2_df.withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,calculate the age on given column and format
# try:
#     sheet_2_df = age_calculation(df=sheet_2_df,column=sheet_2_dob, date_format=sheet_2_date_format)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,filter the age between 20 and 60
try:
    filtered_sheet_2_df = sheet_2_df.where(col(sheet_2_age).between(20, 60))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,apply the data quality rule for phone_no
try:
    dq_sheet_2_df = filtered_sheet_2_df.where((udf_check_phone_number(sheet_2_phone_no, lit(mobilecode_list_str))==True))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,concating the FirstName and LastName as FullName and format column CellPhone
try:
    file_date = extract_date(sheet_2_file_path)
    concated_sheet_2_df = dq_sheet_2_df.withColumn(sheet_2_fullName, concat_ws(' ',sheet_2_firstName,sheet_2_lastName))\
                                       .withColumn("file_date",lit(file_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#Drop duplicate phone number & full_name
try:
    concated_sheet_2_df=concated_sheet_2_df.dropDuplicates([sheet_2_phone_no]).dropDuplicates([sheet_2_fullName])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing contacted_df from others_file
try:
    # joining the dataframe to drop the matching records with contacted dataframe
    sheet_2_contacted_df = concated_sheet_2_df.join(contacted_df, concated_sheet_2_df.
                                                    FullName == contacted_df.FullName, "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing blacklist_df from others_file
try:
    # joining the dataframe to drop the matching records with blacklist dataframe
    sheet_2_blacklist_df = sheet_2_contacted_df.join(blacklist_df, (sheet_2_contacted_df.UserId == blacklist_df.national_id) 
                                                     | (sheet_2_contacted_df.FullName == blacklist_df.FullName), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# importing dnc_df from others_file
try:
    # joining the dataframe to drop the matching records with do-not-call-list dataframe 
    sheet_2_dnc_df = sheet_2_blacklist_df.join(dnc_df,(sheet_2_blacklist_df.FullName == dnc_df.FullName) 
                                               | (sheet_2_blacklist_df.CellPhone == dnc_df.phone_no), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read data from sorDB table named la_tb_pty_individual_curr_dim
try:
    individual_df = spark.sql(''' select * from delta.la_tb_pty_individual_curr_dim ''')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# concate cirst_name and last_name as FullName for individual_df
try:
    individual_df = individual_df.withColumn("FullName",concat_ws(" ",aes_decrypt(col("first_name")),aes_decrypt(col("last_name"))))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_dnc_df and individual_Df

try:
    sheet_2_sordb = sheet_2_dnc_df.join(individual_df, sheet_2_dnc_df.FullName == individual_df.FullName, 'anti')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# appending column ENLable for update remark as per PreferredTime
try:
    sheet_2_sordb = sheet_2_sordb.withColumn("ENLable",when(sheet_2_sordb.PreferredTime == 1, '8am-12pm')\
                                                  .when(sheet_2_sordb.PreferredTime == 2, '12pm-1pm')\
                                                   .when(sheet_2_sordb.PreferredTime == 3, '1pm-3pm')\
                                                  .when(sheet_2_sordb.PreferredTime == 4, '3pm-5pm')\
                                                  .when(sheet_2_sordb.PreferredTime == 5, '5pm-8pm')\
                                                  .when(sheet_2_sordb.PreferredTime == 6, 'AnyTime')\
                                                  .when(sheet_2_sordb.PreferredTime == 0, 'N/A'))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # read telesales data 
try:
    telesales_true_system_df = read_json(location = telesales_true_happiness_path, multiline=False)
    telesales_true_system_df = telesales_true_system_df.withColumn("DTCOutToTSR",explode("DTCOutToTSR")).select("DTCOutToTSR.*")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # read telesales data 
try:
    telesales_sherpa_system_df = read_json(location = telesale_source_path_json, multiline=False)
    telesales_sherpa_system_df = telesales_sherpa_system_df.withColumn("DTCOutToTSR",explode("DTCOutToTSR")).select("DTCOutToTSR.*")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    telesales_system_df = telesales_true_system_df.unionByName(telesales_sherpa_system_df, allowMissingColumns=True)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    telesales_system_df = telesales_system_df.withColumn("FullName",concat_ws(" ",col("FirstName"),col("LastName")))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # joining the dataframe to drop the matching records with teleSystem dataframe
    sheet_2_telesales_system_df = sheet_2_sordb.join(telesales_system_df, sheet_2_sordb.FullName == telesales_system_df.FullName, 'anti')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_dnc_df and sorDB_Df
#importing the sorDB_existing_cust_check from join_sorDB notebook
try:
    sheet_2_sordb_existing_cust = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'semi').withColumn("Remark",lit("Existing FWD customer "))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_contacted_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    sheet_2_sordb_1 = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId== sorDB_existing_cust_check.owner_national_id, 'anti').withColumn("Remark",concat_ws('-',col('ExpectedProductName'),col('RecommendedCoverage'),col('ENLable')))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# union spark dataframe sheet_2_sordb_existing_cust and sheet_2_sordb_1
try:
    sheet_2_union_df = sheet_2_sordb_existing_cust.unionByName(sheet_2_sordb_1, allowMissingColumns=True)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# assign vaiables to create diffrent conditions as per final expected result
PartnerName_hyphen = concat_ws('-', lit(Partner), lit(Campaign))
#PartnerName = concat_ws('', lit(Partner), lit(Campaign))
PartnerName=lit(Campaign)
concat_file_date = concat_ws('',lit("Daily"), col("file_date").substr(1,6))

# COMMAND ----------

# create column PartnerName and DTCCampaignId
try:
    sheet_2_DTCCampaignId_df = sheet_2_union_df.withColumn("PartnerName", PartnerName)\
                                .withColumn("DTCCampaignId_1", concat_file_date)\
                                .withColumn("DTCCampaignId", PartnerName)\
                                .withColumn("DTCCampaignId", concat_ws('-', col("DTCCampaignId"),col("DTCCampaignId_1"),lit("001"), col("file_date").substr(1,6))).drop("DTCCampaignId_1")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# create column userCRM
try:
    sheet_2_userCRM_df = sheet_2_DTCCampaignId_df\
                         .withColumn("userCRM", concat_ws('',lit("Load#"), col("PartnerName"), col("file_date")))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# create column id to generate unique number that will be use to create prefix and suffix conditions
try:
    w = Window().orderBy(lit('1'))
    sheet_2_userCRM_df = sheet_2_userCRM_df.withColumn("id", row_number().over(w))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# create column ActivityId
max_suffix_1 = 999999
max_suffix_2 = 999999

try:
    # calculate the values for each suffix based on current row number
    suffix_2_df = sheet_2_userCRM_df.withColumn("pattern", PartnerName_hyphen)\
                                    .withColumn("pattern_1", concat_ws('',col("pattern"), col("file_date")))\
                                    .withColumn("suffix_2", lpad(when(col("id") <= max_suffix_1, col("id"))\
                                    .otherwise((col("id") - max_suffix_1) % (max_suffix_2 + 1)), 6, "0"))
    
    suffix_1_df = suffix_2_df.withColumn("suffix_1", lpad(when(col("id") <= max_suffix_1, lit(0))\
                             .otherwise(col("id") - max_suffix_1), 6, "0"))

    # concanate the prefix and suffixes 
    sheet_2_ActivityId_df = suffix_1_df.withColumn("ActivityId", concat_ws("-", col("pattern_1"), col("suffix_1"), col("suffix_2")))

    # create userCRMId column
    sheet_2_userCRMId_df = sheet_2_ActivityId_df.withColumn("userCRMId", concat_ws('-', col('userCRM'),col('suffix_2')))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#select the required column using col_standarization method
try:
    sheet_2_standDf = col_standarization(df = sheet_2_userCRMId_df, columns = json_col_standarization)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,select all the target fields
#create party table dataframe with all columns of party table
try:
    sheet_2_parttion_df = sheet_2_standDf.distinct().withColumn("partition_date",lit(file_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#select all columns that is required for expected result
try:
    select_cols_df = sheet_2_parttion_df.select(*select_columns, "partition_date").withColumn("BirthDate",date_format(add_months(to_date(lit('2023-01-01')), col("Age")*-12), "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'"))
except Exception as e:
    raise Exception(e) 

# COMMAND ----------

# grouped results into array with DTCOutToTSR as parent object
grouped_df = select_cols_df.groupBy("partition_date")\
                            .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","BirthDate","Remark"))\
                            .alias("DTCOutToTSR"))

# COMMAND ----------

# # write the telesales_partition_df as json in given location 
try:
    path = telesale_source_path_json
    write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = path, mode="append", partitionColumn=["partition_date"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# define current date and time
from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

# get current timestamp
cur_time = spark.sql("SELECT current_timestamp()").collect()[0][0]

# COMMAND ----------

sheet_2_df=sheet_2_df.withColumn("Package",split(col("DTCCampaignId"),'_')[0])

# COMMAND ----------

##############delete this cell
# write lead recived data into table
try:
    sheet_2_df = campaign_reco(sheet_2_df, col_name, col_dict)
    sheet_2_df\
            .groupBy("Package")\
            .count()\
            .withColumn("SOURCE_SYSTEM",lit("SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write\
            .mode("append")\
            .saveAsTable(lead_received)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write lead passed to telesales data into table
try:
    sheet_2_parttion_df=sheet_2_parttion_df.withColumn("Package",split(col("DTCCampaignId"),'-')[0])
    sheet_2_parttion_df = campaign_reco(sheet_2_parttion_df, col_name, col_dict)
    sheet_2_parttion_df\
                .groupBy("Package")\
                .count()\
                .withColumn("SOURCE_SYSTEM",lit("SHERPA"))\
                .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
                .withColumn("BATCH_ID",lit(curr_date))\
                .write\
                .mode("append")\
                .saveAsTable(lead_passed)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write total leads passed into table
try:
    sheet_2_parttion_df\
            .select(col("UserId").alias("ID_CARD"),"LeadCreateDate","Package")\
            .withColumn("ID_CARD",col("ID_CARD").cast(LongType()))\
            .withColumn("LeadCreateDate",col("LeadCreateDate").cast(TimestampType()))\
            .withColumn("UDH_CUST_FIND_TIME",lit(None).cast(TimestampType()))\
            .withColumn("SOURCE_SYSTEM",lit("SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write.format("delta")\
            .mode("append")\
            .saveAsTable(total_leased_passed)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# get the count and and sum of count for ape 
try:
    count_cust_sold_policy = spark.sql(f"""
                                            select t.Package as PACKAGE,count(s.policy_id) as COUNT,sum(cast((next_premium_amt*billing_frequency_code) as DECIMAL(38,2))) as APE
                                                from
                                                {total_leased_passed} t
                                                join
                                                (select distinct policy_id,next_premium_amt,billing_frequency_code,date,owner_national_id from sorDB_view) as s
                                                on t.ID_CARD = s.owner_national_id
                                                where s.date >= to_date(LeadCreateDate)
                                                and t.udh_cust_find_time IS NULL
                                                group by t.Package
                                        """)

    # write sum of count the policy sold to customer
    count_cust_sold_policy\
            .withColumn("SOURCE_SYSTEM",lit("SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write.format("delta")\
            .mode("append")\
            .saveAsTable(sum_ape)
except Exception as e:
    raise Exception(e)




# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_telesales_silver.cust_sold_sum_ape_policy

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_telesales_gold.vw_telesales_conversion
# MAGIC