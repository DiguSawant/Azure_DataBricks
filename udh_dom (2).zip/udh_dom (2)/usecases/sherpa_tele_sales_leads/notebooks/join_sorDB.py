# Databricks notebook source
# DBTITLE 1,running notebook aes
# MAGIC %run ../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run ../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running Notebook config
# MAGIC %run ../config/config_sherpa

# COMMAND ----------

try:
    # get the data from delta.il_tb_pty_identity_curr_dim into il_identity dataframe
    # il_identity =  spark.sql(f"""select * from {sorDb}.{il_identity_table} """)
    # get the data from delta.la_tb_pty_identity_curr_dim into la_identity dataframe
    la_identity =  spark.sql(f"""select * from {sorDb}.{la_identity_table} """)
    # union il_identity and la_identity
    # merge_identity_df = il_identity.unionByName(la_identity, allowMissingColumns=True)
    # creating temporary view 
    la_identity.createOrReplaceTempView(f"{identity_temp_table}")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # get the data from delta.li_tb_agrt_policy_curr_dim li_policy dataframe
    # il_policy =  spark.sql(f"""select * from {sorDb}.{il_policy_table} """)
    # get the data from delta.la_tb_agrt_policy_curr_dim into la_policy dataframe
    la_policy =  spark.sql(f"""select * from {sorDb}.{la_policy_table} """)
    # union il_policy and la_policy
    # merge_policy_df = il_policy.unionByName(la_policy, allowMissingColumns=True)
    # creating temporary view 
    la_policy.createOrReplaceTempView(f"{policy_temp_table}")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

coverage_temp_table='coverage'

# COMMAND ----------

try:
    # get the data from delta.il_tb_agrt_coverage_curr_dim into li_policy dataframe
    # il_covergae =  spark.sql(f"""select * from {sorDb}.il_tb_agrt_coverage_curr_dim """)
    # get the data from delta.la_tb_agrt_coverage_curr_dim into la_policy dataframe
    la_coverage =  spark.sql(f"""select * from {sorDb}.la_tb_agrt_coverage_curr_dim """)
    # union il_policy and la_policy
    # merge_coverage_df = il_covergae.unionByName(la_coverage, allowMissingColumns=True)
    # creating temporary view 
    la_coverage.createOrReplaceTempView(f"{coverage_temp_table}")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# %sql
# select * from delta.la_tb_agrt_coverage_curr_dim cov
# join delta.la_tb_agrt_policy_curr_dim pol on  aes_decrypt(cov.policy_id) = aes_decrypt(pol.policy_id)
# join delta.la_tb_pty_identity_curr_dim ident on pol.main_policy_owner_id = aes_decrypt(ident.party_id)

# COMMAND ----------

# try:
#     #join both policy_temp_table and identity_temp_table
#     joinDf = spark.sql(f"""select distinct aes_decrypt(p.POLICY_ID) as policy_id, p.MAIN_POLICY_OWNER_ID as owner_id, p.POLICY_ISSUE_DATE as issue_date, aes_decrypt(i.IDENTITY_NUM) as owner_national_id,p.next_premium_amt as next_premium_amt,cast(p.billing_frequency_code as int) as billing_frequency_code,c.plan_code from {policy_temp_table} p inner join {identity_temp_table} i on p.MAIN_POLICY_OWNER_ID = aes_decrypt(i.PARTY_ID) join {coverage_temp_table} c on aes_decrypt(c.policy_id)=aes_decrypt(p.policy_id) """)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

try:
    #join both policy_temp_table and identity_temp_table
    joinDf = spark.sql(f"""select 
        distinct aes_decrypt(p.POLICY_ID) as policy_id, 
        p.MAIN_POLICY_OWNER_ID as owner_id, 
        p.POLICY_ISSUE_DATE as issue_date, 
        aes_decrypt(i.IDENTITY_NUM) as owner_national_id,
        p.next_premium_amt as next_premium_amt,
        cast(p.billing_frequency_code as int) as billing_frequency_code,c.plan_code 
    from 
        {policy_temp_table} p 
    inner join {identity_temp_table} i 
        on p.MAIN_POLICY_OWNER_ID = aes_decrypt(i.PARTY_ID) 
    left join {coverage_temp_table} c 
        on aes_decrypt(c.policy_id)=aes_decrypt(p.policy_id) """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # convert issue_date into date with to_date() using epoc_to_date() udf
    dateDf = joinDf.withColumn('date', to_date(udf_epoch_to_date("issue_date")))
    # count day diffrence from current_date to date using datediff()
    dayDf = dateDf.withColumn("day", datediff(current_date(),'date'))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # create tmporary view 
    dayDf.createOrReplaceTempView(f"{sorDb_temp_view}")
    # filter the data where issue_date is in last 180
    sorDB_Df = spark.sql(f"""select * from {sorDb_temp_view} where day <= 180 """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # create tmporary view 
#     dayDf.createOrReplaceTempView(f"{sorDb_temp_view}")
    # filter the data where issue_date is in last 180
    sorDB_existing_cust_check = spark.sql(f"""select * from {sorDb_temp_view} where day > 180 """).cache()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# try:
#     # create delta table 
#     sorDB_Df.write.format("delta").saveAsTable(f"{database_name}.{table_name}")
# except Exception as e:
#     raise Exception(e)