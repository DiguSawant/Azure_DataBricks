# Databricks notebook source
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../config/config_sherpa

# COMMAND ----------

#read the excel data from given source location
try:
    telesales_system_df = read_csv(location=telesale_source_path)    
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#normalize columns CellPhone
try:
    telesales_partition_df = telesales_system_df.withColumn(telesale_CellPhone,regexp_replace(telesale_CellPhone,"-",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#select the required column using col_standarization method
try:
    sheet_2_standDf = col_standarization(df = telesales_partition_df, columns = telesales_col_stand)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# select columns and append partition_date as partition column
try:
    select_cols_df = sheet_2_standDf.withColumn("partition_date",lit("20230306"))\
                                    .select(*telesales_select_cols, "partition_date")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# grouped results into array with DTCOutToTSR as parent object
try:
    grouped_df = select_cols_df.groupBy("partition_date")\
                            .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","BirthDate","Remark"))\
                            .alias("DTCOutToTSR"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#write the telesales_partition_df as json in given location 
try:
    write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = telesale_source_path_json, mode="append", partitionColumn=["partition_date"])
except Exception as e:
    raise Exception(e)