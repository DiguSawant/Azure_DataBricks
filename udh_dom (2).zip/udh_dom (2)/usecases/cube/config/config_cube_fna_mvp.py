# Databricks notebook source
"""
    Purpose : define parameters used for CUBE dashboard
    Input : database names,table names
    Output : database names,table names
"""

# COMMAND ----------

from pyspark.sql.types import *
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

# assign the variables
database_name = f"{env}_cube_silver"
database_name_mvp = f"{env}_cube_gold"
view_name_source = "vw_cube_fna_mvp_source"
view_name = "vw_cube_fna_mvp"
agent_table = "agent_mvp_silver"
leads_table = "leads_mvp_silver"
products_table = "products_mvp_silver"
lookup_tbl = "lookup_mvp_tbl"

# COMMAND ----------

# define the external path
agent_loc = f"{path_prefix}/silver/cube/mvp/agent/"
leads_loc = f"{path_prefix}/silver/cube/mvp/leads/"
products_loc = f"{path_prefix}/silver/cube/mvp/products/"
lookup_loc =f"{path_prefix}/silver/cube/mvp/lookup/"