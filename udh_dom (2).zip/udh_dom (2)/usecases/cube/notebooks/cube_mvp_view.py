# Databricks notebook source
"""
    Purpose : create views used for CUBE dashboard
    Input : Tables - 1. dev_cube_silver.leads_mvp_silver 2. dev_cube_silver.products_mvp_silver  3. dev_cube_silver.agent_mvp_silver
    Output : views - 1. dev_cube_gold.vw_cube_fna_mvp_source  2.dev_cube_gold.vw_cube_fna_mvp 
"""

# COMMAND ----------

# MAGIC %run ../config/config_cube_fna_mvp

# COMMAND ----------

# insert into "vw_cube_fna_mvp_source" view
spark.sql(
    f"""
CREATE OR REPLACE VIEW {database_name_mvp}.{view_name_source}( CREATED_TIME,SCHEMA, LEVEL, COUNT) as
SELECT CREATED_TIME ,SCHEMA, LEVEL, COUNT FROM
(
SELECT Created_time,"LEADS" as Schema, Level, count(DISTINCT JSONVALUE_ID) as Count
FROM {database_name}.{leads_table}
WHERE Level IS NOT NULL
GROUP BY 1,2,3

UNION

SELECT 
Created_time,"LEADS" as Schema,"NO_OF_LEADS" as Level, count(DISTINCT JSONVALUE_ID) as Count
FROM {database_name}.{leads_table}
GROUP BY 1,2,3

UNION

SELECT 
Created_time,"LEADS" as Schema,"LEADS_SUBMITTED" as Level, count(DISTINCT JSONVALUE_ID) as Count
FROM {database_name}.{leads_table}
WHERE JSONVALUE_LEADSTATUSCODE == 'S'
GROUP BY 1,2,3

UNION

SELECT Created_time,"AGENT" as Schema, Level, count(DISTINCT JSONVALUE_AGENTCODE) as Count
FROM {database_name}.{agent_table}
WHERE Level IS NOT NULL
GROUP BY 1,2,3

UNION

SELECT 
Created_time,"AGENT" as Schema,"TOTAL_AGENTS" as Level, count( DISTINCT JSONVALUE_AGENTCODE) as Count
FROM {database_name}.{agent_table}
GROUP BY 1,2,3
 
UNION

SELECT Created_time,"PRODUCT" as Schema, Level, count(Level) as Count
FROM {database_name}.{products_table}
WHERE Level IS NOT NULL
GROUP BY 1,2,3)"""
)

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/common_functions
# MAGIC

# COMMAND ----------

df = spark.sql(""" select * from dev_cube_gold.vw_cube_fna_mvp_source """)

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC
# MAGIC
# MAGIC *
# MAGIC from dev_cube_gold.vw_cube_fna_mvp_source;

# COMMAND ----------

df = df.withColumn("CREATED_TIME",udf_str_to_date(df.CREATED_TIME))
df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_cube_gold.vw_cube_fna_mvp_source

# COMMAND ----------

#insert into "vw_cube_fna_mvp" view

spark.sql(f""" 
CREATE OR REPLACE VIEW {database_name_mvp}.{view_name}( CREATED_TIME,SCHEMA, LEVEL, COUNT) as
SELECT CREATED_TIME,SCHEMA, LEVEL, COUNT FROM
(
SELECT
    c.CREATED_TIME,
    ltbl.SCHEMA,
    ltbl.LEVEL,
    COALESCE(sum(src.count), 0) AS count
FROM
    (
    SELECT DISTINCT CREATED_TIME
    FROM {database_name_mvp}.vw_cube_fna_mvp_source
    ) c
    CROSS JOIN {database_name}.lookup_mvp_tbl ltbl
    LEFT JOIN {database_name_mvp}.vw_cube_fna_mvp_source src
        ON c.CREATED_TIME = src.CREATED_TIME
        AND ltbl.SCHEMA = src.SCHEMA
        AND ltbl.LEVEL = src.LEVEL
GROUP BY
    c.CREATED_TIME,
    ltbl.SCHEMA,
    ltbl.LEVEL
    )
""")