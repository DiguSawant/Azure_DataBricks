# Databricks notebook source
"""
    Purpose : Derive KPIs used for CUBE dashboard
    Input : Table - 1.dev_silver.iris_lead_cube_fna_silver
    Output :Tables - 1. dev_cube_silver.leads_mvp_silver 2. dev_cube_silver.products_mvp_silver  3. dev_cube_silver.agent_mvp_silver 4.dev_cube_silver.lookup_mvp_tbl
"""

# COMMAND ----------

# MAGIC %run ../config/config_cube_fna_mvp

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../../../tech_utility/aes

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *


# COMMAND ----------

#extracts latest UDH_INSERT_TIMESTAMP
try:
    df_pt_udh_insert_timestamp = spark.sql(f""" select max(UDH_INSERT_TIMESTAMP) from {env}_silver.iris_lead_cube_fna_silver """)
    pt_udh_insert_timestamp = df_pt_udh_insert_timestamp.collect()[0][0]
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt the age field of dataframe
try:
    df_read = spark.sql(f""" select * from {env}_silver.iris_lead_cube_fna_silver  """)
    decryptDf_lead = df_read
    encrypted_column = ["JSONVALUE_AGE"] 
    for field in  encrypted_column :   
        decryptDf_lead = decryptDf_lead.withColumn(field, when(decryptDf_lead[field].isNull(),lit(None)).otherwise(aes_decrypt(field)))
    decryptDf_lead.createOrReplaceTempView("tbl")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#insert into agent table
spark.sql(f"""
INSERT INTO {database_name}.{agent_table} 
SELECT distinct date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')as CREATED_TIME,
JSONVALUE_AGENTCODE,
CASE 
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND (EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 7 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 12  )    THEN "AGENT_MORNING"
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND  (EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 11 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 19  )  THEN "AGENT_AFTERNOON"
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND 
(EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 19 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 23  ) THEN "AGENT_EVENING"
ELSE "AGENT_NIGHT"
END AS LEVEL,
'LEAD' , 
'{pt_udh_insert_timestamp}' as UDH_INSERT_TIMESTAMP
FROM tbl
""")


# COMMAND ----------

#insert data into leads table
spark.sql(f"""
INSERT INTO {database_name}.{leads_table}
SELECT date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')as CREATED_TIME,
JSONVALUE_ID,
JSONVALUE_LEADSTATUSCODE,
CASE WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND (JSONVALUE_AGE>=0 OR JSONVALUE_AGE< 20) THEN "JUVENILE"
WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND (JSONVALUE_AGE>=20) THEN "ADULT" ELSE NULL END AS LEVEL,
'LEAD' , 
'{pt_udh_insert_timestamp}' as UDH_INSERT_TIMESTAMP
FROM tbl
WHERE JSONVALUE_STATUS = 'A'
AND JSONVALUE_ID IS NOT NULL
""")

# COMMAND ----------

#insert data into products tables
spark.sql(f"""
INSERT INTO {database_name}.{products_table}
SELECT date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')as CREATED_TIME,
JSONVALUE_LEADSTATUSCODE,
JSONVALUE_PRODUCTINTERESTEDTYPECODE,
CASE WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND  UPPER(JSONVALUE_PRODUCTINTERESTEDTYPECODE) == 'PA'  THEN "PERSONAL ACCIDENT"
WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND  UPPER(JSONVALUE_PRODUCTINTERESTEDTYPECODE) == 'L'  THEN "LIFE"
WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND  UPPER(JSONVALUE_PRODUCTINTERESTEDTYPECODE) == 'H' THEN "HEALTH"
WHEN JSONVALUE_LEADSTATUSCODE == 'S' AND  UPPER(JSONVALUE_PRODUCTINTERESTEDTYPECODE) == 'W'  THEN "WEALTH"
ELSE NULL END AS LEVEL,
'LEAD' , 
'{pt_udh_insert_timestamp}' as UDH_INSERT_TIMESTAMP
FROM tbl
""")

# COMMAND ----------

#create a lookup table
df_lookup = spark.sql("""
select "AGENT" as SCHEMA,"AGENT_MORNING" as LEVEL
union
select "AGENT" as SCHEMA,"AGENT_AFTERNOON" as LEVEL
union
select "AGENT" as SCHEMA,"AGENT_EVENING" as LEVEL
union
select "AGENT" as SCHEMA,"AGENT_NIGHT" as LEVEL
union
select "AGENT" as SCHEMA,"TOTAL_AGENTS" as LEVEL
union
select "LEADS" as SCHEMA,"JUVENILE" as LEVEL
union
select "LEADS" as SCHEMA,"ADULT" as LEVEL
union
select "LEADS" as SCHEMA,"NO_OF_LEADS" as LEVEL
union
select "LEADS" as SCHEMA,"LEADS_SUBMITTED" as LEVEL
union
select "PRODUCT" as SCHEMA,"PERSONAL ACCIDENT" as LEVEL
union
select "PRODUCT" as SCHEMA,"LIFE" as LEVEL
union
select "PRODUCT" as SCHEMA,"HEALTH" as LEVEL
union
select "PRODUCT" as SCHEMA,"WEALTH" as LEVEL

""")
df_lookup.createOrReplaceTempView("lookup_tbl")

# COMMAND ----------

#save lookup data
table = database_name + "." + lookup_tbl
df_lookup.write.format("delta").mode("overwrite").option("path",lookup_loc).saveAsTable(table)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_cube_silver.lookup_mvp_tbl