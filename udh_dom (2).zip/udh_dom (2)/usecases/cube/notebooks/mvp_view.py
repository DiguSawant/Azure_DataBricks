# Databricks notebook source
# MAGIC %sql
# MAGIC select distinct  JSONVALUE_AGENTCODE, date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')as CREATED_TIME from   dev_silver.lead_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC drop database dev_mvp_silver

# COMMAND ----------

# MAGIC %sql
# MAGIC select count( distinct JSONVALUE_AGENTCODE) from dev_silver.lead_silver
# MAGIC                 where  JSONVALUE_AGENTCODE is not null

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select count( distinct JSONVALUE_AGENTCODE) from dev_cube_silver.agent_mvp_silver
# MAGIC                                         where  created_time is not null and JSONVALUE_AGENTCODE is not null

# COMMAND ----------

# MAGIC %run ../config/config_cube_fna_mvp

# COMMAND ----------

spark.sql(
    f"""
create or replace view {env}_mvp_gold.{view_name_source}( CREATED_TIME,SCHEMA, LEVEL, COUNT) as
select CREATED_TIME,SCHEMA, LEVEL, COUNT from
(
select Created_time,"LEADS" as Schema, Level, count(Level) as Count
from {database_name}.{leads_table}
where Level is not null
group by 1,2,3

union

select 
Created_time,"LEADS" as Schema,"NO_OF_LEADS" as Level, count(*) as Count
from {database_name}.{leads_table}
group by 1,2,3

union

select 
Created_time,"LEADS" as Schema,"LEADS_SUBMITTED" as Level, count(Level) as Count
from {database_name}.{leads_table}
where JSONVALUE_LEADSTATUSCODE == 'S'
group by 1,2,3

union

select Created_time,"AGENT" as Schema, Level, count(Level) as Count
from {database_name}.{agent_table}
where Level is not null
group by 1,2,3

union

select 
Created_time,"AGENT" as Schema,"TOTAL_AGENTS" as Level, count(Level) as Count
from {database_name}.{agent_table}
where Level is not null
group by 1,2,3
 
union

select Created_time,"PRODUCT" as Schema, Level, count(Level) as Count
from {database_name}.{products_table}
group by 1,2,3)"""
)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from
# MAGIC dev_mvp_gold.vw_cube_fna_mvp_source

# COMMAND ----------

schema = ['product','agent','leads']
level =

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_mvp_silver.lookup_tbl

# COMMAND ----------

# MAGIC
# MAGIC %sql 
# MAGIC SELECT c.created_time, lt.schema, lt.level, COALESCE(COUNT(yt.level), 0) AS countb  FROM ( SELECT DISTINCT created_time,level FROM dev_mvp_gold.vw_cube_fna_mvp_source ) c CROSS JOIN dev_mvp_silver.lookup_tbl lt LEFT JOIN dev_mvp_gold.vw_cube_fna_mvp_source yt ON c.created_time = yt.created_time AND lt.schema = yt.schema AND lt.level = yt.level  
# MAGIC where c.created_time = '07/03/2023'
# MAGIC GROUP BY c.created_time, lt.schema, lt.level;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_silver.lead_silver limit 5

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_mvp_silver.leads_silver 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct JSONVALUE_CREATEDTIME ,count(*) from dev_silver.lead_silver where JSONVALUE_CREATEDTIME like '2023-03-07%' 
# MAGIC group by 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT t1.created_time,t1.schema,COUNT(t3.level) TotalRecords
# MAGIC FROM (
# MAGIC     SELECT created_time,schema,level
# MAGIC     FROM (
# MAGIC       SELECT DISTINCT level
# MAGIC       FROM dev_mvp_silver.agent_silver
# MAGIC     ) t1 CROSS JOIN
# MAGIC     (
# MAGIC       SELECT DISTINCT level FROM dev_mvp_silver.lookup_tbl
# MAGIC     )  t2
# MAGIC ) t1
# MAGIC LEFT JOIN TCAP t3 ON t3.GND = t1.GND and t3.schema = t1.schema
# MAGIC group by  t1.GND,t1.schema;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT t.created_time,p.schema,t.level,COALESCE(COUNT(p.level), 0) AS count 
# MAGIC FROM(SELECT DISTINCT created_time, level FROM dev_mvp_silver.agent_silver) t
# MAGIC RIGHT JOIN dev_mvp_silver.lookup_tbl p 
# MAGIC ON  t.level = p.level
# MAGIC GROUP BY t.created_time,p.schema,t.level;

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from dev_mvp_gold.vw_cube_fna_mvp_source

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT all_combinations.created_time, all_combinations.level, all_combinations.schema, COALESCE(COUNT(yt.created_time), 0) AS count FROM ( SELECT DISTINCT t1.created_time, t2.level, t3.schema FROM dev_mvp_gold.vw_cube_fna_mvp_source t1 CROSS JOIN dev_mvp_gold.vw_cube_fna_mvp_source t2 CROSS JOIN dev_mvp_gold.vw_cube_fna_mvp_source t3 ) all_combinations LEFT JOIN dev_mvp_gold.vw_cube_fna_mvp_source yt ON all_combinations.created_time = yt.created_time AND all_combinations.level = yt.level AND all_combinations.schema = yt.schema 
# MAGIC where
# MAGIC all_combinations.CREATED_TIME = '02/03/2023' and(
# MAGIC  !(all_combinations.level = 'AGENT_MORNING' and all_combinations.schema = 'LEADS')
# MAGIC and !(all_combinations.level = 'AGENT_MORNING' and all_combinations.schema = 'PRODUCT')
# MAGIC and !(all_combinations.level = 'AGENT_NIGHT' and all_combinations.schema = 'LEADS')
# MAGIC and !(all_combinations.level = 'AGENT_NIGHT' and all_combinations.schema = 'PRODUCT')
# MAGIC and !(all_combinations.level = 'AGENT_AFTERNOON' and all_combinations.schema = 'LEADS')
# MAGIC and !(all_combinations.level = 'AGENT_AFTERNOON' and all_combinations.schema = 'PRODUCT')
# MAGIC and !(all_combinations.level = 'TOTAL_AGENTS' and all_combinations.schema = 'LEADS')
# MAGIC and !(all_combinations.level = 'TOTAL_AGENTS' and all_combinations.schema = 'PRODUCT'))
# MAGIC GROUP BY all_combinations.created_time, all_combinations.level, all_combinations.schema
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     c.CREATED_TIME,
# MAGIC     lt.SCHEMA,
# MAGIC     lt.LEVEL,
# MAGIC     COALESCE(sum(yt.count), 0) AS count
# MAGIC FROM
# MAGIC     (
# MAGIC     SELECT DISTINCT CREATED_TIME
# MAGIC     FROM dev_mvp_gold.vw_cube_fna_mvp_source
# MAGIC     ) c
# MAGIC     CROSS JOIN dev_mvp_silver.lookup_tbl lt
# MAGIC     LEFT JOIN dev_mvp_gold.vw_cube_fna_mvp_source yt
# MAGIC         ON c.CREATED_TIME = yt.CREATED_TIME
# MAGIC         AND lt.SCHEMA = yt.SCHEMA
# MAGIC         AND lt.LEVEL = yt.LEVEL
# MAGIC
# MAGIC where c.CREATED_TIME ="02/03/2023"
# MAGIC GROUP BY
# MAGIC     c.CREATED_TIME,
# MAGIC     lt.SCHEMA,
# MAGIC     lt.LEVEL;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql select * FROM dev_mvp_gold.vw_cube_fna_mvp_source where CREATED_TIME ="02/03/2023"