# Databricks notebook source
#import smbclient
import smb
import csv
import os
from smb.SMBConnection import SMBConnection
from smb import smb_structs

# COMMAND ----------

#Conn SMB Parameter
remote_name = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-fsx-ip")
username = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-fsx-user")
password = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-fsx-pwd")
my_name = ""
domain = "th.intranet"

#Make SMB Connection
conn = SMBConnection(username, password, my_name, remote_name, domain, is_direct_tcp=True, use_ntlm_v2=True, sign_options=2)
conn.connect(remote_name, 445)

#List File in directory
items = conn.listPath('share', "/UDH_file_share/outbound/ifwd_leads")
for item in items:
    print(item.filename)

# COMMAND ----------

import tempfile
temp_path = ""
with tempfile.NamedTemporaryFile(delete=False) as f:
    conn.retrieveFile('share', '/UDH_file_share/outbound/ifwd_leads/temp_file.csv', f)
    temp_path = f.name

with open(temp_path, "r") as f:
    print(f.read())

# COMMAND ----------

people = [
  (10, "blue"),
  (13, "red"),
  (15, "blue"),
  (99, "red"),
  (67, "blue")
]
peopleDf = spark.createDataFrame(people,["age","fave_colour"])
peopleDf.show()

import os
peopleDf.coalesce(1).write.csv("temp_file_csv",header=True,sep=",",mode="overwrite")

remote_path = "/UDH_file_share/outbound/ifwd_leads/temp_file.csv"

for file_name in os.listdir("/dbfs/temp_file_csv/") :
    if file_name.startswith("part") :
        with open("/dbfs/temp_file_csv/" + file_name, "r") as f:
            f.read()
            conn.storeFile(share_name, remote_path, f)

# COMMAND ----------

dbutils.fs.ls("/")

# COMMAND ----------

#Data that need to be write into File in this case is CSV Data
csv_data = "col1,col2,col3\n1,2,3\n4,5,6\n"

# Open the file for writing
with open("data.csv", "w") as file:
    # Write the data to the file
    file.write(csv_data)



# COMMAND ----------

#ConnStore parameter for specify the file name and sorce/destination path
local_path = os.path.join(os.getcwd(), "data.csv")
remote_path = "/UDH_file_share/outbound/ifwd_leads/data.csv"
share_name = "share"

#Write down the file into destination FSx
with open(local_path, "rb") as file:
    # Transfer the file to the remote SMB share
    conn.storeFile(share_name, remote_path, file)