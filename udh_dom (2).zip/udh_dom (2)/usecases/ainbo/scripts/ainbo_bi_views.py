# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ../config/config_ainbo

# COMMAND ----------

# create ainbo conversion view
spark.sql(f"""
    create or replace view {env}_ainbo_gold.{view_name}
    (TRANS_DATE,PRODUCT_ID,FUNNEL_STAGE,COUNT,PRODUCT_NAME,UTM_CONTENT,APE,VNB,SOURCE_SYSTEM) as
    select trans_date,product_id,funnel_stage,count, product_name, utm_content,ape,vnb,source_system from(
        select to_date(udh_insert_timestamp) trans_date, product_type as product_id, "QUOTE" as funnel_stage, sum(count) as count, product_name, utm_content,0 as ape,0 as vnb,source_system from {database_name}.{quote_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb
        union
        select to_date(udh_insert_timestamp) trans_date, product_type as product_id, "HEALTH_QUESTION" as funnel_stage, sum(count) as count, product_name, utm_content,0 as ape,0 as vnb,source_system from {database_name}.{health_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb
        union
        select to_date(udh_insert_timestamp) trans_date,product_type as product_id,"PERSONAL_INFO" as funnel_stage, sum(count) as count, product_name, utm_content,0 as ape,0 as vnb,source_system from {database_name}.{personal_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb
        union
        select to_date(udh_insert_timestamp) trans_date,product_type as product_id,"SUMMARY" as funnel_stage, sum(count) as count, product_name, utm_content,0 as ape,0 as vnb,source_system from {database_name}.{summary_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb
        union
        select to_date(udh_insert_timestamp) trans_date,product_type as product_id,"PAYMENT" as funnel_stage, sum(count) as count, product_name, utm_content,0 as ape,0 as vnb,source_system from {database_name}.{payment_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb
        union
        select to_date(udh_insert_timestamp) trans_date,product_type as product_id,"SUCCESS" as funnel_stage, sum(count) as count, product_name, utm_content,ape,vnb,source_system from {database_name}.{success_table} group by to_date(udh_insert_timestamp),product_type, product_name, utm_content,source_system,ape,vnb)
""")