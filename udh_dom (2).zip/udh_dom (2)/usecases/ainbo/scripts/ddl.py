# Databricks notebook source
# MAGIC %run ../config/config_ainbo

# COMMAND ----------

# create statement for quote table
spark.sql(f"""
create  or replace table {database_name}.{quote_table}
(
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string
)
USING DELTA
partitioned By (source_system)
location '{quote_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# create statement for health table
spark.sql(f"""
create or replace table {database_name}.{health_table}
(
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string
)
USING DELTA
partitioned By (source_system)
location '{health_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# create statement for personal table
spark.sql(f"""
create or replace table {database_name}.{personal_table}
(
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string
)
USING DELTA
partitioned By (source_system)
location '{personal_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# create statement for summary table
spark.sql(f"""
create or replace table {database_name}.{summary_table}
(
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string
)
USING DELTA
partitioned By (source_system)
location '{summary_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# create statement for payment table
spark.sql(f"""
create or replace table {database_name}.{payment_table}
(
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string
)
USING DELTA
partitioned By (source_system)
location '{payment_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------



# COMMAND ----------

# create statement for success table
spark.sql(f"""
create or replace table {database_name}.{success_table}
(
POLICY_NO string,
PRODUCT_TYPE string,
PRODUCT_NAME string,
UTM_CONTENT string,
COUNT int,
UDH_INSERT_TIMESTAMP timestamp,
SOURCE_SYSTEM string,
APE DECIMAL(10,0),
VNB DECIMAL(20,2),
ACTUAL_VNB DECIMAL(20,2)
)
USING DELTA
partitioned By (source_system)
location '{success_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# create statement for lookup table
spark.sql(f""" 
create or replace table {database_name}.{lookup_table}
(
PRODUCT_ID string,
PRODUCT_NAME string,
SOURCE_SYSTEM string
)
USING DELTA
location '{lookup_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
    """)

# COMMAND ----------

# spark.sql(
# f"""
# insert into {database_name}.{lookup_table}
# values
# ('E60A1','EASY E-SAVE 10/5','NON_NBM'),
# ('CI','FWD EASY E-CANCER','NBM'),
# ('HA','EASY E-HEART','NBM'),
# ('SI','EASY E-STROKE','NBM'),
# ('3CI','BIG 3','NBM'),
# ('T08A','E-CANCER','NBM'),
# ("T12A","EASY E-HEALTH","NON_NBM")

# """)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_ainbo_gold.vw_campaign_ainbo_conversion

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_ainbo_gold.vw_campaign_ainbo_demographics