# Databricks notebook source
# MAGIC %run ../config/config_ainbo

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# DBTITLE 1,quote
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{quote_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# DBTITLE 1,quote table
# insert data into quote table
spark.sql(f"""
insert into {database_name}.{quote_table}
select  
      datavalue_productId,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,''),
      count(*),
      max(udh_insert_timestamp),
      'NON_NBM' 
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'NON_NBM'
where 
      ET_APPLICATION = 'ECOMMERCE'
      and ET_ENTITYNAME = 'SAVESTAGE' 
      and DATAVALUE_HEALTH_HASOTHERINSURANCE IS NULL 
      and DATAVALUE_ISOTPVERIFY IS NULL 
      and DATAVALUE_PREMIUMINFO_BIRTHDATE IS NOT NULL 
      and DATAVALUE_PRODUCTID in ('E60A1','T12A')
group by 
      datavalue_productId,l.product_name,datavalue_utmTracking_utmContent;
""")

# COMMAND ----------

# DBTITLE 1,health_question
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{health_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# insert data into health table
spark.sql(f"""
insert into {database_name}.{health_table}
select  
      datavalue_productId,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,''),
      count(*),
      max(udh_insert_timestamp),
      'NON_NBM' 
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'NON_NBM'
where 
      et_application = 'ECOMMERCE'
      and et_entityname = 'SAVESTAGE' 
      and datavalue_health_hasOtherInsurance IS NOT NULL
      and datavalue_isFatcaPass='FALSE'
      and datavalue_productId in ('E60A1','T12A')
group by 
      datavalue_productId,l.product_name,datavalue_utmTracking_utmContent;
""")

# COMMAND ----------

# DBTITLE 1,personal_info
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{personal_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# DBTITLE 1,personal_info
# insert data into personal table
spark.sql(f"""
insert into {database_name}.{personal_table}
select  
      datavalue_productId,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,''),
      count(*),
      max(udh_insert_timestamp),
      'NON_NBM' 
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'NON_NBM'
where 
      et_application = 'ECOMMERCE'
      and et_entityname = 'SAVESTAGE' 
      and datavalue_health_hasOtherInsurance IS NULL 
      and datavalue_isOtpVerify='FALSE' 
      and datavalue_policyHolder_mobileNumber IS NOT NULL 
      and datavalue_productId in ('E60A1','T12A')
group by 
      datavalue_productId,l.product_name,datavalue_utmTracking_utmContent;
""")

# COMMAND ----------

# DBTITLE 1,summary
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{summary_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# DBTITLE 1,summary
# insert data into summary table
spark.sql(f"""
insert into {database_name}.{summary_table}
select  
      datavalue_productId,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,''),
      count(*),
      max(udh_insert_timestamp),
      'NON_NBM' 
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'NON_NBM'
where 
      et_application = 'ECOMMERCE'
      and et_entityname = 'SAVESTAGE' 
      and datavalue_policyNumber IS NOT NULL
      and datavalue_paymentType IS NULL
      and datavalue_productId in ('E60A1','T12A')
group by 
      datavalue_productId,l.product_name,datavalue_utmTracking_utmContent;
""")

# COMMAND ----------

# DBTITLE 1,payment
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{payment_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# DBTITLE 1,payment table
# insert data into payment table
spark.sql(f"""
insert into {database_name}.{payment_table}
select  
      datavalue_productId,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,''),
      count(*),
      max(udh_insert_timestamp),
      'NON_NBM' 
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'NON_NBM' 
where 
      et_application = 'ECOMMERCE'
      and et_entityname = 'SAVESTAGE' 
      and datavalue_policyNumber IS NOT NULL
      and datavalue_paymentType IS NOT NULL
      and datavalue_isPaymentComplete IS NULL
      and datavalue_productId in ('E60A1','T12A')
group by 
      datavalue_productId,l.product_name,datavalue_utmTracking_utmContent;
""")

# COMMAND ----------

# DBTITLE 1,success
max_time=spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{success_table} where source_system = 'NON_NBM'").collect()[0][0]

if max_time!='' and max_time!=None:
    where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
else:
    where_cond = f"udh_insert_timestamp<'{curr_time}'"

# COMMAND ----------

# DBTITLE 1,success table
# # insert data into success table
# spark.sql(f"""
# insert into {database_name}.{success_table}
# select t2.datavalue_productId,
# t2.product_name,
# t2.datavalue_utmTracking_utmContent,
# t2.count,
# t2.udh_insert_timestamp,
# t2.source_system,
# t2.ape,
# ((t1.VNB_PERCENT/100)*t2.ape) as VNB 
# from {env}_vnb.vnb_rates_silver t1
# join(
#     select  
#       datavalue_productId,
#       l.product_name,
#       nvl(datavalue_utmTracking_utmContent,'') as datavalue_utmTracking_utmContent,
#       count(*) as count,
#       max(udh_insert_timestamp) as udh_insert_timestamp,
#       'non_nbm' as source_system,
#       sum(
#             CASE 
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='MONTHLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*12
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='QUARTERLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*4
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='HALFYEARLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*2
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='YEARLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*1
                 
#                 ELSE DATAVALUE_PREMIUMINFO_PREMIUM*1
#             END 
#   ) as ape
# from 
#       {non_nbm_src_tbl} as s
# join  {database_name}.{lookup_table} as l


# on
#     lower(l.product_id) = lower(s.datavalue_productId)
#   and lower(l.source_system) = 'non_nbm'
# where 
#       et_application = 'ECOMMERCE'
#       and et_entityname = 'SAVESTAGE' 
#       and datavalue_isPaymentComplete = 'TRUE'
#       and datavalue_productId in ('E60A1','T12A')
# group by 
#       datavalue_productId,l.product_name,datavalue_utmTracking_utmContent) as t2 on t1.Product_ID=t2.datavalue_productId and t1.Digital_Channel='DTC'
# """)

# COMMAND ----------

# # insert data into success table
# spark.sql(f"""
# insert into {database_name}.{success_table}
# select datavalue_productId,t3.Product_Name,t4.datavalue_utmTracking_utmContent,t4.count,t4.ape ,((t3.VNB_PERCENT/100)*t4.ape) as vnb,t3.udh_insert_timestamp,t4.source_system from {env}_silver.vnb_rates_silver as t3
# join(
#     select * from {env}_silver.vnb_channel_silver as t1
# join (
#     select  
#       datavalue_productId,
#       DATAVALUE_PARTNER,
#       l.product_name,
#       nvl(datavalue_utmTracking_utmContent,'') as datavalue_utmTracking_utmContent,
#       count(*) as count,
#       max(udh_insert_timestamp) as udh_insert_timestamp,
#       'NON_NBM' as source_system,
#       sum(
#             CASE 
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='MONTHLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*12
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='QUARTERLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*4
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='HALFYEARLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*2
#                 WHEN 
#                     DATAVALUE_PREMIUMINFO_PAYMENTMODE=='YEARLY'
#                 THEN 
#                     DATAVALUE_PREMIUMINFO_PREMIUM*1
                 
#                 ELSE DATAVALUE_PREMIUMINFO_PREMIUM*1
#             END 
#   ) as ape
# from 
#       {non_nbm_src_tbl} as s
# join  {database_name}.{lookup_table} as l


# on
#     lower(l.product_id) = lower(s.datavalue_productId)
#   and lower(l.source_system) = 'NON_NBM'
# where 
#       et_application = 'ECOMMERCE'
#       and et_entityname = 'SAVESTAGE' 
#       and datavalue_isPaymentComplete = 'TRUE'
#       and datavalue_productId in ('E60A1','T12A')
# group by 
#       datavalue_productId,l.product_name,datavalue_utmTracking_utmContent,DATAVALUE_PARTNER
# ) as t2 on t1.Partner_Name=t2.DATAVALUE_PARTNER
# ) as t4 on t3.Digital_Channel=t4.Digital_Channel and t3.Product_ID in ('E60A1','T12A') and t3.Digital_Channel="DTC"
# """)

# COMMAND ----------

# DBTITLE 1,Success Table
# insert data into success table
spark.sql(f"""
insert into {database_name}.{success_table}
select POLICYNO,datavalue_productId,t3.Product_Name,t4.datavalue_utmTracking_utmContent,t4.count,t3.udh_insert_timestamp,t4.
source_system,t4.ape ,((t3.VNB_PERCENT/100)*t4.ape) as vnb,ACTUAL_VNB from {env}_silver.vnb_rates_silver as t3
join(
    select * from {env}_silver.vnb_channel_silver as t1
join (
    select avt.POLICY_NUMBER as POLICYNO,
      datavalue_productId,
      DATAVALUE_PARTNER,
      l.product_name,
      nvl(datavalue_utmTracking_utmContent,'') as datavalue_utmTracking_utmContent,
      count(*) as count,
      max(udh_insert_timestamp) as udh_insert_timestamp,
      'non_nbm' as source_system,
      sum(
            CASE 
                WHEN 
                    DATAVALUE_PREMIUMINFO_PAYMENTMODE=='MONTHLY'
                THEN 
                    DATAVALUE_PREMIUMINFO_PREMIUM*12
                WHEN 
                    DATAVALUE_PREMIUMINFO_PAYMENTMODE=='QUARTERLY'
                THEN 
                    DATAVALUE_PREMIUMINFO_PREMIUM*4
                WHEN 
                    DATAVALUE_PREMIUMINFO_PAYMENTMODE=='HALFYEARLY'
                THEN 
                    DATAVALUE_PREMIUMINFO_PREMIUM*2
                WHEN 
                    DATAVALUE_PREMIUMINFO_PAYMENTMODE=='YEARLY'
                THEN 
                    DATAVALUE_PREMIUMINFO_PREMIUM*1
                 
                ELSE DATAVALUE_PREMIUMINFO_PREMIUM*1
            END 
  ) as ape,COALESCE(avt.VNB_AF_REIN_DIVER , 0) AS ACTUAL_VNB
from 
      {non_nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l


on
    lower(l.product_id) = lower(s.datavalue_productId)
  and lower(l.source_system) = 'non_nbm'
  left join (select POLICY_NUMBER ,sum(VNB_AF_REIN_DIVER) as VNB_AF_REIN_DIVER from {env}_silver.actual_vnb_silver group by POLICY_NUMBER) as avt on s.DATAVALUE_POLICYNUMBER=avt.POLICY_NUMBER
where 

      et_application = 'ECOMMERCE'
      and et_entityname = 'SAVESTAGE' 
      and datavalue_isPaymentComplete = 'TRUE'
      and datavalue_productId in ('E60A1','T12A')
group by 
    ACTUAL_VNB, POLICYNO,datavalue_productId,l.product_name,datavalue_utmTracking_utmContent,DATAVALUE_PARTNER,DATAVALUE_POLICYNUMBER
) as t2 on t1.Partner_Name=t2.DATAVALUE_PARTNER
) as t4 on t3.Digital_Channel=t4.Digital_Channel and t3.Product_ID in ('E60A1','T12A') and t3.Digital_Channel="DTC"
""")