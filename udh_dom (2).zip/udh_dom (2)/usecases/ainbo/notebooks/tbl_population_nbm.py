# Databricks notebook source
# DBTITLE 1,running config notebook
# MAGIC %run ../config/config_ainbo

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# DBTITLE 1,quote Table
# calculate max timestamp
where_cond = max_condition(database_name, quote_table, nbm_src_system, curr_time)

# insert data into quote table
spark.sql(f"""
insert into {database_name}.{quote_table}
select 
    after_product_type,
    l.product_name,
    nvl(json_data_others_utmcontent,''),
    count(*),
    max(udh_insert_timestamp),
    'NBM' 
from 
      {nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.after_product_type)
  and lower(l.source_system) = 'NBM'
where 
    upper(after_user_view) = upper('quote.quickQuestions')
    and upper(after_status) = upper('proposal')
    and {where_cond} 
group by 
    after_product_type,l.product_name,json_data_others_utmcontent;
""")

# COMMAND ----------

# DBTITLE 1,health table
# calculate max timestamp
where_cond = max_condition(database_name, health_table, nbm_src_system, curr_time)

# insert data into health table
spark.sql(f"""
insert into {database_name}.{health_table}
select 
    after_product_type,
    l.product_name,
    nvl(json_data_others_utmcontent,''),
    count(*),
    max(udh_insert_timestamp),
    'NBM' 
from 
      {nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.after_product_type)
  and lower(l.source_system) = 'NBM'
where 
    upper(after_user_view) = upper('quote.underwritingAnswer')
    and upper(after_status) = upper('proposal') 
    and {where_cond} 
group by 
    after_product_type,l.product_name,json_data_others_utmcontent;
""")

# COMMAND ----------

# DBTITLE 1,personal table

# calculate max timestamp
where_cond = max_condition(database_name, personal_table, nbm_src_system, curr_time)

# insert data into personal table
spark.sql(f"""
insert into {database_name}.{personal_table}
select 
     after_product_type,
     l.product_name,
     nvl(json_data_others_utmcontent,''),
     count(*),
     max(udh_insert_timestamp),
     'NBM' 
from 
      {nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.after_product_type)
  and lower(l.source_system) = 'NBM' 
where 
     upper(after_user_view) = upper('quote.personalDetail') 
     and upper(after_status) = upper('proposal')
     and {where_cond} 
group by 
     after_product_type,l.product_name,json_data_others_utmcontent;
""")

# COMMAND ----------

# DBTITLE 1,summary table
# calculate max timestamp
where_cond = max_condition(database_name, summary_table, nbm_src_system, curr_time)

# insert data into summary table
spark.sql(f"""
insert into {database_name}.{summary_table}
select 
      after_product_type,
      l.product_name,
      nvl(json_data_others_utmcontent,''),
      count(*),
      max(udh_insert_timestamp),
      'NBM' 
from 
      {nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.after_product_type)
  and lower(l.source_system) = 'NBM'
where 
      upper(after_user_view) = upper('quote.proceedToPay') 
      and upper(after_status) = upper('proposal') 
      and {where_cond} 
group by 
      after_product_type,l.product_name,json_data_others_utmcontent;
""")

# COMMAND ----------

# DBTITLE 1,payment table
# calculate max timestamp
where_cond = max_condition(database_name, payment_table, nbm_src_system, curr_time)

# insert data into payment table
spark.sql(f"""
insert into {database_name}.{payment_table}
select
      after_product_type,
      l.product_name,
      nvl(json_data_others_utmcontent,''),
      count(*),
      max(udh_insert_timestamp),
      'NBM'
from 
      {nbm_src_tbl} as s
join  {database_name}.{lookup_table} as l
on
      lower(l.product_id) = lower(s.after_product_type)
  and lower(l.source_system) = 'NBM'
where
      upper(after_user_view) = upper('quote.payment')
      and upper(after_status) = upper('pending')
      and {where_cond}
group by
      after_product_type,l.product_name,json_data_others_utmcontent;
""")

# COMMAND ----------

# DBTITLE 1,success table
# # calculate max timestamp
# where_cond = max_condition(database_name, success_table, nbm_src_system, curr_time)

# # insert data into success table
# spark.sql(f"""
# insert into {database_name}.{success_table}
# select t2.after_product_type,t2.product_name,t2.datavalue_utmTracking_utmContent,t2.count,t2.udh_insert_timestamp,t2.source_system, t2.ape,((t1.VNB_PERCENT/100)*t2.ape) as VNB from {env}_vnb.vnb_rates_silver t1
# join(select 
#       after_product_type,
#       l.product_name,
#       nvl(json_data_others_utmcontent,'') as datavalue_utmTracking_utmContent,
#       count(*) as count,
#       max(udh_insert_timestamp) as udh_insert_timestamp,
#       'nbm' as source_system,
#       sum(CASE 
#             WHEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) *1
#             WHEN 
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)*12
#             else 0
#     END) as ape
# from 
#       {nbm_src_tbl} as s
# join  {database_name}.{lookup_table} as l
# on
#       lower(l.product_id) = lower(s.after_product_type)
#   and lower(l.source_system) = 'nbm'
# where 
#       upper(after_user_view) = upper('quote.payment')  
#       and upper(after_status) = upper('payment')  
#       and {where_cond} 
# group by 
#       after_product_type,l.product_name,json_data_others_utmcontent) as t2 on t1.Product_ID=t2.after_product_type and t1.Digital_Channel='DTC'
# """)

# COMMAND ----------

# # calculate max timestamp
# where_cond = max_condition(database_name, success_table, nbm_src_system, curr_time)

# # insert data into success table
# spark.sql(f"""
# insert into {database_name}.{success_table}
# select t2.after_product_type,t2.product_name,t2.datavalue_utmTracking_utmContent,t2.count,t2.udh_insert_timestamp,t2.source_system, t2.ape,((t1.VNB_PERCENT/100)*t2.ape) as VNB from {env}_silver.vnb_rates_silver t1
# join(select 
#       after_product_type,
#       l.product_name,
#       nvl(json_data_others_utmcontent,'') as datavalue_utmTracking_utmContent,
#       count(*) as count,
#       max(udh_insert_timestamp) as udh_insert_timestamp,
#       'nbm' as source_system,
#       sum(CASE 
#             WHEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) *1
#             WHEN 
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)*12
#             else 0
#     END) as ape
# from 
#       {nbm_src_tbl} as s
# join  {database_name}.{lookup_table} as l
# on
#       lower(l.product_id) = lower(s.after_product_type)
#   and lower(l.source_system) = 'nbm'
# where 
#       upper(after_user_view) = upper('quote.payment')  
#       and upper(after_status) = upper('payment')  
#       and {where_cond} 
# group by 
#       after_product_type,l.product_name,json_data_others_utmcontent) as t2 on t1.Product_ID=t2.after_product_type and t1.Digital_Channel='DTC'
# """)

# COMMAND ----------

# DBTITLE 1,Success Table
# # calculate max timestamp
# where_cond = max_condition(database_name, success_table, nbm_src_system, curr_time)

# # insert data into success table
# spark.sql(f"""
# insert into {database_name}.{success_table}
# select
# after_product_type,product_name,datavalue_utmTracking_utmContent,count,ape,vnb,udh_insert_timestamp_1 as udh_insert_timestamp,source_system
# from
# 	(
# 	select
# 		*,
# 		((t3.VNB_PERCENT / 100)* t4.ape) as vnb
# 	from
# 		{env}_silver.vnb_rates_silver as t3
# 	join(
# 		select
# 			*
# 		from
# 			{env}_silver.vnb_channel_silver as t1
# 		join(
# 			select
# 				after_product_type,
# 				l.product_name as product_name_1,
# 				nvl(json_data_others_utmcontent,
# 				'') as datavalue_utmTracking_utmContent,
# 				count(*) as count,
# 				max(udh_insert_timestamp) as udh_insert_timestamp_1,
# 				'NBM' as source_system,
# 				"ECOM" as JSON_DATA_OTHERS_PARTNERCODE,
# 				sum(CASE 
#             WHEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) * 1
#             WHEN 
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)* 12
#             else 0
#     END) as ape
# 			from
# 				{env}_silver.users_data_silver as s
# 			join {env}_ainbo_silver.product_lookup_silver as l
# on
# 				lower(l.product_id) = lower(s.after_product_type)
# 				and lower(l.source_system) = 'NBM'
# 			where
# 				upper(after_user_view) = upper('quote.payment')
# 				and upper(after_status) = upper('payment')
# 				and JSON_DATA_OTHERS_PARTNERCODE not in (
# 				select
# 					Partner_Name
# 				from
# 					{env}_silver.vnb_channel_silver)
# 			group by
# 				after_product_type,
# 				l.product_name,
# 				json_data_others_utmcontent,
# 				JSON_DATA_OTHERS_PARTNERCODE
# ) as t2 on
# 			t1.Partner_Name = t2.JSON_DATA_OTHERS_PARTNERCODE
# ) as t4 on
# 		t3.Digital_Channel = t4.Digital_Channel
# 		and t3.Product_ID = t4.after_product_type
# union
# 	select
# 		*,
# 		((t3.VNB_PERCENT / 100)* t4.ape) as vnb
# 	from
# 		{env}_silver.vnb_rates_silver as t3
# 	join(
# 		select
# 			*
# 		from
# 			{env}_silver.vnb_channel_silver as t1
# 		join(
# 			select
# 				after_product_type,
# 				l.product_name as product_name_1,
# 				nvl(json_data_others_utmcontent,
# 				'') as datavalue_utmTracking_utmContent,
# 				count(*) as count,
# 				max(UDH_INSERT_TIMESTAMP) as udh_insert_timestamp_1,
# 				'nbm' as source_system,
# 				JSON_DATA_OTHERS_PARTNERCODE,
# 				sum(CASE 
#             WHEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) * 1
#             WHEN 
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
#             THEN
#                 cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)* 12
#             else 0
#     END) as ape
# 			from
# 				{env}_silver.users_data_silver as s
# 			join {env}_ainbo_silver.product_lookup_silver as l
# on
# 				lower(l.product_id) = lower(s.after_product_type)
# 					and lower(l.source_system) = 'NBM'
# 				where
# 					upper(after_user_view) = upper('quote.payment')
# 						and upper(after_status) = upper('payment')
# 							and JSON_DATA_OTHERS_PARTNERCODE in (
# 							select
# 								Partner_Name
# 							from
# 								{env}_silver.vnb_channel_silver)
# 						group by
# 							after_product_type,
# 							l.product_name,
# 							json_data_others_utmcontent,
# 							JSON_DATA_OTHERS_PARTNERCODE
# ) as t2 on
# 			t1.Partner_Name = t2.JSON_DATA_OTHERS_PARTNERCODE
# ) as t4 on
# 		t3.Digital_Channel = t4.Digital_Channel
# 		and t3.Product_ID = t4.after_product_type
# )
# """)

# COMMAND ----------

# DBTITLE 1,Success Table
# calculate max timestamp
where_cond = max_condition(database_name, success_table, nbm_src_system, curr_time)

# insert data into success table
spark.sql(f"""
insert into {database_name}.{success_table}
select
POLICY_NO,after_product_type,product_name,datavalue_utmTracking_utmContent,count,udh_insert_timestamp_1 as udh_insert_timestamp,source_system,ape,vnb,ACTUAL_VNB
from
	(
	select
		*,
		((t3.VNB_PERCENT / 100)* t4.ape) as vnb
	from
		{env}_vnb.vnb_rates_silver as t3
	join(
		select
			*
		from
			{env}_vnb.vnb_channel_silver as t1
		join(
			select s.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO as POLICY_NO,
				after_product_type,
				l.product_name as product_name_1,
				nvl(json_data_others_utmcontent,
				'') as datavalue_utmTracking_utmContent,
				count(*) as count,
				max(udh_insert_timestamp) as udh_insert_timestamp_1,
				'nbm' as source_system,
				"ECOM" as JSON_DATA_OTHERS_PARTNERCODE,
				sum(CASE 
            WHEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
            THEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) * 1
            WHEN 
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
            THEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)* 12
            else 0
    END) as ape,COALESCE(avt.VNB_AF_REIN_DIVER , 0) AS ACTUAL_VNB
			from
				{env}_silver.users_data_silver as s
			join {env}_ainbo_silver.product_lookup_silver as l
on
				lower(l.product_id) = lower(s.after_product_type)
				and lower(l.source_system) = 'nbm'
				left join (select POLICY_NUMBER ,sum(VNB_AF_REIN_DIVER) as VNB_AF_REIN_DIVER from {env}_silver.actual_vnb_silver group by POLICY_NUMBER) as avt on s.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO=avt.POLICY_NUMBER
			where
				upper(after_user_view) = upper('quote.payment')
				and upper(after_status) = upper('payment')
				and JSON_DATA_OTHERS_PARTNERCODE not in (
				select
					Partner_Name
				from
					{env}_vnb.vnb_channel_silver)
			group by
			ACTUAL_VNB,
				JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO,
				after_product_type,
				l.product_name,
				json_data_others_utmcontent,
				JSON_DATA_OTHERS_PARTNERCODE
) as t2 on
			t1.Partner_Name = t2.JSON_DATA_OTHERS_PARTNERCODE
) as t4 on
		t3.Digital_Channel = t4.Digital_Channel
		and t3.Product_ID = t4.after_product_type
union
	select
		*,
		((t3.VNB_PERCENT / 100)* t4.ape) as vnb
	from
		{env}_vnb.vnb_rates_silver as t3
	join(
		select
			*
		from
			{env}_vnb.vnb_channel_silver as t1
		join(
			select
			s.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO as POLICY_NO,
				after_product_type,
				l.product_name as product_name_1,
				nvl(json_data_others_utmcontent,
				'') as datavalue_utmTracking_utmContent,
				count(*) as count,
				max(UDH_INSERT_TIMESTAMP) as udh_insert_timestamp_1,
				'nbm' as source_system,
				JSON_DATA_OTHERS_PARTNERCODE,
				sum(CASE 
            WHEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)> cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
            THEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) * 1
            WHEN 
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL) <= cast(JSON_DATA_POLICYDATA_TOTALPREMIUMS_MONTHLY_AFTERGST_PREMIUM_BEFOREMARKETINGDIS_BEFORELOADING as DECIMAL)
            THEN
                cast(JSON_DATA_FRONTENDDATA_XSELL_PREMIUMPAID as DECIMAL)* 12
            else 0
    END) as ape,COALESCE(avt.VNB_AF_REIN_DIVER , 0) AS ACTUAL_VNB
			from
				{env}_silver.users_data_silver as s
			join {env}_ainbo_silver.product_lookup_silver as l
on
				lower(l.product_id) = lower(s.after_product_type)
					and lower(l.source_system) = 'nbm'
					left join (select POLICY_NUMBER ,sum(VNB_AF_REIN_DIVER) as VNB_AF_REIN_DIVER from {env}_silver.actual_vnb_silver group by POLICY_NUMBER) as avt on s.JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO=avt.POLICY_NUMBER
				where
					upper(after_user_view) = upper('quote.payment')
						and upper(after_status) = upper('payment')
							and JSON_DATA_OTHERS_PARTNERCODE in (
							select
								Partner_Name
							from
								{env}_vnb.vnb_channel_silver)
						group by
						ACTUAL_VNB,
						 JSON_DATA_POLICIES_3CI_POLICYDETAILS_POLICYNO,
							after_product_type,
							l.product_name,
							json_data_others_utmcontent,
							JSON_DATA_OTHERS_PARTNERCODE
) as t2 on
			t1.Partner_Name = t2.JSON_DATA_OTHERS_PARTNERCODE
) as t4 on
		t3.Digital_Channel = t4.Digital_Channel
		and t3.Product_ID = t4.after_product_type
)
""")