# Databricks notebook source
# getting the environment variables
import os
env = os.getenv("env").lower()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

# assign the variables
database_name = f"{env}_ainbo_silver"
view_name = "vw_campaign_ainbo_conversion"
nbm_src_tbl = f"{env}_silver.users_data_silver"
non_nbm_src_tbl = f"{env}_silver.nosql_data_entity_silver"
quote_table = "quote_silver"
health_table = "health_question_silver"
personal_table = "personal_info_silver"
summary_table = "summary_silver"
payment_table = "payment_silver"
success_table = "success_silver"
lookup_table = "product_lookup_silver"
nbm_src_system = 'NBM'
non_nbm_src_system = 'NON_NBM'

# COMMAND ----------

# define the external path
quote_loc = f"{path_prefix}/silver/ainbo/quote/"
health_loc = f"{path_prefix}/silver/ainbo/health_question/"
personal_loc = f"{path_prefix}/silver/ainbo/personal_info/"
summary_loc = f"{path_prefix}/silver/ainbo/summary/"
payment_loc = f"{path_prefix}/silver/ainbo/payment/"
success_loc = f"{path_prefix}/silver/ainbo/success/"
lookup_loc = f"{path_prefix}/silver/ainbo/product_lookup/"