# Databricks notebook source
import os
# assign the environment variable
env = os.getenv("env").lower()

# COMMAND ----------

# create view telesales_conversion
spark.sql(f"""
create or replace view {env}_telesales_gold.vw_telesales_conversion as 
SELECT 
      l.PACKAGE as PACKAGE,
      nvl(sum(l.COUNT),0) as NO_RECEIVED_LEADS,
      nvl(sum(p.COUNT),0) as NO_LEADS_PASSED,
      nvl(sum(c.COUNT),0) as NO_POLICY_SOLD,  
      nvl(cast((sum(c.COUNT)*100/sum(p.COUNT)) as decimal(5,2)),0) as CONVERSION_RATE,
      nvl(sum(c.APE),0) as APE,
	  nvl(sum(d.COUNT),0) as USED_LEADS,
      nvl(sum(e.COUNT),0) as CONTACTABLE_LEADS
FROM {env}_telesales_silver.leads_received l
left JOIN {env}_telesales_silver.leads_passed_to_telesales p
on l.PACKAGE = p.PACKAGE
and l.UDH_INSERT_TIMESTAMP = p.UDH_INSERT_TIMESTAMP
left JOIN {env}_telesales_silver.cust_sold_sum_ape_policy c
ON l.PACKAGE = c.PACKAGE
and l.UDH_INSERT_TIMESTAMP = c.UDH_INSERT_TIMESTAMP
left JOIN {env}_telesales_silver.used_leads d
on l.PACKAGE = d.PACKAGE
and l.UDH_INSERT_TIMESTAMP = d.UDH_INSERT_TIMESTAMP
left JOIN {env}_telesales_silver.contactable_leads e
on l.PACKAGE = e.PACKAGE
and l.UDH_INSERT_TIMESTAMP = e.UDH_INSERT_TIMESTAMP
GROUP BY l.PACKAGE
""")

# COMMAND ----------

# MAGIC %sql
# MAGIC