# Databricks notebook source
import os
env = os.getenv("env").lower()
path_prefix = f"/mnt/{env}/fwd_landing"
env = "dev"

# COMMAND ----------

database_name = f"{env}_telesales_silver"
nbm_src_tbl = f"{env}_telesales_silver.telesales_silver"

leads_received_table = "leads_received"
leads_received_loc = f"{path_prefix}/silver/telesales/leads_received/"

passed_to_telesales_table = "leads_passed_to_telesales"
passed_to_telesales_loc = f"{path_prefix}/silver/telesales/leads_passed_to_telesales/"

leads_passed_telesales_table = "total_leads_passed_telesales"
leads_passed_telesales_loc = f"{path_prefix}/silver/telesales/total_leads_passed_telesales/"

cust_sold_sum_ape_policy_table = "cust_sold_sum_ape_policy"
cust_sold_sum_ape_policy_loc = f"{path_prefix}/silver/telesales/cust_sold_sum_ape_policy/"

dashboard_table = "bi_dashboard_table"
dashboard_table_loc =  f"{path_prefix}/adhoc/bi_dashboard_table/"

used_leads_table = "used_leads"
used_leads_table_loc = f"{path_prefix}/silver/telesales/used_leads/"

contactable_leads_table = "contactable_leads"
contactable_leads_table_loc = f"{path_prefix}/silver/telesales/contactable_leads/"

# COMMAND ----------

# ddl for leads_received_table
spark.sql(f"""
create or replace table {database_name}.{leads_received_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string

)
USING DELTA
partitioned By (BATCH_ID)
location '{leads_received_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for passed_to_telesales_table
spark.sql(f"""
create or replace table {database_name}.{passed_to_telesales_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{passed_to_telesales_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for sum_ape_table
spark.sql(f"""
create or replace table {database_name}.{cust_sold_sum_ape_policy_table}
(
PACKAGE string,
COUNT long,
APE DECIMAL(38,2),
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{cust_sold_sum_ape_policy_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for leads_passed_telesales_table
spark.sql(f"""
create or replace table {database_name}.{leads_passed_telesales_table}
(
ID_CARD long,
LEADCREATEDATE timestamp,
PACKAGE string,
UDH_CUST_FIND_TIME timestamp,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{leads_passed_telesales_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{dashboard_table}
(
PACKAGE string,
NO_RECEIVED_LEADS double,
NO_LEADS_PASSED double,
NO_POLICY_SOLD double,
APE double

)
USING DELTA
location '{dashboard_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

spark.sql(f"""
create or replace view {env}_telesales_gold.vw_telesales_conversion as 
SELECT 
      l.PACKAGE as PACKAGE,
      nvl(l.NO_RECEIVED_LEADS,0) as NO_RECEIVED_LEADS,
      nvl(l.NO_LEADS_PASSED,0) as NO_LEADS_PASSED,
      nvl(l.NO_POLICY_SOLD,0) as NO_POLICY_SOLD,  
      nvl(cast((l.NO_POLICY_SOLD*100/NO_LEADS_PASSED) as decimal(32,2)),0)  as CONVERSION_RATE,
      nvl(l.APE,0) as APE
FROM {database_name}.{dashboard_table} l
""")

# COMMAND ----------

# ddl for used_leads_table
spark.sql(f"""
create or replace table {database_name}.{used_leads_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{used_leads_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for contactable_leads_table
spark.sql(f"""
create or replace table {database_name}.{contactable_leads_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{contactable_leads_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")