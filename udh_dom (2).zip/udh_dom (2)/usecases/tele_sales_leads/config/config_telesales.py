# Databricks notebook source
# getting the environment variables
import os
env = os.getenv("env").lower()
env = "dev"
path_prefix = f"/mnt/{env}/fwd_landing/"

# COMMAND ----------

# create config for all the files
adhoc = {
    "True_Happiness":
    {
		"sheet_2":"'True_Happiness(GI)'!A1",
        "source_path":"adhoc/source/",
        "phone_no":"CellPhone",
        "firstName":"FirstName",
        "lastName":"LastName",
        "dob":"BirthDate",
        "date_format":"yyyy-MM-dd HH:mm:ss",
        "age":"age",
        "email":"EMAIL",
       "fullName":"FullName",
       "day":"day"
        },
    "concated_list":
    {
       "sheet_1":"sheet1",
       "source_path":"adhoc/contacted_list/",
        "firstName":"FirstName",
        "lastName":"LastName",
        "fullName":"FullName",
        "cdate":"ContactDate",
        "day":"day"        
    },
     "blacklist":
    {
       "sheet_1":"sheet1",
       "source_path":"adhoc/blacklist/",
        "firstName":"FirstName",
        "lastName":"LastName",
        "fullName":"FullName"       
    },
     "do_not_vall_list":
    {
       "sheet_1":"sheet1",
       "source_path":"adhoc/do_not_call_list/",
        "firstName":"first_name",
        "lastName":"last_name",
        "fullName":"FullName",
        "mobile_no":"phone_no"
    },
     "Mobilecodes_master":
    {
       "sheet_1":"sheet1",
       "source_path":"adhoc/mobilecodes/",
        "MobileCode":"MobileCode"
    },
   "telesales":
    {
       "sheet_1":"sheet1",
       "source_path":"adhoc/True_uploaded_leads.csv",
       "source_path_json":"adhoc/telesales/",
       "CellPhone":"CellPhone",
    "select_cols":"ActivityId,UserCRMId,PartnerName,Source,MediaSource,DTCCampaignId,NumberOfChild,FirstName,LastName,Sex,Email,CellPhone,LeadCreateDate,BirthDate,Remark",
        "col_stand":{
            "ActivityId":"'null'",
            "UserCRMId":"'null'",
            "PartnerName":"PartnerName",
            "Source":"'null'",
            "MediaSource":"'null'",
            "DTCCampaignId":"DTCCampaignId",
            "NumberOfChild":"'null'",
            "FirstName":"FirstName",
            "LastName":"LastName",
            "Sex":"'null'",
            "Email":"'null'",
            "CellPhone":"CellPhone",
            "LeadCreateDate":"LeadCreateDate",
            "BirthDate":"'null'",
            "Remark":"Remark"
        }
    },
    "excel" : {
        "source_path":"adhoc/excel/"
    },
      "sorDb":"delta",
      "sorDb_temp_view":"sorDB_view",
      "il_identity_table":"il_tb_pty_identity_curr_dim",
      "la_identity_table":"la_tb_pty_identity_curr_dim",
      "identity_temp_table":"identity",
      "il_policy_table":"il_tb_agrt_policy_curr_dim",
      "la_policy_table":"la_tb_agrt_policy_curr_dim",
      "policy_temp_table":"policy",
      "il_coverage_table":"il_tb_agrt_coverage_curr_dim",
      "la_coverage_table":"la_tb_agrt_coverage_curr_dim",
      "coverage_temp_table":"coverage",
       "Partner": "True",
       "Campaign":"Happiness",
       "database_name":"nosqldata",
       "table_name":"sorDB"
    

	}   

# COMMAND ----------

# create config for expected json as final result
expected_json = {
  "col_stand":{
    "ActivityId":"ActivityId",
    "UserCRMId":"UserCRMId",
    "PartnerName":"PartnerName",
    "Source":"'5'",
    "MediaSource":"'null'",
    "DTCCampaignId":"DTCCampaignId",
    "NumberOfChild":"'1'",
    "FirstName":"FirstName",
    "LastName":"LastName",
    "Sex":"Gender",
    "Email":"Email",
    "CellPhone":"CellPhone",
    "LeadCreateDate":"LeadCreateDate",
    "BirthDate":"BirthDate",
    "Remark":"Remark"
  },
"select_cols":"ActivityId,UserCRMId,PartnerName,Source,MediaSource,DTCCampaignId,NumberOfChild,FirstName,LastName,Sex,Email,CellPhone,LeadCreateDate,BirthDate,Remark"
}

# COMMAND ----------

# assign variables for identity and policy table
sorDb = adhoc['sorDb']
sorDb_temp_view = adhoc['sorDb_temp_view']
il_identity_table = adhoc['il_identity_table']
la_identity_table = adhoc['la_identity_table']
identity_temp_table = adhoc['identity_temp_table']
il_policy_table = adhoc['il_policy_table']
la_policy_table = adhoc['la_policy_table']
policy_temp_table = adhoc['policy_temp_table']
il_coverage_table = adhoc['il_coverage_table']
la_coverage_table = adhoc['la_coverage_table']
coverage_temp_table = adhoc['coverage_temp_table']
Partner = adhoc['Partner']
Campaign = adhoc['Campaign']
database_name = adhoc['database_name']
table_name = adhoc['table_name']

# COMMAND ----------

# assign variables for expected json
json_col_standarization = expected_json['col_stand']
select_columns = expected_json['select_cols'].split(",")

# COMMAND ----------

# assign variables for sheet_1(TrueHappiness)
sheet_2 = adhoc['True_Happiness']
sheet_2_name = sheet_2['sheet_2']
sheet_2_source_path = path_prefix + sheet_2['source_path']
sheet_2_phone_no = sheet_2['phone_no']
sheet_2_firstName = sheet_2['firstName']
sheet_2_lastName = sheet_2['lastName']
sheet_2_dob = sheet_2['dob']
sheet_2_date_format = sheet_2['date_format']
sheet_2_age = sheet_2['age']
sheet_2_email = sheet_2['email']
sheet_2_fullName = sheet_2['fullName']
sheet_2_day = sheet_2['day']

# COMMAND ----------

# assign variables for concated_list
concated_list = adhoc['concated_list']
concated_list_sheet_1 = concated_list['sheet_1']
concated_list_source_path = path_prefix + concated_list['source_path']
concated_list_firstName = concated_list['firstName']
concated_list_lastName = concated_list['lastName']
concated_list_fullName = concated_list['fullName']
concated_list_cdate = concated_list['cdate']
concated_list_day = concated_list['day']


# COMMAND ----------

# assign variables for blacklist
blacklist = adhoc['blacklist']
blacklist_sheet_1 = blacklist['sheet_1']
blacklist_source_path = path_prefix + blacklist['source_path']
blacklist_firstName = blacklist['firstName']
blacklist_lastName = blacklist['lastName']
blacklist_fullName = blacklist['fullName']


# COMMAND ----------

# assign variables for do_not_call_list
dnc = adhoc['do_not_vall_list']
dnc_sheet_1 = dnc['sheet_1']
dnc_source_path = path_prefix + dnc['source_path']
dnc_firstName = dnc['firstName']
dnc_lastName = dnc['lastName']
dnc_fullName = dnc['fullName']
dnc_mobile_no = dnc['mobile_no']

# COMMAND ----------

# assign variables for Mobilecodes_master
code = adhoc['Mobilecodes_master']
code_sheet_1 = code['sheet_1']
code_source_path = path_prefix + code['source_path']
code_MobileCode = code['MobileCode']

# COMMAND ----------

# assign variables for Telesales system
telesale = adhoc['telesales']
telesale_sheet_1 = telesale['sheet_1']
telesale_source_path = path_prefix + telesale['source_path']
telesale_CellPhone = telesale['CellPhone']
telesale_source_path_json = path_prefix + telesale['source_path_json']
telesales_col_stand = telesale['col_stand']
telesales_select_cols = telesale['select_cols'].split(",")
excel_source_path = path_prefix + adhoc['excel']['source_path']

# COMMAND ----------

col_dict = {
    "PATRUE1M_PLAN[1-5]":"HAPPINESS UPGRADE",
    "PACOUPLE":"DEAL D DAY",
    "TA_TRUE_PLAN2":"SEASONAL CAMPAIGN"
}
col_name = "PACKAGE"

# COMMAND ----------

lead_received = f"{env}_telesales_silver.leads_received"
lead_passed = f"{env}_telesales_silver.leads_passed_to_telesales"
total_leased_passed = f"{env}_telesales_silver.total_leads_passed_telesales"
sum_ape = f"{env}_telesales_silver.cust_sold_sum_ape_policy"
used_leads = f"{env}_telesales_silver.used_leads"
contactable_leads=f"{env}_telesales_silver.contactable_leads"