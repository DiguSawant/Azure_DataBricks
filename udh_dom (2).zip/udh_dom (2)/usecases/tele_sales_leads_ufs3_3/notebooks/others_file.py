# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ../config/config_telesales

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,read the data from given source location for contacted list
try:
    #load most recent updated file from given directory using find_most_recent_file() 
    concated_list_file_path = find_most_recent_file(concated_list_source_path)
    contacted_df = read_csv(location=concated_list_file_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(concated_list_source_path)
print(concated_list_file_path)
contacted_df.show(10,False)

# COMMAND ----------

#concatination of FirstName and LastName as FullName
#calculates day using day_calculation
try:
    contacted_df = contacted_df.withColumn(concated_list_fullName, concat_ws(' ',concated_list_firstName,concated_list_lastName))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,read the data from given source location for blacklist
try:
    #load most recent updated file from given directory using find_most_recent_file()
    blacklist_file_path = find_most_recent_file(blacklist_source_path)
    blacklist_df = read_csv(location=blacklist_file_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(blacklist_source_path)
print(blacklist_file_path)
blacklist_df.show(10,False)

# COMMAND ----------

#concatination of FirstName and LastName as FullName
try:
    blacklist_df = blacklist_df.withColumn(blacklist_fullName, concat_ws(' ',blacklist_firstName,blacklist_lastName))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,read the data from given source location for do_not_call_list
try:
    #load most recent updated file from given directory using find_most_recent_file()
    dnc_file_path = find_most_recent_file(dnc_source_path)
    dnc_df = read_csv(location=dnc_file_path).dropna()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(dnc_file_path)
print(dnc_source_path)
dnc_df.show(10,False)

# COMMAND ----------

#concatination of FirstName and LastName as FullName
#remove the hyphen from column mobile_no
try:
    dnc_df = dnc_df.withColumn(dnc_fullName, concat_ws(' ',dnc_firstName,dnc_lastName))\
                   .withColumn(dnc_mobile_no,regexp_replace(dnc_mobile_no,"-","")).dropna()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

dnc_df.show(10,False)

# COMMAND ----------

# DBTITLE 1,read the data from given source location for Mobilecodes_master
try:
   #load most recent updated file from given directory using find_most_recent_file()
    mobilecode_file_path = find_most_recent_file(code_source_path)
    Mobilecodes_master_df = read_csv(location=mobilecode_file_path, infer_schema=False)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(mobilecode_file_path)
print(code_source_path)
Mobilecodes_master_df.show(10,False)

# COMMAND ----------

#fetching the value from MobileCode and appending it as list
try:
    mobilecodes = Mobilecodes_master_df.select(code_MobileCode).collect()
    mobilecode_list = []
    for mobilecode in mobilecodes:
        mobilecode_list.append(mobilecode[0])
    mobilecode_list_str = str(mobilecode_list)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(mobilecode_list_str)

# COMMAND ----------

