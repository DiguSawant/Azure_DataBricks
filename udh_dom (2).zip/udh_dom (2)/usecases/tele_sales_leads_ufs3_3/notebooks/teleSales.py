# Databricks notebook source
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../config/config_telesales

# COMMAND ----------

#read the excel data from given source location
try:
    telesales_system_df = read_csv(location=telesale_source_path)    
except Exception as e:
    raise Exception(e)

# COMMAND ----------

print(telesale_source_path)
telesales_system_df.show(10,False)

# COMMAND ----------

#append the partition_date as partition column
telesales_partition_df = telesales_system_df.withColumn(telesale_CellPhone,regexp_replace(telesale_CellPhone,"-","")).withColumn("partition_date",lit("20230306"))

# COMMAND ----------

#write the telesales_partition_df as json in given location 
try:
    write_to_path(df = telesales_partition_df.coalesce(1), file_format = "json", location = telesale_source_path_json, mode="append", partitionColumn=["partition_date"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

telesales_partition_df.show(10,False)
print(telesale_source_path_json)