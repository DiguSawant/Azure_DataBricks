# Databricks notebook source
# getting the environment variables
import os
env = os.getenv("env").lower()
env = "dev"
path_prefix = f"/mnt/{env}/fwd_landing/"

# COMMAND ----------

# create config for all the files
adhoc = {
    "excel" : {
        "sheet_1":"tbl_TrueDaily",
        "source_path":"adhoc/excel/"
    }
}   

# COMMAND ----------

used_leads = f"{env}_telesales_silver.used_leads"
contactable_leads=f"{env}_telesales_silver.contactable_leads"

# COMMAND ----------

excel_source_path = path_prefix + adhoc['excel']['source_path']
excel_sheet_1 = adhoc['excel']['sheet_1']

# COMMAND ----------

col_dict = {
    "PATRUE1M_PLAN[1-5]":"HAPPINESS UPGRADE",
    "PACOUPLE":"DEAL D DAY",
    "TA_TRUE_PLAN2":"SEASONAL CAMPAIGN"
}
col_name = "PACKAGE"