# Databricks notebook source
import os
env = os.getenv("env").lower()
env = "dev"
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

database_name = f"{env}_telesales_silver"

used_leads_table = "used_leads"
used_leads_table_loc = f"{path_prefix}/silver/telesales/used_leads/"
contactable_leads_table = "contactable_leads"
contactable_leads_table_loc = f"{path_prefix}/silver/telesales/contactable_leads/"

# COMMAND ----------

# ddl for used_leads_table
spark.sql(f"""
create or replace table {database_name}.{used_leads_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{used_leads_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for contactable_leads_table
spark.sql(f"""
create or replace table {database_name}.{contactable_leads_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{contactable_leads_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")