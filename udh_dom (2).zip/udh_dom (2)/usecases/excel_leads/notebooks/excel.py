# Databricks notebook source
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../config/config_excel

# COMMAND ----------

# get current timestamp
cur_time = spark.sql("SELECT current_timestamp()").collect()[0][0]

# COMMAND ----------

# define current date and time
from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

try:
    # load most recent updated file from given directory using find_most_recent_file()
    excel_file_path = find_most_recent_file(excel_source_path)
    excel_df = read_csv(excel_file_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

excel_df = excel_df.withColumn("Package",trim(split(col("Remark"),'-')[0]))

# COMMAND ----------

excel_df.display()
excel_df = campaign_reco(excel_df, col_name, col_dict)

# COMMAND ----------

final_used_leads = excel_df.filter(~ col("Latest Status ID").startswith("0"))

# COMMAND ----------

# write lead passed to telesales data into table
try:
    final_used_leads\
                .groupBy("Package")\
                .count()\
                .withColumn("SOURCE_SYSTEM",lit("TRUE HAPPINESS"))\
                .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
                .withColumn("BATCH_ID",lit(curr_date))\
                .write\
                .mode("append")\
                .saveAsTable(used_leads)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

excel_df.select("package").distinct().show()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_telesales_silver.used_leads;

# COMMAND ----------

final_contactable_leads=excel_df.filter(~ col("Latest Status ID").startswith("1"))
#print(final_contactable_leads)

# COMMAND ----------

# write Contactable leads passed to telesales data into table
try:
    final_contactable_leads\
                .groupBy("Package")\
                .count()\
                .withColumn("SOURCE_SYSTEM",lit("TRUE HAPPINESS"))\
                .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
                .withColumn("BATCH_ID",lit(curr_date))\
                .write\
                .mode("append")\
                .saveAsTable(contactable_leads)
except Exception as e:
    raise Exception(e)