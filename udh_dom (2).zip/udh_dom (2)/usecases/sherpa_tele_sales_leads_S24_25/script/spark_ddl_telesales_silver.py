# Databricks notebook source
import os
# env = os.getenv("env").lower()
env = "dev"
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

database_name = f"{env}_telesales_silver"
nbm_src_tbl = f"{env}_telesales_silver.telesales_silver"

leads_received_table = "leads_received"
leads_received_loc = f"{path_prefix}/silver/telesales/leads_received/"

passed_to_telesales_table = "leads_passed_to_telesales"
passed_to_telesales_loc = f"{path_prefix}/silver/telesales/leads_passed_to_telesales/"

leads_passed_telesales_table = "total_leads_passed_telesales"
leads_passed_telesales_loc = f"{path_prefix}/silver/telesales/total_leads_passed_telesales/"

cust_sold_sum_ape_policy_table = "cust_sold_sum_ape_policy"
cust_sold_sum_ape_policy_loc = f"{path_prefix}/silver/telesales/cust_sold_sum_ape_policy/"

# COMMAND ----------

# ddl for leads_received_table
spark.sql(f"""
create or replace table {database_name}.{leads_received_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string

)
USING DELTA
partitioned By (BATCH_ID)
location '{leads_received_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for passed_to_telesales_table
spark.sql(f"""
create or replace table {database_name}.{passed_to_telesales_table}
(
PACKAGE string,
COUNT long,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{passed_to_telesales_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for sum_ape_table
spark.sql(f"""
create or replace table {database_name}.{cust_sold_sum_ape_policy_table}
(
PACKAGE string,
COUNT long,
SUM DECIMAL(38,2),
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{cust_sold_sum_ape_policy_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

# ddl for leads_passed_telesales_table
spark.sql(f"""
create or replace table {database_name}.{leads_passed_telesales_table}
(
ID_CARD long,
LEADCREATEDATE timestamp,
PACKAGE string,
UDH_CUST_FIND_TIME timestamp,
SOURCE_SYSTEM string,
UDH_INSERT_TIMESTAMP timestamp,
BATCH_ID string
)
USING DELTA
partitioned By (BATCH_ID)
location '{leads_passed_telesales_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")