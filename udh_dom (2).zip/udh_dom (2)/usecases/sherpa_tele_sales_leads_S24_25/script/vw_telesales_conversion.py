# Databricks notebook source
import os
# assign the environment variable
# env = os.getenv("env").lower()
env = "dev"

# COMMAND ----------

# create view telesales_conversion
spark.sql(f"""
create or replace view {env}_telesales_gold.vw_telesales_conversion as 
SELECT 
      l.PACKAGE as PACKAGE,
      sum(l.COUNT) as NO_RECEIVED_LEADS,
      sum(p.COUNT) as NO_LEADS_PASSED,
      sum(c.COUNT) as NO_POLICY_SOLD,  
      cast((sum(c.COUNT)*100/sum(p.COUNT)) as decimal(5,2)) as CONVERSION_RATE,
      sum(c.SUM) as APE 
FROM {env}_telesales_silver.leads_received l
left JOIN {env}_telesales_silver.leads_passed_to_telesales p
on l.PACKAGE = p.PACKAGE
and l.UDH_INSERT_TIMESTAMP = p.UDH_INSERT_TIMESTAMP
left JOIN {env}_telesales_silver.cust_sold_sum_ape_policy c
ON l.PACKAGE = c.PACKAGE
and l.UDH_INSERT_TIMESTAMP = c.UDH_INSERT_TIMESTAMP
GROUP BY l.PACKAGE
""")

# COMMAND ----------

# MAGIC %sql SELECT * FROM dev_telesales_silver.leads_received LIMIT 10