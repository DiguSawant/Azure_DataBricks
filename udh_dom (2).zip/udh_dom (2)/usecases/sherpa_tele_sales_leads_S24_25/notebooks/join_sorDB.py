# Databricks notebook source
# DBTITLE 1,running notebook aes
# MAGIC %run /Shared/udh_dom/tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run  /Shared/udh_dom/tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running Notebook config
# MAGIC %run /Shared/udh_dom/usecases/sherpa_tele_sales_leads/config/config_sherpa

# COMMAND ----------

try:
    # get the data from delta.il_tb_pty_identity_curr_dim into il_identity dataframe
    il_identity =  spark.sql(f"""select * from {sorDb}.{il_identity_table} """)
    # get the data from delta.la_tb_pty_identity_curr_dim into la_identity dataframe
    la_identity =  spark.sql(f"""select * from {sorDb}.{la_identity_table} """)
    # union il_identity and la_identity
    merge_identity_df = il_identity.unionByName(la_identity, allowMissingColumns=True)
    # creating temporary view 
    merge_identity_df.createOrReplaceTempView(f"{identity_temp_table}")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # get the data from delta.li_tb_agrt_policy_curr_dim li_policy dataframe
    il_policy =  spark.sql(f"""select * from {sorDb}.{il_policy_table} """)
    # get the data from delta.la_tb_agrt_policy_curr_dim into la_policy dataframe
    la_policy =  spark.sql(f"""select * from {sorDb}.{la_policy_table} """)
    # union il_policy and la_policy
    merge_policy_df = il_policy.unionByName(la_policy, allowMissingColumns=True)
    # creating temporary view 
    merge_policy_df.createOrReplaceTempView(f"{policy_temp_table}")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    #join both policy_temp_table and identity_temp_table
    joinDf = spark.sql(f"""select distinct aes_decrypt(p.POLICY_ID) as policy_id, p.MAIN_POLICY_OWNER_ID as owner_id, p.POLICY_ISSUE_DATE as issue_date, aes_decrypt(i.IDENTITY_NUM) as owner_national_id,p.next_premium_amt as next_premium_amt,p.billing_frequency_code as billing_frequency_code from {policy_temp_table} p inner join    {identity_temp_table} i on p.MAIN_POLICY_OWNER_ID = aes_decrypt(i.PARTY_ID)""")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # convert issue_date into date with to_date() using epoc_to_date() udf
    dateDf = joinDf.withColumn('date', to_date(udf_epoch_to_date("issue_date")))
    # count day diffrence from current_date to date using datediff()
    dayDf = dateDf.withColumn("day", datediff(current_date(),'date'))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # create tmporary view 
    dayDf.createOrReplaceTempView(f"{sorDb_temp_view}")
    # filter the data where issue_date is in last 180
    sorDB_Df = spark.sql(f"""select * from {sorDb_temp_view} where day <= 180 """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # create tmporary view 
#     dayDf.createOrReplaceTempView(f"{sorDb_temp_view}")
    # filter the data where issue_date is in last 180
    sorDB_existing_cust_check = spark.sql(f"""select * from {sorDb_temp_view} where day > 180 """).cache()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# try:
#     # create delta table 
#     sorDB_Df.write.format("delta").saveAsTable(f"{database_name}.{table_name}")
# except Exception as e:
#     raise Exception(e)