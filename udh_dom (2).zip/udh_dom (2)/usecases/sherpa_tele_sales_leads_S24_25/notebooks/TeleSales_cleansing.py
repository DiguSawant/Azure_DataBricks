# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ../config/config_sherpa

# COMMAND ----------

# DBTITLE 1,running aes notebook
# MAGIC %run /Shared/udh_dom_old/tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_utility
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook others_file
# MAGIC %run ./others_file

# COMMAND ----------

# DBTITLE 1,running notebook join_sorDB
# MAGIC %run /Shared/udh_dom/usecases/sherpa_tele_sales_leads/notebooks/join_sorDB

# COMMAND ----------

# DBTITLE 1,importing requireds
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,read the data from given source location for sheet_2
try:
   #load most recent updated file from given directory using find_most_recent_file() 
    sheet_2_file_path = find_most_recent_file(sheet_2_source_path)
    sheet_2_df = read_csv(location=sheet_2_file_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,drop if all the null fields
try:
    sheet_2_df = sheet_2_df.dropDuplicates().dropna(how='all')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,trim the fileds using trim_fields function
try:
    sheet_2_df = trim_fields(df=sheet_2_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,normalize the columns(replacing dot,hyphen,and spaces by underscore)
try:
    sheet_2_df = normalize_column_name(sheet_2_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,drop the duplicates for given column--phone_no and name
try:
    sheet_2_df = sheet_2_df.dropDuplicates([sheet_2_phone_no]).dropDuplicates([sheet_2_firstName,sheet_2_lastName]).withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,calculate the age on given column and format
# try:
#     sheet_2_df = age_calculation(df=sheet_2_df,column=sheet_2_dob, date_format=sheet_2_date_format)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,filter the age between 20 and 60
try:
    filtered_sheet_2_df = sheet_2_df.where(col(sheet_2_age).between(20, 60))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

filtered_sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,apply the data quality rule for phone_no
try:
    dq_sheet_2_df = filtered_sheet_2_df.where((udf_check_phone_number(sheet_2_phone_no, lit(mobilecode_list_str))==True))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

dq_sheet_2_df.display()

# COMMAND ----------

# DBTITLE 1,concating the FirstName and LastName as FullName and format column CellPhone
try:
    file_date = extract_date(sheet_2_file_path)
    concated_sheet_2_df = dq_sheet_2_df.withColumn(sheet_2_fullName, concat_ws(' ',sheet_2_firstName,sheet_2_lastName))\
                                       .withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-","")).withColumn("file_date",lit(file_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

concated_sheet_2_df.display()

# COMMAND ----------

#importing contacted_df from others_file
try:
    # joining the dataframe to drop the matching records with contacted dataframe
    sheet_2_contacted_df = concated_sheet_2_df.join(contacted_df, concated_sheet_2_df.
                                                    FullName == contacted_df.FullName, "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_contacted_df.display()

# COMMAND ----------

#importing blacklist_df from others_file
try:
    # joining the dataframe to drop the matching records with blacklist dataframe
    sheet_2_blacklist_df = sheet_2_contacted_df.join(blacklist_df, (sheet_2_contacted_df.LastName == blacklist_df.lastname) 
                                                     | (sheet_2_contacted_df.FirstName == blacklist_df.firstname), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_blacklist_df.display()

# COMMAND ----------

# importing dnc_df from others_file
try:
    # joining the dataframe to drop the matching records with do-not-call-list dataframe 
    sheet_2_dnc_df = sheet_2_blacklist_df.join(dnc_df,(sheet_2_blacklist_df.FullName == dnc_df.FullName) 
                                               | (sheet_2_blacklist_df.CellPhone == dnc_df.phone_no), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_dnc_df.display()

# COMMAND ----------

#change here.---->

# COMMAND ----------

individual_df=spark.sql(''' select * from delta.la_tb_pty_individual_curr_dim ''')

# COMMAND ----------

individual_df.display()

# COMMAND ----------

# MAGIC %sql 
# MAGIC SELECT aes_decrypt('rbfdpCmfiCiYEatVdC3Ctg==' )

# COMMAND ----------

# join sheet_2_dnc_df and individual_Df

try:
    sheet_2_sordb = sheet_2_dnc_df.join(individual_df, (sheet_2_dnc_df.FirstName == aes_decrypt(individual_df.first_name)) & (sheet_2_dnc_df.LastName == aes_decrypt(individual_df.last_name)), 'anti')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_sordb=sheet_2_sordb.withColumn("ENLable",when(sheet_2_sordb.
PreferredTime == 1, '8am-12pm').when(sheet_2_sordb.
PreferredTime == 2, '12pm-1pm').when(sheet_2_sordb.
PreferredTime == 3, '1pm-3pm').when(sheet_2_sordb.
PreferredTime == 4, '3pm-5pm').when(sheet_2_sordb.
PreferredTime == 0, 'N/A'))

# COMMAND ----------

sheet_2_sordb.display()

# COMMAND ----------

####################delete this cell

# telesales_system_df = spark.read.csv('/mnt/fwd_test/adhoc/True_uploaded_leads.csv', header=True)

# COMMAND ----------

# # read telesales data 
try:
    telesales_system_df = read_json(location = telesale_source_path_json, multiline=False)
    telesales_system_df = telesales_system_df.withColumn("DTCOutToTSR",explode("DTCOutToTSR")).select("DTCOutToTSR.*")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

telesales_system_df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC select aes_decrypt('
# MAGIC ���')

# COMMAND ----------

try:
    # joining the dataframe to drop the matching records with teleSystem dataframe
    sheet_2_telesales_system_df = sheet_2_sordb.join(telesales_system_df, (sheet_2_sordb.FirstName == telesales_system_df.FirstName)&(sheet_2_sordb.LastName == telesales_system_df.LastName), 'anti') 
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_telesales_system_df.display()

# COMMAND ----------

#use concatination-->concat(Package+Recommended coverage+preferred time)as Package
#telesales_system_df=telesales_system_df.withColumn()

# COMMAND ----------

# join sheet_2_dnc_df and sorDB_Df
#importing the sorDB_existing_cust_check from join_sorDB notebook
try:
    sheet_2_sordb_existing_cust = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'semi').withColumn("Remark",lit("Existing FWD customer "))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_sordb_existing_cust.display()

# COMMAND ----------

sheet_2_telesales_system_df=sheet_2_telesales_system_df.withColumn("Package",split(col("DTCCampaignId"),'_')[0])

# COMMAND ----------

sheet_2_telesales_system_df.display()

# COMMAND ----------

# join sheet_2_contacted_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    sheet_2_sordb_1 = sheet_2_telesales_system_df.join(sorDB_existing_cust_check, sheet_2_telesales_system_df.UserId== sorDB_existing_cust_check.owner_national_id, 'anti').withColumn("Remark",concat_ws('-','ExpectedProductName','RecommendedCoverage','ENLable'))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_sordb_1.display()

# COMMAND ----------

try:
    sheet_2_union_df = sheet_2_sordb_existing_cust.unionByName(sheet_2_sordb_1, allowMissingColumns=True)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_union_df.display()

# COMMAND ----------

# assign vaiables to create diffrent conditions as per final expected result
PartnerName_hyphen = concat_ws('-', lit(Partner), lit(Campaign))
PartnerName = concat_ws('', lit(Partner), lit(Campaign))
concat_file_date = concat_ws('',lit("Daily"), col("file_date").substr(1,6))

# COMMAND ----------

# create column PartnerName and DTCCampaignId
try:
    sheet_2_DTCCampaignId_df = sheet_2_union_df.withColumn("PartnerName", PartnerName)\
                                .withColumn("DTCCampaignId_1", concat_file_date)\
                                .withColumn("DTCCampaignId", PartnerName)\
                                .withColumn("DTCCampaignId", concat_ws('-', col("DTCCampaignId"),                     col("DTCCampaignId_1"), lit("001"), col("file_date").substr(1,6))).drop("DTCCampaignId_1")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_DTCCampaignId_df.display()

# COMMAND ----------

# create column userCRM
try:
    sheet_2_userCRM_df = sheet_2_DTCCampaignId_df\
                         .withColumn("userCRM", concat_ws('',lit("Load#"), col("PartnerName"), col("file_date")))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_userCRM_df.display()

# COMMAND ----------

# create column id to generate unique number that will be use to create prefix and suffix conditions
try:
    w = Window().orderBy(lit('1'))
    sheet_2_userCRM_df = sheet_2_userCRM_df.withColumn("id", row_number().over(w))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# create column ActivityId
max_suffix_1 = 999999
max_suffix_2 = 999999

try:
    # calculate the values for each suffix based on current row number
    suffix_2_df = sheet_2_userCRM_df.withColumn("pattern", PartnerName_hyphen)\
                                    .withColumn("pattern_1", concat_ws('',col("pattern"), col("file_date")))\
                                    .withColumn("suffix_2", lpad(when(col("id") <= max_suffix_1, col("id"))\
                                    .otherwise((col("id") - max_suffix_1) % (max_suffix_2 + 1)), 6, "0"))
    
    suffix_1_df = suffix_2_df.withColumn("suffix_1", lpad(when(col("id") <= max_suffix_1, lit(0))\
                             .otherwise(col("id") - max_suffix_1), 6, "0"))

    # concanate the prefix and suffixes 
    sheet_2_ActivityId_df = suffix_1_df.withColumn("ActivityId", concat_ws("-", col("pattern_1"), col("suffix_1"), col("suffix_2")))

    # create userCRMId column
    sheet_2_userCRMId_df = sheet_2_ActivityId_df.withColumn("userCRMId", concat_ws('-', col('userCRM'),col('suffix_2')))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#DONE

# COMMAND ----------

sheet_2_userCRMId_df.display()

# COMMAND ----------

#select the required column using col_standarization method
try:
    sheet_2_standDf = col_standarization(df = sheet_2_userCRMId_df, columns = json_col_standarization)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

    sheet_2_standDf.display()

# COMMAND ----------

# DBTITLE 1,select all the target fields
#create party table dataframe with all columns of party table
try:
    sheet_2_parttion_df = sheet_2_standDf.distinct().withColumn("partition_date",lit(file_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_parttion_df.display()

# COMMAND ----------

#select all columns that is required for expected result
try:
    select_cols_df = sheet_2_parttion_df.select(*select_columns, "partition_date")
except Exception as e:
    raise Exception(e) 

# COMMAND ----------

sheet_2_parttion_df.printSchema

# COMMAND ----------

select_cols_df.printSchema

# COMMAND ----------



# COMMAND ----------

select_cols_df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC * if you want to write the file in csv format remove the %md  
# MAGIC #write the telesales_partition_df as csv in given location 
# MAGIC try:    
# MAGIC     write_csv(df = csv_df.coalesce(1), location = "dbfs:/mnt/prod/fwd_landing/adhoc/csv/", mode="overwrite", partitionColumn=["partition_date"])
# MAGIC except Exception as e:
# MAGIC     raise Exception(e)

# COMMAND ----------

# col_dict = {
#     "PATRUE1M_PLAN[1-5]":"HAPPINESS UPGRADE",
#     "PA Couple":"DEAL D DAY",
#     "TA True Plan 2":"SEASONAL CAMPAIGN"
# }
# col_name = "PACKAGE"

# def campaign_reco(df,col_name,col_dict):
#     for key in col_dict:
#         df = df.withColumn(col_name,regexp_replace("Package",key,col_dict[key]))
#     return df

# df = campaign_reco(sheet_2_df,col_name,col_dict)

# COMMAND ----------

# grouped results into array with DTCOutToTSR as parent object
grouped_df = select_cols_df.groupBy("partition_date")\
                            .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","Age","Remark"))\
                            .alias("DTCOutToTSR"))

# COMMAND ----------

grouped_df.display()

# COMMAND ----------

# # write the telesales_partition_df as json in given location 
try:
    path = "mnt/dev/fwd_landing/adhoc/sherpa/target/"
    write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = path, mode="append", partitionColumn=["partition_date"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# define current date and time
from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

# get current timestamp
cur_time = spark.sql("SELECT current_timestamp()").collect()[0][0]

# COMMAND ----------

# MAGIC %sql
# MAGIC drop database sherpa

# COMMAND ----------

sheet_2_df=sheet_2_df.withColumn("Package",split(col("DTCCampaignId"),'_')[0])

# COMMAND ----------

sheet_2_df.display()

# COMMAND ----------

##############delete this cell
# write lead recived data into table
try:
    sheet_2_df = campaign_reco(sheet_2_df, col_name, col_dict)
    sheet_2_df\
            .groupBy("Package")\
            .count()\
            .withColumn("SOURCE_SYSTEM",lit("TRUE SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write\
            .mode("append")\
            .saveAsTable("sherpa.lead_received")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

sheet_2_parttion_df.columns

# COMMAND ----------

sheet_2_parttion_df=sheet_2_parttion_df.withColumn("Package",split(col("DTCCampaignId"),'-')[0])

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sherpa.lead_received

# COMMAND ----------

sheet_2_parttion_df=sheet_2_parttion_df.withColumn("Package",split(col("DTCCampaignId"),'-')[0])

# COMMAND ----------

# write lead passed to telesales data into table
try:
    sheet_2_parttion_df = campaign_reco(sheet_2_parttion_df, col_name, col_dict)
    sheet_2_parttion_df\
                .groupBy("Package")\
                .count()\
                .withColumn("SOURCE_SYSTEM",lit("TRUE SHERPA"))\
                .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
                .withColumn("BATCH_ID",lit(curr_date))\
                .write\
                .mode("append")\
                .saveAsTable("sherpa.lead_passed")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sherpa.lead_passed

# COMMAND ----------


# write total leads passed into table
try:
    sheet_2_parttion_df\
            .select("UserId","LeadCreateDate","Package")\
            .withColumn("UserId",col("UserId").cast(LongType()))\
            .withColumn("LeadCreateDate",col("LeadCreateDate").cast(TimestampType()))\
            .withColumn("UDH_CUST_FIND_TIME",lit(None).cast(TimestampType()))\
            .withColumn("SOURCE_SYSTEM",lit("TRUE SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write.format("delta")\
            .mode("append")\
            .saveAsTable("sherpa.total_lead_passed")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sherpa.total_lead_passed

# COMMAND ----------

#get the count and and sum of count 
count_cust_sold_policy = spark.sql(f"""
                                    select 
                                    t.Package as PACKAGE,
                                    count(*) as COUNT,
                                    cast(sum(next_premium_amt*billing_frequency_code) as DECIMAL(38,2)) as SUM
                                    from sherpa.total_leased_passed t
                                    join sorDB_view as s
                                    on t.UserId = s.owner_national_id
                                    where s.date >= to_date(LeadCreateDate)
                                    and t.udh_cust_find_time IS NULL
                                    GROUP BY t.Package
                         """)

#write sum of count the policy sold to customer 
try:
    count_cust_sold_policy\
            .withColumn("SOURCE_SYSTEM",lit("TRUE SHERPA"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))\
            .write.format("delta")\
            .mode("append")\
            .saveAsTable("sherpa.sum_ape")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sherpa.sum_ape

# COMMAND ----------

# merge total_leased_passed using sorDB_view to get update of udh_cust_find_time if any
try:
    spark.sql(f"""
        MERGE INTO sherpa.total_leased_passed t 
        USING (select distinct owner_national_id from sorDB_view s join sherpa.total_leased_passed t on t.UserId = s.owner_national_id  where s.date>=to_date(t.LeadCreateDate)) m 
        ON t.UserId = m.owner_national_id
        WHEN MATCHED THEN UPDATE 
        SET udh_cust_find_time = '{cur_time}'
        """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# grouped results into array with DTCOutToTSR as parent object
grouped_df = select_cols_df.groupBy("partition_date")\
                            .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","BirthDate","Remark"))\
                            .alias("DTCOutToTSR"))

# COMMAND ----------

# # write the telesales_partition_df as json in given location 
# try:
#     path = telesale_source_path_json
#     write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = path, mode="append", partitionColumn=["partition_date"])
# except Exception as e:
#     raise Exception(e)