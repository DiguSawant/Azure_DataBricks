# Databricks notebook source
# DBTITLE 1,running notebook config
# MAGIC %run ../config/config_telesales

# COMMAND ----------

# DBTITLE 1,running notebook aes
# MAGIC %run ../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_functions
# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook others_file
# MAGIC %run ./others_file

# COMMAND ----------

# DBTITLE 1,running notebook join_sorDB
# MAGIC %run ./join_sorDB

# COMMAND ----------

from datetime import datetime, timedelta
import pytz
# set time zone
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")

# COMMAND ----------

# DBTITLE 1,importing requireds
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,read ifwd data for true campaigns
try:
    ifwd_df = spark.readStream\
                         .format("delta")\
                         .load("/mnt/fwd_test/prashant_dev_1/telesales/silver_data/udh_batch_id=20230428/")\
                         .filter((col("ET_ENTITYNAME")==entity_name) & (col("ET_APPLICATION")==entity_application) & (col("ET_SYSTEMCREATEDDT")>=lead_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# select columns and decrypt caloumns datavalue
try:
    ifwd_decrypt_df = ifwd_df.select(*select_cols).withColumn(encrypted_column, aes_decrypt(encrypted_column))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# query to get the selected columns
try:
    # create temp view 
    ifwd_decrypt_df.createOrReplaceTempView("temp_vw")

    # query to get data for true leads
    telesales_df = spark.sql(""" 
    SELECT * from(select  b.ET_SYSTEMCREATEDDT as LeadCreateDate
    , max( case b.DT_DATAKEY when 'USERID' then b.DT_DATAVALUE else NULL end)                         as UserId
    , max( case b.DT_DATAKEY when 'CONSENTCHECKEDDATE' then b.DT_DATAVALUE else NULL end)             as ConsentCheckedDate
    , max( case b.DT_DATAKEY when 'EMAIL' then b.DT_DATAVALUE else NULL end)                          as Email
    , max( case b.DT_DATAKEY when 'FIRSTNAME' then b.DT_DATAVALUE else NULL end)                      as FirstName
    , max( case b.DT_DATAKEY when 'CELLPHONE' then b.DT_DATAVALUE else NULL end)                      as CellPhone
    , max( case b.DT_DATAKEY when 'PARTNERNAME' then b.DT_DATAVALUE else NULL end)                    as PartnerName
    , max( case b.DT_DATAKEY when 'CONSENTCHECKBOX' then b.DT_DATAVALUE else NULL end)                as ConsentCheckBox
    , max( case b.DT_DATAKEY when 'SOURCE' then b.DT_DATAVALUE else NULL end)                         as Source
    , max( case b.DT_DATAKEY when 'DTCCAMPAIGNID' then b.DT_DATAVALUE else NULL end)                  as DTCCampaignId
    , max( case b.DT_DATAKEY when 'CONSENTVERSIONCD' then b.DT_DATAVALUE else NULL end)               as ConsentVersionCd
    , max( case b.DT_DATAKEY when 'CONSENTMSG' then b.DT_DATAVALUE else NULL end)                     as ConsentMsg
    , max( case b.DT_DATAKEY when 'LASTNAME' then b.DT_DATAVALUE else NULL end)                       as LastName
    , max( case b.DT_DATAKEY when 'REQUIREULLICENSE' then b.DT_DATAVALUE else NULL end)               as RequireULLicense
    , max( case b.DT_DATAKEY when 'BIRTHDATE' then b.DT_DATAVALUE else NULL end)                      as BirthDate
    , max( case b.DT_DATAKEY when 'SEX' then b.DT_DATAVALUE else NULL end)                            as Sex
    from temp_vw b group by b.ET_ENTITYSEQ, b.ET_SYSTEMCREATEDDT)
    where DTCCampaignId in ('TrueSenior-All-001-01032023', 'TrueSpecialDay-All-001-01032023', 'TrueVas-All-001-01032023')
""")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,drop if all the null fields
try:
    telesales_df = telesales_df.dropna(how='all')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,trim the fileds using trim_fields function
try:
    trim_df = trim_fields(df=telesales_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,normalize the columns(replacing dot,hyphen,and spaces by underscore)
try:
    normalize_df = normalize_column_name(trim_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,appending column package and file_date and concate first name and last name as full_name
try:
    normalize_df = normalize_df.withColumn(sheet_2_phone_no,regexp_replace(sheet_2_phone_no,"-",""))\
                               .withColumn(sheet_2_fullName, concat_ws(' ',sheet_2_firstName,sheet_2_lastName))\
                               .withColumn("Package",split(col("DTCCampaignId"),'-')[0])\
                               .withColumn("file_date",split(col("DTCCampaignId"),'-')[3])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,calculate the age on given column and format
# try:
#     age_df = age_calculation(df=normalize_df,column=sheet_2_dob, date_format=sheet_2_date_format)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,filter the age between 20 and 60
# try:
#     filtered_sheet_2_df = age_df.where(col(sheet_2_age).between(20, 60))
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# DBTITLE 1,apply the data quality rule for phone_no and email
try:
    dq_df = normalize_df.where((udf_check_phone_number(sheet_2_phone_no, lit(mobilecode_list_str))==True))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing contacted_df from others_file
try:
    # joining the dataframe to drop the matching records with contacted dataframe
    contacted_df = dq_df.join(contacted_df, dq_df.FullName == contacted_df.FullName, "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#importing blacklist_df from others_file
try:
    # joining the dataframe to drop the matching records with blacklist dataframe
    blacklist_df = contacted_df.join(blacklist_df, (contacted_df.UserId == blacklist_df.national_id) 
                                                     | (contacted_df.FullName == blacklist_df.FullName), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# importing dnc_df from others_file
try:
    # joining the dataframe to drop the matching records with do-not-call-list dataframe 
    dnc_df = blacklist_df.join(dnc_df, (blacklist_df.UserId == dnc_df.national_id) 
                                               | (blacklist_df.FullName == dnc_df.FullName) 
                                               | (blacklist_df.CellPhone == dnc_df.phone_no), "anti")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join dnc_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    sordb = dnc_df.join(sorDB_Df, dnc_df.UserId == sorDB_Df.owner_national_id, 'anti')
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # read telesales data 
try:
    telesales_system_df = read_json(location = telesale_source_path_json, multiline=False)
    telesales_system_df = telesales_system_df.withColumn("DTCOutToTSR",explode("DTCOutToTSR")).select("DTCOutToTSR.*","partition_date")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # joining the dataframe to drop the matching records with teleSystem dataframe
    telesales_system_df = sordb.join(telesales_system_df, sordb.CellPhone == telesales_system_df.CellPhone, 'anti').withColumn("partition_date",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_dnc_df and sorDB_Df
#importing the sorDB_existing_cust_check from join_sorDB notebook
try:
    sordb_existing_cust = telesales_system_df.join(sorDB_existing_cust_check, telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'semi').withColumn("Remark",lit("Existing FWD customer "))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write existing leads
try:
    write_stream(df=sordb_existing_cust,file_format="delta", mode="complete", checkpoint_location=ext_leads_checkpoint_Location, path=ext_leads_target_path, partitioncolumn=["partition_date"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join sheet_2_contacted_df and sorDB_Df
#importing the sorDB_Df from join_sorDB notebook
try:
    new_leads_df = telesales_system_df.join(sorDB_existing_cust_check, telesales_system_df.UserId == sorDB_existing_cust_check.owner_national_id, 'anti').withColumn("Remark",lit("null"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write new leads
try:
    write_stream(df=new_leads_df,file_format="delta", mode="complete", checkpoint_location=leads_checkpoint_location, path=leads_target_path, partitioncolumn=["partition_date"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read existing and new leads data
try:
    ext_leads = spark.readStream.format("delta")\
                                 .option("base_path",ext_leads_source_path+"udh_batch_id={}".format(curr_date))\
                                 .load(ext_leads_source_path)
    leads = spark.readStream.format("delta")\
                            .option("base_path",leads_source_path+"udh_batch_id={}".format(curr_date))\
                            .load(leads_source_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# union spark dataframe 
try:
    union_df = ext_leads.unionByName(leads, allowMissingColumns=True)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate column of CellPhone and FullName
try:
    union_df = union_df.dropDuplicates(["CellPhone"]).dropDuplicates(["FullName"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# try:
#     union_df = union_df.withColumn("partition_date",lit(curr_date))
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

try:
    sheet_2_parttion_df = union_df.distinct()
# #select the required column using col_standarization method
    sheet_2_standDf = col_standarization(df = sheet_2_parttion_df, columns = json_col_standarization)
    select_cols_df = sheet_2_standDf.select(*select_columns, "partition_date")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

def foreachFun(df, epoch_id):
    grouped_df = df.groupBy("partition_date")\
                    .agg(collect_list(struct("ActivityId","UserCRMId","PartnerName","Source","MediaSource","DTCCampaignId","NumberOfChild","FirstName","LastName","Sex","Email","CellPhone","LeadCreateDate","BirthDate","Remark"))\
                    .alias("DTCOutToTSR"))
    write_to_path(df = grouped_df.coalesce(1), file_format = "json", location = json_target_path, mode="append", partitionColumn=["partition_date"])

# COMMAND ----------

# define current date and time
from datetime import datetime, timedelta
import pytz
bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_time = timeinbankok.strftime("%Y%m%d%H%M%S")

# COMMAND ----------

# get current timestamp
try:
    cur_time = spark.sql("SELECT current_timestamp()").collect()[0][0]
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %sql
# MAGIC use telesales;
# MAGIC show tables;

# COMMAND ----------

# # write data into lead_received table
# try:
#     normalize_df.groupBy("Package")\
#         .count()\
#         .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
#         .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
#         .withColumn("BATCH_ID",lit(curr_date))\
#         .writeStream.format("delta")\
#         .outputMode("append")\
#         .option("checkpointLocation",lead_received_checkpoint)\
#         .toTable("telesales.lead_recieved")
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

def lead_recieved_batch(df, epoch_id):
    df_1 = df\
        .groupBy("Package")\
        .count()\
        .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
        .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
        .withColumn("BATCH_ID",lit(curr_date))
    df_1.write.format("delta").mode("append").saveAsTable("telesales.lead_recieved")

# COMMAND ----------

normalize_df.writeStream\
.outputMode("complete")\
.option("checkpointLocation",lead_received_checkpoint)\
.foreachBatch(lead_recieved_batch)\
.start()

# COMMAND ----------

# # write data into leads_passed_to_telesales table
# try:
#     sheet_2_standDf.groupBy("Package")\
#         .count()\
#         .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
#         .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
#         .withColumn("BATCH_ID",lit(curr_date))\
#         .writeStream.format("delta")\
#         .outputMode("complete")\
#         .option("checkpointLocation",leads_passed_checkpoint)\
#         .toTable('telesales.lead_passed')
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

def leads_passed_batch(df,epoch_id):
    df_2 = df\
        .groupBy("Package")\
        .count()\
        .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
        .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
        .withColumn("BATCH_ID",lit(curr_date))
    df_2.write.format("delta").mode("append").saveAsTable("telesales.lead_passed")

# COMMAND ----------

sheet_2_standDf.writeStream\
.outputMode("append")\
.option("checkpointLocation",leads_passed_checkpoint)\
.foreachBatch(leads_passed_batch)\
.start()

# COMMAND ----------

# # write total leads passed into table
# try:
#     sheet_2_standDf\
#             .select("UserId","LeadCreateDate","DTCCampaignId")\
#             .withColumn("UserId",col("UserId").cast(LongType()))\
#             .withColumn("LeadCreateDate",col("LeadCreateDate").cast(TimestampType()))\
#             .withColumn("UDH_CUST_FIND_TIME",lit(None).cast(TimestampType()))\
#             .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
#             .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
#             .withColumn("BATCH_ID",lit(curr_date))\
#             .writeStream.format("delta")\
#             .outputMode("append")\
#             .option("checkpointLocation",total_leads_passed_checkpoint)\
#             .toTable(total_leased_passed)
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

def total_leads_batch(df,epoch_id):
    df_3 = df\
            .select(col("UserId").alias("ID_Card"),"LeadCreateDate","Package")\
            .withColumn("ID_Card",col("ID_Card").cast(LongType()))\
            .withColumn("LeadCreateDate",col("LeadCreateDate").cast(TimestampType()))\
            .withColumn("UDH_CUST_FIND_TIME",lit(None).cast(TimestampType()))\
            .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
            .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
            .withColumn("BATCH_ID",lit(curr_date))

    df_3.write.format("delta").mode("append").saveAsTable("telesales.total_leased_passed")

# COMMAND ----------

sheet_2_standDf.writeStream\
.outputMode("append")\
.option("checkpointLocation",total_leads_passed_checkpoint)\
.foreachBatch(total_leads_batch)\
.start()

# COMMAND ----------

# MAGIC %sql SELECT * from telesales.total_leased_passed

# COMMAND ----------

# count_cust_sold_policy = spark.sql("""select  Package,plan_code,DTCCampaignId,sum(APE) as APE,sum((APE*VNB_PERCENT/100)) as VNB ,count(*) as count from (
# (select s.plan_code,t.UserId,t.Package,t.DTCCampaignId as DTCCampaignId,cast((next_premium_amt*billing_frequency_code) as DECIMAL(38,2)) as APE
#                                     from temp_2 t
#                                     join sorDB_view as s
#                                     on t.UserId = s.owner_national_id
#                                     where s.date<=to_date(LeadCreateDate)
#                                     and t.udh_cust_find_time IS NULL ) as t1 join  dev_silver.vnb_rates_silver t2 on t1.plan_code = t2.Product_ID and t2.Channel = "AD" and t2.Digital_Channel = "DM Non-TMB"
#  ) group by  Package,plan_code,DTCCampaignId
#  """)

# COMMAND ----------

try:
    # create temporary view for total_leads_passed_telesales table
    spark.readStream.format("delta").table(total_leased_passed).createOrReplaceTempView("temp")
    count_cust_sold_policy = spark.sql(f"""
                                        select  Package,sum(APE) as APE,sum((APE*VNB_PERCENT/100)) as VNB ,count(*) as count from (
                                        (
                                            select s.plan_code,t.ID_CARD,t.Package,cast((next_premium_amt*billing_frequency_code) as DECIMAL(38,2)) as APE
                                                from
                                                temp t
                                                join
                                                sorDB_view as s
                                                on t.ID_CARD = s.owner_national_id
                                                where s.date >= to_date(LeadCreateDate)
                                                and t.udh_cust_find_time IS NULL ) as t1
                                                left join
                                                {env}_silver.vnb_rates_silver t2 on nvl(t1.plan_code,"RC1A") = t2.Product_ID 
                                                and t2.Channel = "AD" and t2.Digital_Channel = "DM Non-TMB"
                                        ) group by Package
                                        """)

    # count_cust_sold_policy\
    #     .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
    #     .withColumn("UDH_INSERT_TIMESTAMP",lit(curr_time))\
    #     .withColumn("BATCH_ID",lit(curr_date))\
    #     .writeStream.format("delta")\
    #     .outputMode("complete")\
    #     .option("checkpointLocation",cust_sold_checkpoint)\
    #     .toTable(sum_ape)
except Exception as e:
    raise Exception(e)

# COMMAND ----------


def batch_4(df,epoch_id):
    df = df\
        .withColumn("SOURCE_SYSTEM",lit("IFWD"))\
        .withColumn("UDH_INSERT_TIMESTAMP",lit(cur_time))\
        .withColumn("BATCH_ID",lit(curr_date))
        
    df.write.format("delta").mode("append").saveAsTable("telesales.sum_ape")

# COMMAND ----------

count_cust_sold_policy.writeStream\
.outputMode("complete")\
.option("checkpointLocation",cust_sold_checkpoint)\
.foreachBatch(batch_4)\
.start()

# COMMAND ----------

# MAGIC %sql select * from telesales.sum_ape

# COMMAND ----------

# merge total_leased_passed using sorDB_view to get update of udh_cust_find_time if any
try:
    spark.sql(f"""
        MERGE INTO {total_leased_passed} t 
        USING (select distinct owner_national_id from sorDB_view s join {total_leased_passed} t on t.UserId = s.owner_national_id  where s.date>=to_date(t.LeadCreateDate)) m 
        ON t.UserId = m.owner_national_id
        WHEN MATCHED THEN UPDATE 
        SET udh_cust_find_time = '{cur_time}'
        """)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # create view telesales_conversion
# spark.sql(f"""
# create or replace view dev_telesales_silver.vw_telesales_conversion_ifwd_1 as 
# SELECT 
#       l.Package as Package,
#       sum(l.count) as NO_RECEIVED_LEADS,
#       sum(p.count) as NO_LEADS_PASSED,
#       sum(c.count) as NO_POLICY_SOLD,
#       cast((sum(c.count)*100/sum(p.count)) as decimal(5,2)) as CONVERSION_RATE,
#       sum(c.APE) as APE,
#       sum(c.VNB) as VNB
# FROM dev_telesales_silver.leads_received_ifwd l
# left JOIN dev_telesales_silver.passed_to_telesales_ifwd p
# on l.UserId = p.UserId
# left join dev_telesales_silver.cust_sold_policy_ifwd c
# on p.DTCCampaignId = c.DTCCampaignId
# GROUP BY l.Package
# """)

# COMMAND ----------

# %sql select Package,sum(case when stage="recieved" then 1 else 0 end ) as no_recieved_leads,sum(case when stage="passed" then 1 else 0 end ) as no_passed_leads,sum(case when stage="sold" then 1 else 0 end ) as no_sold_leads  ,sum(APE) as APE,SUM(VNB) as VNB  from (
# select Package,DTCCampaignId,APE,VNB,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,BATCH_ID,count,"sold" as stage from dev_telesales_silver.cust_sold_policy_ifwd
# union ALL
# select  Package,DTCCampaignId,0 as APE,0 as VNB,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,BATCH_ID,count,"passed" as stage from dev_telesales_silver.passed_to_telesales_ifwd
# union ALL
# select  Package,DTCCampaignId,0 as APE,0 as VNB,SOURCE_SYSTEM,UDH_INSERT_TIMESTAMP,BATCH_ID,count,"recieved" as stage from dev_telesales_silver.leads_received_ifwd ) group by Package

# COMMAND ----------

# write the telesales_partition_df as json in given location 
try:
    select_cols_df.writeStream.outputMode("append")\
                  .foreachBatch(foreachFun)\
                  .option("checkpointLocation",json_checkpoinLocation)\
                  .start()
except Exception as e:
    raise Exception(e)