# Databricks notebook source
# getting the environment variables
import os
env = os.getenv("env").lower()
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for nbo_demographics
config =  {
    "nbo": { 
     "s3_path" : path_prefix + f"/bronze/ainbo/api_in/TH.{u_env}.ODS.AINBO.API_IN.RECO_OFFER/",
     "schemalocation": path_prefix + "/silver/schema/nbo/",
     "checkpointlocation": path_prefix + "/silver/checkpoint/nbo/",
     "target_path": path_prefix + "/silver/nbo/",
     "pii_columns":["profile_maritalStatus", "profile_gender", "profile_income","profile_age","profile_hasChildren","profile_numberOfChildren","insight_occupationCode"],
     "database_name": env + "_silver",
    "intermediate_table": "nbo_silver",
	"column_schema":StructType([StructField('campaign', StructType([StructField('id', StringType(), True), StructField('medium', StringType(), True), StructField('products', ArrayType(StringType(), True), True), StructField('source', StringType(), True)]), True), StructField('id', StringType(), True), StructField('insight', StructType([StructField('cardFace', StringType(), True), StructField('insuranceSpending', StringType(), True), StructField('occupationCode', StringType(), True), StructField('spendingPerActiveAccount', StringType(), True)]), True), StructField('offer', StructType([StructField('customerSegment', StringType(), True), StructField('key', StringType(), True), StructField('product', StructType([StructField('code', StringType(), True), StructField('name', StringType(), True)]), True), StructField('ranking', StringType(), True)]), True), StructField('profile', StructType([StructField('address', StructType([StructField('district', StringType(), True), StructField('province', StringType(), True), StructField('zipCode', StringType(), True)]), True), StructField('age', StringType(), True), StructField('gender', StringType(), True), StructField('hasChildren', StringType(), True), StructField('hasCreditCard', StringType(), True), StructField('income', StringType(), True), StructField('maritalStatus', StringType(), True), StructField('numberOfChildren', StringType(), True), StructField('referenceKey', StringType(), True)]), True)])
    }
}

# COMMAND ----------

# extract variables from config
nbo_s3_path = config['nbo']['s3_path']
nbo_schemalocation = config['nbo']['schemalocation']
nbo_checkpointlocation = config['nbo']['checkpointlocation']
nbo_target_path = config['nbo']['target_path']
nbo_schema = config['nbo']['column_schema']
nbo_intermediate_table = config['nbo']['intermediate_table']
nbo_pii_columns = config['nbo']['pii_columns']
nbo_database_name = config['nbo']['database_name']
# assign the required variables
database_name = f"{env}_ainbo_gold"
nbo_src_tbl = f"{env}_silver.nbo_silver"
nbm_src_tbl = f"{env}_silver.users_data_silver"
non_nbm_src_tbl = f"{env}_silver.nosql_data_entity_silver"
view_name = "vw_campaign_ainbo_demographics"
view_nbm = "vw_nbo_nbm"
view_non_nbm = "vw_nbo_non_nbm"

# COMMAND ----------

ainbo_database_name = 'dev_ainbo_silver'
nbm_view = 'nbm_vw'
nbm_stage_view = 'nbm_stage_vw'
non_nbm_view = 'non_nbm_vw'
non_nbm_stage_view = 'non_nbm_stage_vw'
database_name = 'dev_ainbo_gold'
view_name = 'vw_campaign_ainbo_demographics'