# Databricks notebook source
# MAGIC %run ../config/config_nbo

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/aes

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run  ../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
current_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")
# d = timeinbankok - timedelta(days=1,hours=0, minutes=3)
# e = d.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

#calling read_stream method to read source data using autoloader
try:
    nbo_stream = read_stream(source_path = nbo_s3_path, checkpoint_location = nbo_schemalocation , file_format = "text")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# decrype the data using aes_decrypt
try:
    decrypt_df = nbo_stream.withColumn("value", aes_decrypt("value"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert column from string data type into struct type
try:
    struct_df = decrypt_df.withColumn("value", from_json("value",nbo_schema))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#flatten the json data
try:
    nbo_flatten_df = flatten_struct(struct_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# rename column
try:
    for cols in nbo_flatten_df.columns:
        nbo_flatten_df = nbo_flatten_df.withColumnRenamed(cols,cols.replace('value_',''))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all columns value in upper case
try:
    nbo_values_upper_df = columnsValue_to_upper_case(df = nbo_flatten_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# applying rule on below columns
try:
    customised_df = nbo_values_upper_df\
                          .withColumn("profile_age", when((col("profile_age") == "") | (col("profile_age").isNull()),0)\
                          .otherwise(col("profile_age")))\
                          .withColumn("profile_hasCreditCard", when((col("profile_hasCreditCard") == "") | (col("profile_hasCreditCard").isNull()) | (col("profile_hasCreditCard") == "FALSE"), 0)\
                          .when(col("profile_hasCreditCard")=="TRUE",1)\
                          .otherwise(col("profile_hasCreditCard")))\
                          .withColumn("profile_hasChildren", when((col("profile_hasChildren") == "") | (col("profile_hasChildren").isNull()) | (col("profile_hasChildren") == "FALSE"),0).when(col("profile_hasChildren") == "TRUE", 1)\
                          .otherwise(col("profile_hasChildren")))\
                          .withColumn("profile_numberOfChildren", when((col("profile_numberOfChildren") == "") | (col("profile_numberOfChildren").isNull()),0).otherwise(col("profile_numberOfChildren")))\
                          .withColumn("profile_address_district", when((col("profile_address_district") == "") | (col("profile_address_district").isNull()),lit(None)).otherwise(col("profile_address_district")))\
                          .withColumn("profile_address_province", when((col("profile_address_province") == "") | (col("profile_address_province").isNull()),lit(None)).otherwise(col("profile_address_province")))\
                           .withColumn("profile_maritalStatus", when((col("profile_maritalStatus") == "") | (col("profile_address_province").isNull()),lit(None)).otherwise(col("profile_maritalStatus")))\
                           .withColumn("profile_income", when((col("profile_income") == "") | (col("profile_income").isNull()),lit(None)).otherwise(col("profile_income")))\
                            .withColumn("profile_gender", when((col("profile_gender") == "") | (col("profile_gender").isNull()),lit(None)).when(col("profile_gender") == "MALE", "M").when(col("profile_gender") == "FEMALE", "F").otherwise(col("profile_gender")))
                          
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#calling encrypt_column method to encrypt the columns
try:
    nbo_encrypted_df = encrypt_column(df = customised_df, columns = nbo_pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#append column udh_batch_id for partition and drop row if found all coulmns null
try:
    nbo_partition_df = nbo_encrypted_df\
                       .withColumn("udh_batch_id",lit(curr_date))\
                       .dropna(how="all")\
                       .withColumn("udh_insert_timestamp",lit(current_time).cast(TimestampType()))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert columns name in upper case
try:
    nbo_fields_upper_df = columnsNames_to_upper_case(nbo_partition_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write data into external delta table usin write_stream_delta_table common utility
try:
    table = nbo_database_name + "." + nbo_intermediate_table
    write_stream_delta_table(df = nbo_fields_upper_df, table_name = table , checkPointLocation = nbo_checkpointlocation,
                             externalTablePath = nbo_target_path, partitionColumn=["UDH_BATCH_ID"], outputMode="append")
except Exception as e:
    raise Exception(e)