# Databricks notebook source

df=spark.read.json('/mnt/dev/fwd_landing/bronze/ga4/TH.DEV.GBQ.GA4.GOOGLE_ANALYTICS')



# COMMAND ----------

df.createOrReplaceTempView('google_analytics_test')

# COMMAND ----------

# MAGIC %sql
# MAGIC desc google_analytics_test

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from google_analytics_test 
# MAGIC where event_date between '20220912' and '20230430' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from google_analytics_test where event_date=20230105 limit 10
# MAGIC -- and event_timestamp= 1672891284785286 and event_name='view_item' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from google_analytics_test where event_date = '20230511'

# COMMAND ----------

# MAGIC %sql
# MAGIC select event_date, count(*) from google_analytics_test group by event_date

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from google_analytics_test where event_date='20230511' and event_timestamp= 1683815601022549 and event_name='page_view'
# MAGIC and year='2023' and month='05' and day='11'