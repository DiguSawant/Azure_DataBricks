-- Databricks notebook source

select count(distinct JSONVALUE_ID) FROM dev_silver.lead_silver WHERE JSONVALUE_STATUS='A'

-- COMMAND ----------

select count(distinct JSONVALUE_ID) FROM dev_cube_silver.leads_mvp_silver

-- COMMAND ----------

select level,sum(count) from  dev_cube_gold.vw_cube_fna_mvp group by LEVEL --having level='NO_OF_LEADS'

-- COMMAND ----------

-- 2 no of agents
SELECT COUNT(DISTINCT JSONVALUE_AGENTCODE ) FROM  dev_silver.lead_silver 

-- COMMAND ----------

select date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')as CREATED_TIME, CASE 
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND (EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 7 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 12  )    THEN "AGENT_MORNING"
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND  (EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 11 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 19  )  THEN "AGENT_AFTERNOON"
WHEN(EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) >= 0  OR  EXTRACT(MINUTES FROM JSONVALUE_CREATEDTIME ) < 60 ) AND 
(EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME )  > 19 AND EXTRACT(HOURS FROM JSONVALUE_CREATEDTIME ) < 23  ) THEN "AGENT_EVENING"
ELSE "AGENT_NIGHT"
END AS LEVEL,count(DISTINCT JSONVALUE_AGENTCODE)
from dev_silver.iris_lead_cube_fna_silver where  date_format(to_date(jsonValue_createdTime),'dd/MM/yyyy')='02/03/2023' and JSONVALUE_AGENTCODE is not null group by CREATED_TIME,LEVEL



-- COMMAND ----------

Select created_time, LEVEL, count(DISTINCT JSONVALUE_AGENTCODE) from dev_cube_silver.agent_mvp_silver group by CREATED_TIME, LEVEL having CREATED_TIME='02/03/2023'

-- COMMAND ----------

select CREATED_TIME, level, sum(count) from dev_cube_gold.vw_cube_fna_mvp group by LEVEL,CREATED_TIME having level='TOTAL_AGENTS'

-- COMMAND ----------

select *  from dev_cube_gold.vw_cube_fna_mvp where CREATED_TIME='02/03/2023'

-- COMMAND ----------



-- COMMAND ----------

--select CREATED_TIME, level, sum(count) from  dev_cube_gold.vw_cube_fna_mvp group by LEVEL,CREATED_TIME having level='TOTAL_AGENTS'
select * from  dev_cube_gold.vw_cube_fna_mvp limit 10

-- COMMAND ----------

-- 3 no of lead submitted
select count(distinct JSONVALUE_LEADSTATUSCODE) from dev_silver.lead_silver where JSONVALUE_LEADSTATUSCODE='S'

-- COMMAND ----------

desc 

-- COMMAND ----------

select  count(distinct JSONVALUE_LEADSTATUSCODE) from dev_cube_silver.leads_mvp_silver where JSONVALUE_LEADSTATUSCODE='S'

-- COMMAND ----------

select level,sum(count) from  dev_cube_gold.vw_cube_fna_mvp group by LEVEL


-- COMMAND ----------

-- 4 age verifcaition -- age=2
select * from dev_silver.lead_silver where JSONVALUE_ID=10257



-- COMMAND ----------

 SELECT * FROM  dev_cube_silver.leads_mvp_silver 

-- COMMAND ----------

-- count of prodcutinteresttype code for wealth
select count(*) FROM dev_silver.iris_lead_cube_fna_silver where JSONVALUE_LEADSTATUSCODE='S' and JSONVALUE_PRODUCTINTERESTEDTYPECODE='PA'

-- COMMAND ----------

select COUNT(*) from dev_cube_silver.products_mvp_silver where JSONVALUE_LEADSTATUSCODE='S' and JSONVALUE_PRODUCTINTERESTEDTYPECODE='PA'

-- COMMAND ----------

select level,sum(count) from  dev_cube_gold.vw_cube_fna_mvp group by LEVEL

-- COMMAND ----------

select count(*) from 