# Databricks notebook source
# MAGIC %run /Shared/udh_dom/tech_utility/aes

# COMMAND ----------

# MAGIC %sql 
# MAGIC --raw encrytped data for the path field
# MAGIC select aes_decrypt('gKguXeMPR9H+4+DJytCF+g==')

# COMMAND ----------

# MAGIC %sql
# MAGIC --raw file encrypted data
# MAGIC select aes_decrypt('xHIFPzXXGo9dBbRzZRr7Tw==')

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime as dt
dt.fromtimestamp(1613636211025/1000).strftime('%Y-%m-%d %H:%M:%S')

# COMMAND ----------

