-- Databricks notebook source
--select  * from dev_cube_silver.lead_agent_silver 
--where agent_rel_id='da4d2220-bf8f-4745-b4e7-3860fa690a71'

desc dev_cube_silver.lead_agent_silver 



-- COMMAND ----------

select * from dev_cube_silver.lead_info_silver limit 100

-- COMMAND ----------

select lead_id,source_lead_id,source_system,lead_type,lead_name_lang,lead_full_name,lead_first_name,lead_last_name,
title,lead_birth_date,lead_gender_code,address_country,address_city,address_postal_code,address_line_1,address_line_2,
address_line_3,lead_email_address,mobile_phone_country_code,mobile_phone_num,occupation,occupation_group,marital,is_smoke,number_of_kids,
lead_valid_status,inquire_reason,tsr,lead_score,etl_valid_start_time,etl_valid_end_time,etl_is_current_flag,etl_create_time,etl_create_by,
etl_update_time,etl_update_by,etl_source_system_record_time,etl_source_bu,etl_source_system,etl_source_table,__md5 from dev_cube_silver.lead_info_silver 
where lead_id='DH-1a9b2d19-5f7a-48b4-ba10-5fa7365dddcd'

-- COMMAND ----------

select * from dev_cube_silver.lead_status_silver
where lead_status_id='2323cc5b-272e-4f4d-8c58-f7e7f31644b4'
and update_date='2023-03-20T12:03:19.799Z'

--

-- COMMAND ----------

--select * from dev_cube_silver.lead_silver limit 100
--select * from dev_cube_silver.lead_silver where jsonValue_id=10257 and jsonValue_agentCode=105090
Desc dev_cube_silver.lead_silver


-- COMMAND ----------

select * from dev_silver.lead_silver where JSONVALUE_AGE=10257 and JSONVALUE_AGENTCODE=105090

-- COMMAND ----------

select * from dev_cube_silver.product_info_silver limit 100


-- COMMAND ----------

select * from dev_cube_silver.product_rec_silver limit 100
--WHERE lead_id='AI-40172066' and
--product_code='Endowment (Par)'

-- COMMAND ----------

DESC  dev_cube_silver.lead_agent_silver 

-- COMMAND ----------

desc dev_cube_silver.lead_status_silver

-- COMMAND ----------

desc dev_cube_silver.product_info_silver

-- COMMAND ----------

desc dev_cube_silver.product_rec_silver

-- COMMAND ----------

desc dev_cube_silver.lead_info_silver

-- COMMAND ----------

desc dev_silver.lead_status_silver

-- COMMAND ----------

desc dev_silver.lead_agent_silver

-- COMMAND ----------

Desc dev_silver.lead_info_silver

-- COMMAND ----------

desc dev_silver.product_info_silver

-- COMMAND ----------

desc dev_silver.product_rec_silver

-- COMMAND ----------

Desc dev_silver.lead_silver

-- COMMAND ----------

select * from dev_silver.lead_status_silver limit 100

-- COMMAND ----------

select COUNT(AGENT_CODE),case(when ) FROM dev_silver.lead_agent_silver 

-- COMMAND ----------

select * from  dev_silver.product_info_silver limit 100

-- COMMAND ----------

select * from dev_silver.product_rec_silver limit 100

-- COMMAND ----------

select * from dev_silver.lead_silver limit 100

-- COMMAND ----------

select distinct JSONVALUE_PRODUCTINTERESTEDTYPECODE from dev_silver.lead_silver

-- COMMAND ----------

select count(JSONVALUE_ID) FROM dev_silver.lead_silver WHERE JSONVALUE_STATUS='A'

-- COMMAND ----------

select GOVERNMENT_ID_NUM,LEAD_BIRTH_DATE,LEAD_EMAIL_ADDRESS,LEAD_FIRST_NAME,LEAD_FULL_NAME,
LEAD_LAST_NAME,	LEAD_MIDDLE_NAME,MOBILE_PHONE_NUM from dev_silver.lead_info_silver limit 100

-- COMMAND ----------

select GOVERNMENT_ID_NUM,LEAD_BIRTH_DATE,LEAD_EMAIL_ADDRESS,LEAD_FIRST_NAME,LEAD_FULL_NAME,
LEAD_LAST_NAME,	LEAD_MIDDLE_NAME,MOBILE_PHONE_NUM from dev_silver.lead_info_silver where LEAD_ID='DH-0BF6EB0F-3902-45D0-B727-4C3D8643233A'

-- COMMAND ----------

select JSONVALUE_AGE,JSONVALUE_NAME_EN,JSONVALUE_MOBILENUMBER,JSONVALUE_PHONEMOBILE,JSONVALUE_EMAILADDRESS,
	JSONVALUE_BIRTHDATE from dev_silver.lead_silver limit 100

-- COMMAND ----------

select JSONVALUE_AGE,JSONVALUE_NAME_EN,JSONVALUE_MOBILENUMBER,JSONVALUE_PHONEMOBILE,JSONVALUE_EMAILADDRESS,
	JSONVALUE_BIRTHDATE from dev_silver.lead_silver where JSONVALUE_ID=10257 and JSONVALUE_AGENTCODE=105090

-- COMMAND ----------

select distinct