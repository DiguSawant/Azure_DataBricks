# Databricks notebook source
# DBTITLE 1,import the python package we need
# from confluent_kafka.schema_registry import SchemaRegistryClient
from pyspark.sql.types import IntegerType,StringType,StructType,StructField,DoubleType,TimestampType,ArrayType,BooleanType
from struct import pack, unpack
import ssl
import boto3
import base64
import json
from botocore.exceptions import ClientError

# COMMAND ----------

# import os
# env = os.getenv("env").lower()
# if env == 'dev':
#     sec_key = "confluent-cloud-saslssl-devcapem-location"
# else:
#     sec_key = "confluent-cloud-saslssl-capem-location"
    

# COMMAND ----------

# DBTITLE 1,Use the dbutils module to get the secret 
aws_access_keyid = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-access-key-id")
aws_secret_access_key = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-secret-access-key")
aws_rolearn = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-rolearn")
kafka_bootstrap_servers = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-bootstrap-servers-url")
kafka_ca_path = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-saslssl-capem-location")
schemaRegistryURL = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-schemaregistry-url")
secretname = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-secretmanager-secretname")

# COMMAND ----------

# DBTITLE 1,Connect to the Schema Registry, define the topic that we need and define the function to get the relative topic's schema and schema id
# import json
# try:
#     schema_registry_conf = {
#         'url':f'{schemaRegistryURL}',
#         'ssl.ca.location':f'{kafka_ca_path}'
#     }
# except Exception as e:
#     raise e
    
# schema_registry_client = SchemaRegistryClient(schema_registry_conf)

# #define the function to get relative topic's schema and schema_id
# def get_key_schema(topic_name):
#     try:
#         schema_key = schema_registry_client.get_latest_version(f"{topic_name}-key")
#     except Exception as e:
#         raise e
#     schema=schema_key.schema.schema_str
#     schema_id=schema_key.schema_id
#     return (schema,schema_id)

# def get_value_schema(topic_name):
#     try:
#         schema_value = schema_registry_client.get_latest_version(f"{topic_name}-value")
#     except Exception as e:
#         raise e
#     schema=schema_value.schema.schema_str
#     schema_id=schema_value.schema_id
#     return (schema,schema_id)
# # schemakey_en = json.loads(get_value_schema('TH.UAT.ODS.LIFEPLAN.public.Entity')[0])

# COMMAND ----------

####create a connection for aws secret manage service
def get_secret(input_secret_name):
    secret_name = input_secret_name ####secert name
    region_name = "ap-southeast-1"
    # Create a Secrets Manager client
    #session = boto3.session.Session()
    client = boto3.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS key.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return secret  

# COMMAND ----------

# DBTITLE 1,Retrieve the secret from secret manger by using personal AccessKeyId and SecretKeyId of AWS to connect the secret manger
###use some account's credenctial first

aws_some_iamaccount = {
    'aws_access_key_id':aws_access_keyid,
    'aws_secret_access_key':aws_secret_access_key   
}
### get ENV token which the role will be switched to 

sts=boto3.client('sts', **aws_some_iamaccount)
stsresponse = sts.assume_role(
    RoleArn=aws_rolearn, 
    RoleSessionName='assumed'
)
aws_credentials_assumed_role = {
    'region_name':'ap-southeast-1',
    'aws_access_key_id':stsresponse["Credentials"]["AccessKeyId"],
    'aws_secret_access_key':stsresponse["Credentials"]["SecretAccessKey"],
    'aws_session_token':stsresponse["Credentials"]["SessionToken"]
}
###configure the token before calling aws'product api
boto3.setup_default_session(**aws_credentials_assumed_role)


secret=json.loads(get_secret(secretname)) ###return dict type
api_key=secret['kafka_api_key']
api_secret=secret['kafka_api_secret']
thssot_confluent_aes_key = secret['kafka_aes_key']
