# Databricks notebook source
# DBTITLE 1,running secret_key_env_param_blz notebook
# MAGIC %run ./secret_key_env_param

# COMMAND ----------

# MAGIC %md ### AES Function

# COMMAND ----------

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad,unpad
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType,DoubleType
from pyspark.sql import SparkSession
import base64 as b64

class Aes_ECB(object):
    def __init__(self,key):
        self.key = key
        self.MODE = AES.MODE_ECB
        self.BS = 16


    def add_to_16(value):
        while len(value) % 16 != 0:
            value += "\0"
        return str.encode(value)


    def AES_encrypt(self, text):
      if(text is not None and text != 'null' and text.strip() != ''):
        aes = AES.new(Aes_ECB.add_to_16(self.key), self.MODE)
        encrypted_text = str(b64.encodebytes(aes.encrypt(pad(text.strip().encode(),self.BS,style="pkcs7"))), encoding="utf-8").replace("\n", "")
        return encrypted_text
      else:
        return text


    def AES_decrypt(self, text):
      if(text is not None and text != 'null' and text.strip() != ''):
        base64_decrypted = b64.b64decode(text.encode("utf-8"))  # decodebytes
        aes = AES.new(Aes_ECB.add_to_16(self.key), self.MODE)
        decrypted_text = unpad(aes.decrypt(base64_decrypted),self.BS,style="pkcs7")
        decrypted_code = decrypted_text
        return decrypted_code.decode("utf-8")
      else:
        return text

      
# aes_key = thssot_confluent_aes_key  #dbutils.secrets.get(scope = "kv_gdp_eas_fwdapp_01_scopename", key = "ID-CDP-encryption-aes-key")
aes_key = thssot_confluent_aes_key  
Customer  =  Aes_ECB(aes_key)

# using by SQL or DSL
spark.udf.register('aes_decrypt', Customer.AES_decrypt, StringType())
spark.udf.register('aes_encrypt', Customer.AES_encrypt, StringType())

# using by pyspark
aes_decrypt = udf(Customer.AES_decrypt,StringType())
aes_encrypt = udf(Customer.AES_encrypt,StringType())