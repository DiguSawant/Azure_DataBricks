# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime as dt, timedelta
from datetime import datetime 

# COMMAND ----------

# DBTITLE 1,Spark function for reading json file
"""
    Purpose : read json files using pyspark
    Input : location, multiline, allowUnquotedFieldNames, allowSingleQuotes, dropFieldIfAllNull
    Output : spark dataframe
"""

def read_json(location, multiline=True, allowUnquotedFieldNames=False,
                   allowSingleQuotes=True, dropFieldIfAllNull=False):
    #validate the input parameters
    if location is None or location == "":
        raise Exception("file location is required")
    if multiline is None or multiline == "" or type(multiline) not in (str, bool):
        raise Exception("multiline can not be empty or none, must be type of boolean(True/False)")
    if allowUnquotedFieldNames is None or allowUnquotedFieldNames == "" or type(allowUnquotedFieldNames) not in (
            str, bool):
        raise Exception("allowUnquotedFieldNames can not be empty or none, must be type of boolean(True/False)")
    if allowSingleQuotes is None or allowSingleQuotes == "" or type(allowSingleQuotes) not in (str, bool):
        raise Exception("allowSingleQuotes can not be empty or none, must be type of boolean(True/False)")
    if dropFieldIfAllNull is None or dropFieldIfAllNull == "" or type(dropFieldIfAllNull) not in (str, bool):
        raise Exception("dropFieldIfAllNull can not be empty or none, must be type of boolean(True/False)")
    else:
        #call the spark reader property for reading json
        FORMAT = spark.read.format("json")
        #creating options as dictionary for reading json
        OPTIONS = {"multiline": multiline, "allowUnquotedFieldNames": allowUnquotedFieldNames,
                   "allowSingleQuotes": allowSingleQuotes, "dropFieldIfAllNull": dropFieldIfAllNull}
        try:
            df = FORMAT.options(**OPTIONS).load(location)
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : read data as spark stream
    Input  : source_path, checkpoint_location, file_format
    Output : spark dataframe
"""
def read_stream(source_path, checkpoint_location, file_format):
    if source_path is None or source_path == "":
        raise Exception("source_path can not be empty")
    if checkpoint_location is None or checkpoint_location == "":
        raise Exception("checkpoint_location can not be empty")
    if file_format is None or file_format == "":
        raise Exception("file_format can not be empty")
    else:
        try:
            read_stream = spark.readStream.format("cloudFiles")\
                               .option("cloudFiles.format", file_format)\
                               .option("inferSchema", "true")\
                               .option("cloudFiles.schemaLocation",checkpoint_location)\
                               .load(source_path)
            return read_stream
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : read data as spark stream
    Input  : source_path, checkpoint_location, file_format
    Output : spark dataframe
"""
def read_stream_with_schema(source_path, checkpoint_location, file_format, schema=None):
    if source_path is None or source_path == "":
        raise Exception("source_path can not be empty")
    if checkpoint_location is None or checkpoint_location == "":
        raise Exception("checkpoint_location can not be empty")
    if file_format is None or file_format == "":
        raise Exception("file_format can not be empty")
    else:
        try:
            read_stream = spark.readStream.format("cloudFiles")\
                               .option("cloudFiles.format", file_format)\
                                .schema(schema)\
                               .option("inferSchema", False)\
                               .option("cloudFiles.schemaLocation",checkpoint_location)\
                               .load(source_path)
            return read_stream
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : write data as spark stream
    Input  : df,file_format, mode, checkpoint_location, path, partitioncolumn
    Output :
"""
def write_stream(df,file_format, mode, checkpoint_location, path, partitioncolumn=None):
    if df is None or df == "":
        raise Exception("df can not be empty")
    if file_format is None or file_format == "":
        raise Exception("file_format can not be empty")
    if mode is None or mode == "":
        raise Exception("mode can not be empty")
    if checkpoint_location is None or checkpoint_location == "":
        raise Exception("checkpoint_location can not be empty")
    if path is None or path == "":
        raise Exception("path can not be empty")
    if partitioncolumn == "":
        raise Exception("partitioncolumn can not be empty")
    else:
        try:
            if partitioncolumn is None:
                df.writeStream.format(file_format)\
                  .outputMode(mode)\
                  .option("checkpointLocation",checkpoint_location)\
                  .trigger(processingTime='1 minutes')\
                  .start(path)
            else:
                df.writeStream.format(file_format)\
                  .outputMode(mode)\
                  .option("checkpointLocation",checkpoint_location)\
                  .partitionBy(*partitioncolumn)\
                  .start(path)
        except Exception as e:
            raise Exception(e)
#.trigger(processingTime='1 minutes')\

# COMMAND ----------

"""
    Purpose : write data into delta table using pyspark
    Input  : spark dataframe, table, externalTablePath, partitionColumn, mode, overwriteSchema
    Output : spark dataframe
"""
def write_stream_delta_table(df, table_name, checkPointLocation, externalTablePath=None, partitionColumn=None, outputMode="append"):
    #validate the input parameters
    if df is None or df == "":
        raise Exception("input parameter df can not be empty or none")
    if table_name is None or table_name == "":
        raise Exception("parameter table_name can not be empty or none")
    if checkPointLocation is None or checkPointLocation == "":
        raise Exception("checkPointLocation can not be empty or none")
    if externalTablePath == "":
        raise Exception("externalTablePath can not be empty, must be type of string")
    if outputMode is None or outputMode == "" or type(outputMode)!= str:
        raise Exception("parameter outputMode can not be empty or none, must be type of string")
    if partitionColumn == "":
        raise Exception("parameter partitionColumn can not be empty")
    else:
        if externalTablePath is not None:
            OPTIONS = {"path":externalTablePath,"checkpointLocation":checkPointLocation }
        else:
            OPTIONS = {"checkpointLocation":checkPointLocation}
        try:
            if partitionColumn is not None:
                df.writeStream.format("delta")\
                        .outputMode(outputMode)\
                        .options(**OPTIONS)\
                        .partitionBy(partitionColumn)\
                        .toTable(table_name)                
            else:
                df.writeStream.format("delta")\
                        .outputMode(outputMode)\
                        .options(**OPTIONS)\
                        .toTable(table_name)                
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : read data from delta using pyspark
    Input : location and table
    Output : spark dataframe
"""

def read_delta(location = None, table = None):
    #validate the input parameters
    if location is None and table is None:
        raise("Table or location is not given")
    if table is None:
        delta_df=spark.read.format("delta").load(location)
    else:
        delta_df = spark.read.table(table_name)
    return delta_df

# COMMAND ----------

"""
    Purpose : column standarization for appending columns with dataframe
    Input  : df,columns
    Output :spark dataframe
"""
def col_standarization(df,columns):
    #validate the input parameters
    if df is None or df == "":
        raise Exception("df can not be empty")
    if columns is None or columns == "":
        raise Exception("columns can not be empty")
    else:
        try:
            for key in columns:
                df = df.withColumn(key,expr(columns[key]))
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : encrypt given columns
    Input  : df,columns
    Output :spark dataframe
"""
def encrypt_column(df,columns):
    if df is None or df == "":
        raise Exception("df can not be empty")
    if columns is None or columns == "":
        raise Exception("columns can not be empty")
    else:
        try:
            for i in columns:
                df = df.withColumn(i, aes_encrypt(col(i)))
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : to insert and update table configurations in the config table
    Input : config table name,tablename and config
    Output : insert and update config table
"""
def config_upsert(config_table, config_name, config):
    if config_table is None or config_table == "":
        raise Exception("config_table can not be empty")
    if config_name is None or config_name == "":
        raise Exception("config_name can not be empty")
    if config is None or config == "":
        raise Exception("config can not be empty")
    else:
        try:
            config = str(config).replace("'",'"')
            table_check = spark.sql(f""" select count(*) from {config_table} where config_name = "{config_name}" """)
            previous_record_count=table_check.collect()[0][0]

            if previous_record_count > 0:

                previous_created_date = spark.sql(f""" select min(created_at) from {config_table} where config_name = "{config_name}" """).collect()[0][0]

                spark.sql(f""" insert into {config_table} (config_name ,config ,created_at ,updated_at ,status) values("{config_name}",'{config}',"{previous_created_date}",current_timestamp(),'active')
             """) 

                max_updated_at = spark.sql(f"""select max(updated_at) from {config_table} where config_name = "{config_name}" """).collect()[0][0]
                print(max_updated_at)
                spark.sql(f"""update {config_table} set status ="inactive" where config_name="{config_name}" and  updated_at < "{max_updated_at}"  """)

            else:

                   spark.sql(f""" insert into {config_table} (config_name ,config ,created_at ,updated_at ,status) values("{config_name}",'{config}',current_timestamp(),current_timestamp(),"active")
             """) 
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : to extract config into json format from config table
    Input : config table name,config_name
    Output : json config
"""
def config_extractor(config_table,config_name):
    if config_table is None or config_table == "":
        raise Exception("config_table can not be empty")
    if config_name is None or config_name == "":
        raise Exception("config_name can not be empty")
    else:
        try:
          #select config for given config_name having status active
            df = spark.sql(f"""select config from {config_table} where config_name ="{config_name}" and status = "active" """)
            config = df.collect()[0][0]
            config=config.replace("$","'")
            config = eval(config)
            return config
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : to convert string schema to spark schema
    Input : string schema
    Output : spark schema
"""
def schema_converter(string_schema):
    if string_schema is None or string_schema == "":
        raise Exception("string_schema can not be empty")
    else:
        try:
            sparkschema=[]
            exec(f"""sparkschema.append({string_schema})""")
            return sparkschema[0]
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

def process_part(table_name):
    date_df = spark.sql(f"select max(processed_date) from control_table where table_name = '{table_name}' and status = 'success'")
    process_date = date_df.collect()[0][0]
    if process_date:
        part_df = spark.sql(f"select max(processed_part) from control_table where table_name = '{table_name}' and processed_date = {process_date} and status = 'success'")
        process_part = part_df.collect()[0][0]
        print(process_part)
        if process_part:
            process_part = process_part + 1
            if process_part == 24:
                process_date = int((datetime.strftime(str(process_date),'%Y%m%d')+timedelta(days = 1)).strftime('%Y%m%d'))
                process_part = 0
    return process_date,process_part

# COMMAND ----------

# import datetime
# """
#     Purpose : convert epoch time to expected format
#     Input : column of epoc_time
#     Output : datetime
# """
# def epoch_to_date(epoc_time):
#     if len(str(epoc_time)) == 10:
#         #     if epoch time is in seconds
#         return datetime.datetime.fromtimestamp(epoc_time).strftime('%Y-%m-%d %H:%M:%S')
#     if len(str(epoc_time)) == 13:
#         #     if epoch time is in miliseconds
#         return datetime.datetime.fromtimestamp(epoc_time/1000).strftime('%Y-%m-%d %H:%M:%S')
#     if len(str(epoc_time)) == 16:
#         #     if epoch time is in microseconds
#         return datetime.datetime.fromtimestamp(epoc_time/1000000).strftime('%Y-%m-%d %H:%M:%S')
#     if len(str(epoc_time)) == 19:
#         #     if epoch time is in nanoseconds
#         return datetime.datetime.fromtimestamp(epoc_time/1000000000).strftime('%Y-%m-%d %H:%M:%S')

# # register epoch_to_date as pyspark udf
# udf_epoch_to_date = udf(epoch_to_date, StringType()) 

# COMMAND ----------

"""
    Purpose : convert columns in upper case
    Input : spark dataframe
    Output : spark dataframe
"""
def columnsNames_to_upper_case(df):
    try:
        df = df.toDF(*[col.upper() for col in df.columns])
        return df
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

"""
    Purpose : convert columns value in upper case
    Input : spark dataframe
    Output : spark dataframe
"""
def columnsValue_to_upper_case(df,exclude_columns=[]):
    try:
        for i in df.dtypes:
            if(i[0] in exclude_columns):
                continue
            if (i[1] in ('int','long','bigint','float','boolean','timestamp','double','struct')):
                continue
            if(i[1]=='string' and len(i[0])>0):
                df = df.withColumn(i[0],upper(df[i[0]]))
            elif(i[1]=='array'):
                df = df.withColumn(i[0],transform(col(i[0]),lambda x: upper(x)))
            elif(i[1]=='struct'):
                df = df.withColumn(i[0],struct(*[upper(col(c)).alias(c) for c in i[0].schema.names]))
        return df
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

"""
    Purpose : convert columns data type into integer type
    Input : spark dataframe and colums
    Output : spark dataframe
"""
def convert_to_integer(df,columns:[]):
    try:
        for cols in df.dtypes:
            if cols[0] in columns:
                df = df.withColumn(cols[0],col(cols[0]).cast(IntegerType()))
        return df
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

"""
    Purpose : convert string to json
    Input : spark dataframe, columns, schema
    Output : spark dataframe
"""
def string_to_json_column(df,column,schema):
    df = df.withColumn(f'{column}',from_json(f'{column}',schema))
    return df

# COMMAND ----------

"""
    Purpose : calculate max timestamp
    Input : database, table, source_system, curr_time
    Output : where_condition
"""
# calculate max timestamp to get the latest data
def max_condition(database, table, source_system, curr_time):
    max_time = spark.sql(f"select cast(max(udh_insert_timestamp) as string) from {database_name}.{table} where source_system = '{source_system}'").collect()[0][0]

    if max_time!='' and max_time!=None:
        where_cond = f"udh_insert_timestamp>'{max_time}' and udh_insert_timestamp<'{curr_time}'"
    else:
        where_cond = f"udh_insert_timestamp<'{curr_time}'"
    return where_cond

# COMMAND ----------

"""
    Purpose : read table from mysql
    Input : host,port,database_name,user_id,password,numPartitions,partitionColumn,query,table,lowerBound,upperBound
    Output : spark dataframe
"""
def read_from_MSSQL(host,port,database_name,user_id,password,numPartitions=None,partitionColumn=None,query=None,table=None,lowerBound=None,upperBound=None):
            if table is None:
                        df = spark.read.format("jdbc")\
                        .option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver")\
                        .option("url", f"jdbc:sqlserver://{host}:{port};databaseName={database_name}")\
                        .option("query", query)\
                        .option("user", user_id)\
                        .option("password", password)\
                        .load()
            else:
                df = spark.read \
                        .format("jdbc") \
                        .option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver")\
                        .option("url", f"jdbc:sqlserver://{host}:{port};databaseName={database_name};") \
                        .option("numPartitions", numPartitions)\
                        .option("partitionColumn", partitionColumn)\
                        .option("lowerBound", lowerBound)\
                        .option("upperBound", upperBound)\
                        .option("dbtable", table) \
                        .option("user", user_id) \
                        .option("password", password) \
                        .load()
            return df
                

# COMMAND ----------

"""
    Purpose : decrypt the spark dataframe encrypted columns
    Input : pyspark dataframe, column
    output : pyspark dataframe
"""
def decrypt_columns(df,columns):
    for column in columns:
        df=df.withColumn(f"{column}+'es'",aes_decrypt(column))
    return df

# COMMAND ----------


"""
    Purpose : read data as csv format from given location
    Input : location, sep, header, infer_schema, schema, mode
    output : pyspark dataframe
"""
def read_csv(location , sep=",", header=True, infer_schema=True, schema=None, mode="PERMISSIVE"):
    if location is None or location == "":
        raise Exception("location can not be empty")
    if sep is None or sep == "":
        raise Exception("sep can not be empty")
    if header == "" or type(header) not in (str,bool):
        raise Exception("header can not be empty")
    if infer_schema == "" or type(infer_schema) not in (str,bool):
        raise Exception("inferSchema can not be empty")
    if schema == "":
        raise Exception("schema can not be empty")
    if mode is None or mode == "":
        raise Exception("mode can not be empty")
    else:
        FORMAT = spark.read.format("csv")
        OPTIONS = {"header":header, "sep":sep, "inferSchema":infer_schema, "mode":mode}
        try:
            if schema is not None:
                OPTIONS["infer_schema"] = False
                df = FORMAT.options(**OPTIONS).schema(schema).load(location)
            else:
                df = FORMAT.options(**OPTIONS).load(location)
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : replacing all spaces, dot(.), hyphen(-) from column name
    Input : pyspark dataframe
    output : pyspark dataframe
"""
def normalize_column_name(df):
#     validate the arguments
    if df is None or df == "":
        raise Exception("df can not be empty")
    else:
        try:
#             replace the dot, space and hyphen from the columns and renamed column with underscore(_)
            for column in df.columns:
                renamedColumn = column.strip().replace(' ','_').replace('-','_').replace('.','_').replace('/','_').rstrip('_')
                df = df.withColumnRenamed(column, renamedColumn)
            return df
        except Exception as e:
            raise Exception(e)
        

# COMMAND ----------

"""
    Purpose : trim the column value of spark dataframe 
    Input : spark dataframe
    output : spark dataframe
"""
def trim_fields(df):
#     validate the argument
    if df is None or df == "":
        raise Exception("df can not be empty")
    else:
        try:
            for cols in df.columns:
#                 trim the all fields of dataframe using trim() function
                df = df.withColumn(cols,trim(cols))
                return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : calculate age on basis of birth date 
    Input : spark dataframe,column,date_format
    output : spark dataframe
"""
def age_calculation(df,column,date_format):
#     validate the arguments
    if df is None or df == "":
        raise Exception("df can not be empty")
    if column is None or column == "":
        raise Exception("column can not be empty")
    else:
        try:
#             convert the column(birth_column) from string to timestamp format
            df = df.withColumn("dob",from_unixtime(unix_timestamp(df[column],date_format)))
#             calculate the age by subtracting the birth year from the current year
            df = df.withColumn("age",year(current_date())-year(df["dob"]))
#             if the current year is before the birth year, subtract 1 from the age
            df = df.withColumn("age",when(month(current_date()) < month(df["dob"]),df["age"]-1).when((month(current_date())==month(df["dob"])) & (dayofmonth(current_date()) < dayofmonth(df["dob"])),df["age"]-1).otherwise(df["age"])).drop("dob")
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : calculate day on basis of given date 
    Input : date column
    output : day
"""
def python_day_calculation(date_col):
#     validate the arguments
    if date_col is None or date_col == "":
        raise Exception("date_col can not be empty")
    else:
        try:
#             convert date string o datetime object
            date_obj = datetime.strptime(date_col,'%m/%d/%y').date()
#             calculate the number of days between the current date and the date object
            day = (datetime.now().date()-date_obj).days
            return day
        except Exception as e:
            raise Exception(e)

# register python_day_calculation as pyspark udf
udf_day_calculation = udf(python_day_calculation, StringType())

# COMMAND ----------

"""
    Purpose : data quality function to check phone number
    Input : column_name, mobilecode_list_str
    output : boolean as True or False
"""
def python_check_phone_number(column_name, mobilecode_list_str):
    try:
        # removing "-" from the phone number  to validate it is digit  
        number = str(column_name).strip().replace("-","")
        mobilecode_list_str = mobilecode_list_str.replace('[',"").replace(']',"").replace("'","").replace(" ","").split(",")
        if number.isdigit() :
            if len(number) == 10 and number[0:3] in mobilecode_list_str :
                return True
            else:
                return False
    except Exception as e:
        raise Exception(e)
        
# register python_day_calculation as pyspark udf
udf_check_phone_number = udf(python_check_phone_number, BooleanType())

# COMMAND ----------

import datetime
"""
    Purpose : convert epoch timestamp into date format YYYY-mm-dd
    Input : epoch time
    output : date
"""
def epoch_to_date(epoc_time):
    if len(str(epoc_time)) == 10:
        #     if epoch time is in seconds
        return datetime.datetime.fromtimestamp(epoc_time).strftime('%Y-%m-%d')
    if len(str(epoc_time)) == 13:
        #     if epoch time is in miliseconds
        return datetime.datetime.fromtimestamp(epoc_time/1000).strftime('%Y-%m-%d')
    if len(str(epoc_time)) == 16:
        #     if epoch time is in microseconds
        return datetime.datetime.fromtimestamp(epoc_time/1000000).strftime('%Y-%m-%d')
    if len(str(epoc_time)) == 19:
        #     if epoch time is in nanoseconds
        return datetime.datetime.fromtimestamp(epoc_time/1000000000).strftime('%Y-%m-%d')

# register epoch_to_date as pyspark udf
udf_epoch_to_date = udf(epoch_to_date, StringType())    

# COMMAND ----------

import re
"""
    Purpose : extract date from file path
    Input  : date
    Output :date_str
"""

date_pattern = r'\d{4}\d{2}-\d{2}|\d{8}'
date_pattern_1 = r'\d{4}/\d{2}/\d{2}|\d{8}'
date_pattern_2 = r'\b\d{1,2}[a-zA-Z]{3}\d{4}\b'
date_pattern_3 = r'\d{4}-\d{2}|\d{6}'
def extract_date(path):
    date_match = re.search(date_pattern, path)
    date_match_1 = re.search(date_pattern_1, path)
    date_match_2 = re.search(date_pattern_2, path)
    date_match_3 = re.search(date_pattern_3, path)
    if date_match:
        date_str = date_match.group(0).replace('-','')
        return date_str
    elif date_match_1:
        date_str = date_match_1.group(0).replace('/','')
        return date_str
    elif date_match_2:
        match = date_match_2.group()
        date_obj = datetime.strptime(match, '%d%b%Y')
        date_str = date_obj.strftime('%Y%m%d')
        return date_str
    elif date_match_3:
        date_str = date_match_3.group(0)
        return date_str
    else:
        return None
    
    
udf_extract_date = udf(extract_date, StringType())

# COMMAND ----------

"""
    Purpose : change column name based on given dictionary mapping
    Input : spark dataframe, new column name followed by existing column name in dictionary
    Output : spark dataframe
"""
def rename_column(df, column_dict):
    if df is None or df == "":
        raise Exception("input parameter df can not be empty or none")
    if column_dict is None or column_dict == "":
        raise Exception("column_dict can not be empty or none")
    if not isinstance(column_dict, dict):
        raise Exception("column_dict must be type of dictionary")
    else:
        try:
            for item in column_dict.items():
                if item[0] in df.columns:
                    existing_column = item[0]
                    new_column = item[1]
                    df = df.withColumnRenamed(existing_column, new_column)
                else:
                    raise Exception(f"column {item[0]} are not present in spark dataframe")
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : write data to given path
    Input : spark dataframe, file_format, location, mode, overwriteSchema, partitionColumn,
    Output :
"""
def write_to_path(df, file_format, location, mode="append", overwriteSchema=True, partitionColumn=None):
    if df is None or df == "":
        raise Exception("input parameter df can not be empty or none")
    if file_format is None or file_format == "":
        raise Exception("file_format can not be empty or none")
    if location is None or location == "":
        raise Exception("location can not be empty or none")
    if mode == "" or mode is None:
        raise Exception("mode can not be empty")
    if overwriteSchema == "" or type(overwriteSchema) != bool:
        raise Exception("overwriteSchema must be type of bool")
    if partitionColumn == "":
        raise Exception("partitionColumn can not be empty")
    else:
        try:
            OPTIONS = {"overwriteSchema": overwriteSchema}
            if partitionColumn is not None:
                df.write.format(file_format).mode(mode)\
                    .option("overwriteSchema",overwriteSchema)\
                    .partitionBy(*partitionColumn).save(location)
            else:
                df.write.format(file_format).mode(mode).option("overwriteSchema", overwriteSchema).save(location)
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : find the most recent updated files
    Input : directory_path
    Output : abs_file_path
"""
def find_most_recent_file(directory_path):
    if directory_path is None or directory_path == "":
        raise Exception("directory_path can not be empty")
    else:
        try:
            file = dbutils.fs.ls(directory_path)
            most_recent_file = sorted(file, key = lambda i:i.modificationTime, reverse=True)[0]
            abs_file_path = most_recent_file.path
            return abs_file_path
        except Exception as e:
            raise Exception(e)

# COMMAND ----------

"""
    Purpose : function to replace column's value as per col_dict 
    Input : spark dataframe, column, col_dict
    Output : abs_file_path
"""
def campaign_reco(df, col_name, col_dict):
    try:
        for key in col_dict:
            df = df.withColumn(col_name,regexp_replace("Package", key,col_dict[key]))
        return df
    except Exception as e:
        raise Exception(e)    

# COMMAND ----------

"""
    Purpose : read data from excel file 
    Input : sheet_name, source_path, inferSchema, treatEmptyValuesAsNulls
    output : spark dataframe
"""
def read_excel(sheet_name, source_path, inferSchema=False, treatEmptyValuesAsNulls=False):
#     validate the argument
    if sheet_name is None or sheet_name == "":
        raise Exception("sheet_name can not be empty")
    if source_path is None or source_path == "":
        raise Exception("source_path can not be empty")
    if inferSchema is None or inferSchema == "":
        raise Exception("inferSchema can not be empty")
    if treatEmptyValuesAsNulls is None or treatEmptyValuesAsNulls == "":
        raise Exception("treatEmptyValuesAsNulls can not be empty")
    else:
        FORMAT = spark.read.format("com.crealytics.spark.excel")
        OPTIONS = {"header":True, "inferSchema":inferSchema,
                   "dataAddress":sheet_name, "treatEmptyValuesAsNulls":treatEmptyValuesAsNulls}
        try:
            df = FORMAT.options(**OPTIONS).load(source_path)
            return df
        except Exception as e:
            raise Exception(e)

# COMMAND ----------


"""
    Purpose : convert epoch timestamp into date format YYYY-mm-dd
    Input : epoch time
    output : date
"""
def epoch_to_datetime(epoc_time):
    if len(str(epoc_time)) == 10:
        #     if epoch time is in seconds
        return date_format.fromtimestamp(epoc_time).strftime('%Y-%m-%d %H:%M:%S')
    if len(str(epoc_time)) == 13:
        #     if epoch time is in miliseconds
        return dt.fromtimestamp(epoc_time/1000).strftime('%Y-%m-%d %H:%M:%S')
    if len(str(epoc_time)) == 16:
        #     if epoch time is in microseconds
        return dt.fromtimestamp(epoc_time/1000000).strftime('%Y-%m-%d %H:%M:%S')
    if len(str(epoc_time)) == 19:
        #     if epoch time is in nanoseconds
        return dt.fromtimestamp(epoc_time/1000000000).strftime('%Y-%m-%d %H:%M:%S')

# register epoch_to_date as pyspark udf
udf_epoch_to_datetime = udf(epoch_to_datetime, StringType())    

# COMMAND ----------


"""
    Purpose : convert str to date dd-mm-YYYY
    Input : epoch time
    output : date
"""
def epoch_to_datetime(epoc_time):
    
        return dt.strptime(epoc_time,'%d-%m-%Y')

# register epoch_to_date as pyspark udf
udf_str_to_date = udf(epoch_to_datetime, StringType())    