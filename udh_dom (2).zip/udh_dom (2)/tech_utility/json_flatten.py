# Databricks notebook source
# MAGIC %md ### Json flatten
# MAGIC * Doc_Type           : ETL
# MAGIC * Tech Description   : This notebook is flatten the json of array type.
# MAGIC * Pre_requisites     : Accepts the spark dataframe.
# MAGIC * Inputs             : Spark dataframe.
# MAGIC * Output             : Spark dataframe with flatten json.
# MAGIC * author             : 'Blazeclan'

# COMMAND ----------

# DBTITLE 1,importing required 
# importing the required 
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import DataFrame as sparkDF

# COMMAND ----------

# DBTITLE 1,Json Flattening function for array type and struct type
#list of columns as per filter_type(ArrayType, StructType)
"""
    Purpose : append the columns in list cols 
    Input : spark dataframe , filter_types
    output : list of columns
"""
def type_cols(df_dtypes, filter_type):
    try:
        cols = []
        #extracting columns and data type and appending in variable cols as list
        for col_name, col_type in df_dtypes:
            if col_type.startswith(filter_type):
                cols.append(col_name)
        return cols
    except Exception as e:
        raise Exception(e)

# normalize the parent objects with child object as column name
"""
    Purpose : normalize the json field into root object 
    Input : spark dataframe , columns
    output : spark dataprame
"""
def df_normalize(df, columns):    
    try:
        #convert array of struct into struct using array_zip
        df = df.withColumn("arr_col", array_zip(*columns))
        #returns all values in array including null
        df = df.withColumn("arr_col", explode_outer(col("arr_col")))
        #drop parent column and add child columns
        for column in columns:
            df = df.withColumn(column, col("arr_col." + column))
        nested_df = df.drop(col('arr_col'))
        return flatten_struct(nested_df)        
    except Exception as e:
            raise Exception(e)
            

#flatten json of array type schema
"""
    Purpose : flatten the array type of json data 
    Input : spark dataframe
    output : spark dataprame
"""
def flatten_array(df):
    #validate input parameter
    if df == "" or df is None:
        raise Exception("df can not be empty")
    if not isinstance(df, sparkDF):
        raise Exception("df must be type of spark dataframe")
    else:
        try:
            #for all array type column call the df_normalize function
            while True:
                columns = []
                for col_name,col_type in df.dtypes:
                    if col_type[:5] == "array":
                        columns.append(col_name)
                    df = df_normalize(df, columns)
                    if len(columns)>0:
                        print(columns)
                    else:
                        break
#           for all nested array type column call json_flatten function
            for col_name,col_type in df.dtypes:
              if col_type[:5] == "array":
#                 print("array present")
                return json_flatten(df)        
            return df
        except Exception as e:
            raise Exception(e)
            
            
#flatten json for struct type schema
"""
    Purpose : flatten the struct type of json data 
    Input : spark dataframe
    output : spark dataprame
"""

def flatten_struct(*args):
    try:
        parent_node_req = args[1]
    except:
        parent_node_req = 'yes'
    try:
        nested_df = args[0]
        stack = [((), nested_df)]
        columns = []
        #for all struct type column convert nested column into root column + child column
        if parent_node_req.lower() == 'yes':
            while len(stack) > 0:
                parents, df = stack.pop()
                for column_name, column_type in df.dtypes:
                    if column_type[:6] == "struct":
                        projected_df = df.select(column_name + ".*")
                        stack.append((parents + (column_name,), projected_df))
                    else:
                        columns.append(col(".".join(parents + (column_name,))).alias("_".join(parents + (column_name,))))
            return nested_df.select(columns)
        else:
            while len(stack) > 0:
                parents, df = stack.pop()
                for column_name, column_type in df.dtypes:
                    if column_type[:6] == "struct":
                        projected_df = df.select(column_name + ".*")
                        stack.append((parents + (column_name,), projected_df))
                    else:
                        columns.append(col(".".join(parents + (column_name,))).alias(column_name))
            return nested_df.select(columns)
    except Exception as e:
        raise Exception(e)
        
        
#driver function for flatten json(ArrayType, StructType)
"""
    Purpose : Driver function to flatten json(ArrayType, StructType) 
    Input : spark dataframe
    output : spark dataprame
"""
def flatten_json(nested_df):
    try:
        df = nested_df
        #check the type of columns
        struct_cols = type_cols(nested_df.dtypes, "struct")
        array_cols = type_cols(nested_df.dtypes, "array")
        if struct_cols:
            #call flatten_struct if type of column is struct
            df = flatten_struct(df)
            return flatten_json(df)
        if array_cols:
            #call flatten_array if type of column is array
            df = flatten_array(df)
            return flatten_json(df)
        return df
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Json Flattening function for array type, struct type and map type
#Driver function flatten the json of array type, struct type and map type
"""
    Purpose : Driver function to flatten json(ArrayType, StructType, MapType) 
    Input : spark dataframe
    output : spark dataprame
"""
def flatten_all_type_json(df, sep="_"):
#     compute Complex Fields (Arrays, Structs and Maptypes) in Schema
    complex_fields = dict(
      [
          (field.name, field.dataType)
          for field in df.schema.fields
          if type(field.dataType) == ArrayType
          or type(field.dataType) == StructType
          or type(field.dataType) == MapType
      ]
    )

    while len(complex_fields) != 0:
        col_name = list(complex_fields.keys())[0]
        if type(complex_fields[col_name]) == StructType:
            expanded = [
              col(col_name + "." + k).alias(col_name + sep + k)
              for k in [n.name for n in complex_fields[col_name]]
            ]
            df = df.select("*", *expanded).drop(col_name)

#         if ArrayType then add the Array Elements as Rows using the explode function
#         i.e. explode Arrays
        if type(complex_fields[col_name]) == ArrayType:
            df = df.withColumn(col_name, explode_outer(col_name))

#         if MapType then convert all sub element to columns.
#         i.e. flatten
        if type(complex_fields[col_name]) == MapType:
            keys_df = df.select(explode_outer(map_keys(col(col_name)))).distinct()
            keys = list(map(lambda row: row[0], keys_df.collect()))
            key_cols = list(
                  map(
                      lambda f: col(col_name).getItem(f).alias(str(col_name + sep + f)),
                      keys,
                  )
            )
            drop_column_list = [col_name]
            df = df.select(
                  [
                      col_name
                      for col_name in df.columns
                      if col_name not in drop_column_list
                  ]
                  + key_cols
            )

#         recompute remaining Complex Fields in Schema
        complex_fields = dict(
              [
                  (field.name, field.dataType)
                  for field in df.schema.fields
                  if type(field.dataType) == ArrayType
                  or type(field.dataType) == StructType
                  or type(field.dataType) == MapType
              ]
          )

    return df

# COMMAND ----------

# DBTITLE 1,flattening json for nonNBM  array of struct
from pyspark.sql.functions import col, explode
def type_cols(df_dtypes, filter_type):
    cols = []
    #extracting columns and data type and appending in variable cols as list
    for col_name, col_type in df_dtypes:
        if col_type.startswith(filter_type):
            cols.append(col_name)
    return cols

#for all struct type column convert nested column into root column + child column
def flatten_df(nested_df, sep='_'):
    nested_cols = type_cols(nested_df.dtypes, "struct")
    flatten_cols = [fc for fc, _ in nested_df.dtypes if fc not in nested_cols]
    for nc in nested_cols:
        for cc in nested_df.select(f"{nc}.*").columns:
            if sep is None:
                flatten_cols.append(col(f"{nc}.{cc}").alias(f"{cc}"))
            else:
                flatten_cols.append(col(f"{nc}.{cc}").alias(f"{nc}{sep}{cc}"))
    return nested_df.select(flatten_cols)

#for all array type column convert nested column
def explode_df(nested_df):
    nested_cols = type_cols(nested_df.dtypes, "array")
    exploded_df = nested_df
    for nc in nested_cols:
        exploded_df = exploded_df.withColumn(nc, explode(col(nc)))
    return exploded_df

#wrapper function for flatten 
def flatten_explode_df(nested_df):
    df = nested_df
    struct_cols = type_cols(nested_df.dtypes, "struct")
    array_cols = type_cols(nested_df.dtypes, "array")
    if struct_cols:
        df = flatten_df(df)
        return flatten_explode_df(df)
    if array_cols:
        df = explode_df(df)
        return flatten_explode_df(df)
    return df

# df = flatten_explode_df(nested_df)