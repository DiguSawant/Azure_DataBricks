# Databricks notebook source
# MAGIC %md ### Data Quality Functions
# MAGIC * Doc_Type              :   ETL
# MAGIC * Tech Description      : This notebook is for dq rules using udf.
# MAGIC * Pre_requisites        : Accepts the columns.
# MAGIC * Inputs             : column name.
# MAGIC * Output             : Boolean.
# MAGIC * author             : Blazeclan

# COMMAND ----------

# DBTITLE 1,Importing required Packages
from pyspark.sql.types import *   
from pyspark.sql.functions import *
import re

# COMMAND ----------

# DBTITLE 1,Function Defination of check_null 
"""
    Purpose : check null value for given column
    Input : column name
    Output : boolean (true or false)
"""
def python_check_null(value):
    try:
        if value is None:
            status = False
        else:
          #check the value is empty string or string None and string null
            value=str(value).strip() 
            if value == "None" or value == "" or value=="null":
                status = False
            else:
                status = True
        return status
    except Exception as e:
        raise Exception(e)   
        
# example for calling function
# %sql select check_nul(L_NAME)
# good_df = df.where(check_nul(col("L_NAME")) == True)

# COMMAND ----------

# DBTITLE 1,Registering Check_null function in SparK SQL
spark.udf.register("check_null", python_check_null)

# COMMAND ----------

# DBTITLE 1,Registering Check_null function in Pyspark
check_null = udf(python_check_null, BooleanType())

# COMMAND ----------

# DBTITLE 1,Function Defination of check_length 
"""
    Purpose : check length
    Input : column_name, length (length is as arguments it can take one or two parameters)
    Output : boolean type
"""

def python_check_length(column_name, *length):
#     Check the parameter length is null or empty    
    if length == "" or length is None:
        raise Exception("length can not br empty or none")
    else:
        try:
#             check the condition of parameter length with given value
            if len(length) > 2:
                raise Exception("length should be [min,max] or [exact_value]")
            if len(length) == 2:
                min_value = length[0]
                max_value = length[1]
#                 comapre the lenght of given column_name with minimum value and maximim value
                if min_value <= len(str(column_name)) <= max_value:
                    status = True
                else:
                    status = False
            else:
                if len(str(column_name)) == length[0]:
                    status = True
                else:
                    status = False
            return status          
        except Exception as e:
            raise Exception(e)
            


# example for calling function
# %sql select check_length(EMPLOYEE_ID)
# good_df = df.where(check_length(col("EMPLOYEE_ID"),lit(3)) == True)
# good_df = df.where(check_length(col("EMPLOYEE_ID"),lit(2),lit(5)) == True)

# COMMAND ----------

# DBTITLE 1,Registering check_length function as udf in SparK SQL
spark.udf.register("check_length", python_check_length, BooleanType())

# COMMAND ----------

# DBTITLE 1,Registering check_length function as udf in Pyspark
check_length = udf(python_check_length, BooleanType())

# COMMAND ----------

# DBTITLE 1,Function Defination of check_email 
"""
    Purpose : check email's pattern for given column
    Input : column name
    Output : boolean (true or false)
"""
def python_check_email(column_name):
    
    try:
        column_name=str(column_name)
        #regex pattern for email validation check like contains @ and domain
        pattern = re.compile('^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
        if pattern.match(column_name):
            status = True
        else:
            status = False
        return status
      
    except Exception as e:
        raise Exception(e)


# example for calling function
# %sql select check_email(EMAIL)
# good_df = df.where(check_email(col("EMAIL") == True)

# COMMAND ----------

# DBTITLE 1,Registering check_email function as udf in SparK SQL
spark.udf.register("check_email", python_check_email, BooleanType())

# COMMAND ----------

# DBTITLE 1,Registering check_email function as udf in Pyspark
check_email = udf(python_check_email, BooleanType())

# COMMAND ----------

# DBTITLE 1,Function Defination of check_phone_number
"""
    Purpose : check phone number pattern for given column
    Input : column name
    Output : boolean (true or false)
"""

def python_check_phone_number(column_name):
    try:
      # removing "-" from the phone number  to validate it is digit  
      number = str(column_name).strip().replace("-","")
      
      if number.isdigit() :
        if len(number) == 10 :
            return True
        else:
            return False
      #if the number contains "+" then check for contry code and length of the phone number    
      else:
            if number[0:3] == "+66" and len(number) == 12:
               return True
            else:
               return False
              
    except Exception as e:
        raise Exception(e)

# example for calling function
# %sql select check_phone_number(PHONE_NUMBER)
# good_df = df.where(check_phone_number(col("PHONE_NUMBER"))) == True)



# COMMAND ----------

# DBTITLE 1,Registering check_phone_number function as udf in SparK SQL
spark.udf.register("check_phone_number", python_check_phone_number, BooleanType())

# COMMAND ----------

# DBTITLE 1,Registering check_phone_number function as udf in Pyspark
check_phone_number = udf(python_check_phone_number, BooleanType())