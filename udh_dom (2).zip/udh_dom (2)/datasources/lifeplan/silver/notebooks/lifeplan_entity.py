# Databricks notebook source
"""
    Purpose : Load data for Lead
    Input : s3 files(Topic : TH.DEV.ODS.IRIS_LEAD)
    Output : Tables - dev_cube_fna_silver.iris_lead_cube_fna_silver, dev_silver.iris_lead_cube_fna_silver
"""

# COMMAND ----------

# MAGIC %run  ../../../../tech_utility/aes

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/common_functions
# MAGIC

# COMMAND ----------

# MAGIC %run ../../../../datasources/cube/config/config_lead_silver

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime,timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

#calling read_stream method to read source data using autoloader
try:
    df_read_lead = read_stream(source_path = source_s3_path, checkpoint_location = checkpointlocation, file_format = "json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert string to struct schema using from_json
try:
    lead_flattend_df = df_read_lead.withColumn(flatten_column,from_json(flatten_column, column_schema)).dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#flatten the json data
try:
    lead_stream_flatten_df = flatten_struct(lead_flattend_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop rows if null found in all coumns
try:
    df_dropna_lead = lead_stream_flatten_df.dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append the partition column udh_insert_dt and udh_insert_hr
try:
    partition_df_lead = df_dropna_lead.withColumn("udh_source_sys",lit('lead'))\
                                .withColumn("udh_insert_timestamp",current_timestamp())\
                                .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicates
try:
    partition_df_lead_dup = partition_df_lead.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# insert flatten data into external table
try:
    table = intermediate_database_name + "." + intermediate_table_name
    partition_df_lead_dup.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation",intermediate_checkpoint_location)\
        .option("path",intermediate_target_path)\
        .partitionBy(["UDH_BATCH_ID"])\
        .toTable(table)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all columns names in upper case
try:
    lead_field_upper_df = columnsNames_to_upper_case(partition_df_lead_dup)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# filter out the corrupted data
try:
    lead_field_filter_df = lead_field_upper_df.filter("JSONVALUE_ID not in ('10181','10182','10183','10184','10185','11903', '13794','16249','21054','21055','21038','22039','22040','22038' ) ")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt the json_data field of dataframe
try:
    decryptDf_lead = lead_field_filter_df 
    for field in  encrypted_column :   
        decryptDf_lead = decryptDf_lead.withColumn(field, when(decryptDf_lead[field].isNull(),lit(None)).otherwise(aes_decrypt(field)))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all string type column's value into upper case
df = decryptDf_lead
str_cols = [col_name for col_name, data_type in df.dtypes if data_type == "string"]
for col_name in str_cols:        
    df = df.withColumn(col_name, upper(col(col_name)))

# COMMAND ----------

#encrypt the json_data field of dataframe
try:
    encryptDf = df 
    for field in  encrypted_column :   
        encryptDf = encryptDf.withColumn(field, when(encryptDf[field].isNull(),lit(None)).otherwise(aes_encrypt(field)))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#covert datatype for created_time column
df_read_long = encryptDf.withColumn("JSONVALUE_CREATEDTIME",encryptDf.JSONVALUE_CREATEDTIME.cast("long"))

# COMMAND ----------

#convert epoch to datetime
try:
    df_read_time = df_read_long.withColumn("JSONVALUE_CREATEDTIME", udf_epoch_to_datetime(df_read_long["JSONVALUE_CREATEDTIME"]))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate rows
try:
    encryptDf_lead = df_read_time.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# save the data
table = database_name + "." + table_name
def process_batch(df,epoch_id):    
    df.select(select_cols).write.format("delta").mode("append").partitionBy("UDH_BATCH_ID").option("path",target_path).saveAsTable(table)

# COMMAND ----------

# write data into external delta table 
try:    
    encryptDf_lead.writeStream\
                        .foreachBatch(process_batch)\
                        .option("checkpointLocation",checkpointlocation)\
                        .start()
except Exception as e:
    raise Exception(e)