# Databricks notebook source
# MAGIC %run ../config/config_vnb

# COMMAND ----------

# MAGIC %run ../../../tech_utility/common_functions

# COMMAND ----------

# read csv data using read_csv method
try:
    vnb_rates_df = read_csv(location = vnb_rates_file_path, sep = ",", header = True, infer_schema = False, schema = None, mode = "PERMISSIVE")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# normalize the columns
try:
    normalized_df = normalize_column_name(vnb_rates_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# remove % symbol
try:
    normalized_df = normalized_df.withColumn("VNB%",regexp_replace("VNB%","%",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# cast column into decimal data type
try:
    normalized_df = normalized_df.withColumn("VNB%",col("VNB%").cast(DecimalType()))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# rename column using spark function
try:
    renamed_df = normalized_df.withColumnRenamed("VNB%","VNB_PERCENT")\
                                .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType()))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write data into delta table
try:
    renamed_df.write.format("delta")\
              .option("path",vnb_rates_target_path)\
              .mode("overwrite")\
              .saveAsTable(vnb_rates_target_table)
except Exception as e:
    raise Exception(e)