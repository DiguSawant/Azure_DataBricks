# Databricks notebook source
# MAGIC %run ../config/config_vnb

# COMMAND ----------

# MAGIC %run ../../../tech_utility/common_functions

# COMMAND ----------

# read csv data from given location
try:
    channel_df = read_csv(location = vnb_channel_file_path, sep = ",", header = True, infer_schema = True, schema = None, mode = "PERMISSIVE")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# normalize the column and append column udh_insert_timestamp
try:
    normalized_df = normalize_column_name(channel_df)\
                     .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType()))\
                     .drop("Remarks")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write data into table
try:
    normalized_df.write.format("delta")\
                 .option("path", vnb_channel_target_path)\
                 .mode("overwrite")\
                 .saveAsTable(vnb_channel_target_table)
except Exception as e:
    raise Exception(e)