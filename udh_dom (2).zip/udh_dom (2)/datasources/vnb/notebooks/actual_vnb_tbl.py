# Databricks notebook source
# MAGIC %run ../config/config_vnb

# COMMAND ----------

# MAGIC %run ../../../tech_utility/common_functions

# COMMAND ----------

# read csv data using read_csv method
try:
    actual_vnb_df = read_csv(location = actual_vnb_file_path, sep = ",", header = True, infer_schema = False, schema = None, mode = "PERMISSIVE")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# normalize the columns
try:
    normalized_df = normalize_column_name(actual_vnb_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# remove % symbol
try:
    normalized_df = normalized_df\
                    .withColumn("VNB%_Af_Rein_Diver",regexp_replace("VNB%_Af_Rein_Diver","%",""))\
                    .withColumn("Protection_VNB%_Af_Rein_Diver",regexp_replace("Protection_VNB%_Af_Rein_Diver","%",""))\
                    .withColumn("NBStrain%",regexp_replace("NBStrain%","%",""))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#Trim the spaces from both ends
try:
    normalized_df=trim_fields(normalized_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# remove commas from the fields
try:
    for column in normalized_df.columns:
        normalized_df=normalized_df.withColumn(column,regexp_replace(column, ',', ''))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#replacing - with 0 not like -100,-fdfd

try:
    pattern=r"-(?![A-Za-z0-9])"
    for column in normalized_df.columns:
        normalized_df= normalized_df.withColumn(column,regexp_replace(col(column),pattern,'0'))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# cast column into decimal data type
try:
    normalized_df = normalized_df\
                    .withColumn("Protection_VNB%_Af_Rein_Diver",col("Protection_VNB%_Af_Rein_Diver").cast(DecimalType()))\
                    .withColumn("VNB%_Af_Rein_Diver",col("VNB%_Af_Rein_Diver").cast(DecimalType()))\
                    .withColumn("NBStrain%",col("NBStrain%").cast(DecimalType()))\
                    .withColumn("VNB_Af_Rein_Diver",col("VNB_Af_Rein_Diver").cast(LongType()))
                    
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# rename column using spark function
try:
    renamed_df = normalized_df\
                .withColumnRenamed("Protection_VNB%_Af_Rein_Diver","Protection_VNB_PERCENT_Af_Rein_Diver")\
                .withColumnRenamed("NBStrain%","NBMStrain_PERCENT")\
                .withColumnRenamed("VNB%_Af_Rein_Diver","VNB_PERCENT_Af_Rein_Diver")\
                .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType()))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# converting column names in uppercase
try:
    upper_df=columnsNames_to_upper_case(renamed_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write data into delta table
try:
    upper_df.write.format("delta")\
              .option("path",actual_vnb_target_path)\
              .mode("overwrite")\
               .option("overwriteSchema","True")\
              .saveAsTable(actual_vnb_target_table)
except Exception as e:
    raise Exception(e)