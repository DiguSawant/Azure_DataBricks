# Databricks notebook source
# getting the environment variables
import os
env = os.getenv("env").lower()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

vnb_rates_target_path = f"{path_prefix}/silver/vnb/vnb_rates/"
vnb_rates_target_table = f"{env}_silver.vnb_rates_silver"
vnb_rates_file_path = f"{path_prefix}/bronze/vnb/source/vnb_rates.csv"
vnb_channel_target_path = f"{path_prefix}/silver/vnb/vnb_channel/"
vnb_channel_target_table = f"{env}_silver.vnb_channel_silver"
vnb_channel_file_path = f"{path_prefix}/bronze/vnb/source/Digital_Channel_Partner.csv"
actual_vnb_file_path=f"{path_prefix}/vnb/source/actual_vnb/10.VNB_YTD_by_Policy_TH_Send_Out(M1).csv"
actual_vnb_target_path=f"{path_prefix}/silver/vnb/actual_vnb/"
actual_vnb_target_table=f"{env}_silver.actual_vnb_silver"

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")