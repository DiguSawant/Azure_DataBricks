# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "lead": { 
     "s3_path": path_prefix + f"/testinfo/data/lead_tmp/",
     "schemalocation_path": path_prefix + "/testinfo/schema/cube/lead_tmp/",
     "checkpoint_location": path_prefix + "/testinfo/checkpoint/lead_tmp/",
	 "column_schema": StructType([ StructField('clientType', StringType(), True), StructField('leadStatusCode', StringType(), True), StructField('name',  StructType([StructField('en', StringType(), True) ])), StructField('preferredLang', StringType(), True), StructField('age', StringType(), True), StructField('productInterestedTypeCode', StringType(), True), StructField('productInterested',  StructType([StructField('th', StringType(), True), StructField('en_th', StringType(), True) ])), StructField('mobileNumber', StringType(), True), StructField('emailAddress', StringType(), True), StructField('createdTime', StringType(), True), StructField('updatedTime', StringType(), True), StructField('sourceTypeCode', StringType(), True), StructField('id', StringType(), True), StructField('acknowledged', StringType(), True), StructField('status', StringType(), True), StructField('agentCode', StringType(), True), StructField('birthDate', StringType(), True), StructField('contactedFlag', StringType(), True), StructField('appointmentFlag', StringType(), True), StructField('illustrationFlag', StringType(), True), StructField('submittedFlag', StringType(), True), StructField('activityLogList', StringType(), True)]),
     "flatten_column": "jsonValue",
     "encrypted_column": ["name", "mobileNumber", "phoneMobile", "emailAddress", "birthDate"],
     "select_cols": "*",
     "decrypted_column": "",
     "target_path" : path_prefix + '/testinfo/mydata/lead_tmp/',
     "database_name" : f"{env}_cube_silver_test",
     "table_name" : "lead_silver",
     "pii_columns": "jsonValue_name_en,jsonValue_mobileNumber,jsonValue_phoneMobile,jsonValue_emailAddress,jsonValue_birthDate"
    }   
    
}

# COMMAND ----------

# #config for cube
# config_cube =  {
#     "lead": { 
#      "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.ODS.IRIS_LEAD/",
#      "schemalocation_path": path_prefix + "/silver/schema/cube/lead/",
#      "checkpoint_location": path_prefix + "/silver/checkpoint/cube/lead/",
# 	 "column_schema":"",
#      "flatten_column": "",
#      "encrypted_column": "",
#      "select_cols": "*",
#      "decrypted_column": "",
#      "target_path" : path_prefix + '/silver/cube/lead/',
#      "database_name" : f"{env}_cube_silver",
#      "table_name" : "lead_silver",
#      "pii_columns": ""
#     }   
    
# }

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['lead']['s3_path']
schemalocation = config_cube['lead']['schemalocation_path']
checkpointlocation = config_cube['lead']['checkpoint_location']
target_path = config_cube['lead']['target_path']
column_schema = config_cube['lead']['column_schema']
flatten_column = config_cube['lead']['flatten_column']
encrypted_column = config_cube['lead']['encrypted_column']
select_cols = config_cube['lead']['select_cols']
database_name = config_cube['lead']['database_name']
table_name = config_cube['lead']['table_name']
pii_columns = config_cube['lead']['pii_columns']


# COMMAND ----------

