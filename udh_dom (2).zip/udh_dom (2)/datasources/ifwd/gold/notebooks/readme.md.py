# Databricks notebook source
# MAGIC %md
# MAGIC # Gold layer Notebooks

# COMMAND ----------

1. The scripts that are used for the gold layer