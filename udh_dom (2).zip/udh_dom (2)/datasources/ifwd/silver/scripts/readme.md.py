# Databricks notebook source
# MAGIC %md
# MAGIC # Silver layer sql script

# COMMAND ----------

1. This folder contains all the DDL & DML notebooks (sql statements) for the required tables to be created