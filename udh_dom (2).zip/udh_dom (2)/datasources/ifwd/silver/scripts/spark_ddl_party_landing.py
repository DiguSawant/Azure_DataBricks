# Databricks notebook source
import os
env = os.getenv("env").lower()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

spark.sql(f"""create database {env}_party_silver""")

# COMMAND ----------

spark.sql(f"""create database {env}_silver""")

# COMMAND ----------

database_name = f"{env}_party_silver"

nonnbm_party_table = f"party_silver"
nonnbm_party_table_loc = f"{path_prefix}/silver/party_silver/party/"

nonnbm_individual_table = "individual_silver"
nonnbm_individual_table_loc = f"{path_prefix}/silver/party_silver/individual/"

nonnbm_identity_table = "identity_silver"
nonnbm_identity_table_loc = f"{path_prefix}/silver/party_silver/identity/"

nonnbm_electronic_address_table = "electronic_address_silver"
nonnbm_electronic_address_table_loc = f"{path_prefix}/silver/party_silver/electronic_address/"

nonnbm_bank_account_table = "bank_account_silver"
nonnbm_bank_account_table_loc = f"{path_prefix}/silver/party_silver/bank_account/"

nonnbm_organisation_table = "organisation_silver"
nonnbm_organisation_table_loc = f"{path_prefix}/silver/party_silver/organisation/"

# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_party_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_party_table} (
party_sid long generated always as identity (start with 1 increment by 1) comment "" ,
party_id string comment "",
party_source string comment "",
party_name string comment "",
party_type_code string comment "",
customer_flag string comment "",
employee_flag string comment "",
prospect_flag string comment "",
agent_flag string comment "",
email_address string comment "",
udh_active_flag string comment "",
udh_insert_date timestamp comment "",
udh_update_date timestamp comment "",
source_system string comment "",
dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_party_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")


# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_individual_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_individual_table}(
individual_sid long generated always as identity (start with 1 increment by 1) comment "",
party_id string comment "",
full_name string comment "",
first_name string comment "",
middle_name string comment "",
last_name string comment "",
local_full_name string comment "",
local_first_name string comment "",
local_middle_name string comment "",
local_last_name string comment "",
salutation string comment "",
occupation string comment "",
occupation_class string comment "",
annual_income string comment "",
gender_code string comment "",
birth_date string comment "",
birth_place string comment "",
nationality_code string comment "",
marital_status_code string comment "",
language_code string comment "",
death_date string comment "",
udh_active_flag string comment "",
udh_insert_date timestamp comment "",
udh_update_date timestamp comment "",
source_system string comment "",
dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_individual_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")


# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_identity_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_identity_table}(
identity_sid long generated always as identity (start with 1 increment by 1) comment "",
party_id string comment "",
ident_type string comment "",
ident_number string comment "",
ident_issue_country string comment "",
ident_expiry_date timestamp comment "",
udh_active_flag string comment "",
udh_insert_date timestamp comment "",
udh_update_date timestamp comment "",
source_system string comment "",
dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_identity_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_electronic_address_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_electronic_address_table} (
    electronic_address_id long generated always as identity (start with 1 increment by 1) comment "auto increment value",
    party_id string comment "forign key",
    address_type string comment "mobile - hardcoded value",
    phone_country_code string comment "66 by default if its not mentioned in source system",
    phone_area_code string comment "populate null",
    phone_number string comment "",
    contact_via_phone string comment "",
    udh_active_flag string comment "Default to Y. When record is not active change N",
    udh_insert_date timestamp comment "",
    udh_update_date timestamp comment "",
    source_system string comment "hard code value",
    dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_electronic_address_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_bank_account_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_bank_account_table} (
    bank_account_key long generated always as identity (start with 1 increment by 1) comment "auto increment value",
    party_id string comment "forign key",
    bank_account_number string comment "",
    bank_code string comment "",
    bank_name string comment "",
    bank_branch_code string comment "",
    bank_account_name string comment "",
    bank_account_type string comment "",
    main_currency string comment "",
    udh_active_flag string comment "Default to Y. When record is not active change N",
    udh_insert_date timestamp comment "",
    udh_update_date timestamp comment "",
    source_system string comment "hard code value",
    dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_bank_account_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

spark.sql(f"""drop table if exists {database_name}.{nonnbm_organisation_table}""")

# COMMAND ----------

spark.sql(f"""
create or replace table {database_name}.{nonnbm_organisation_table} (
    organisation_sid long generated always as identity (start with 1 increment by 1) comment "auto increment value",
    party_id string comment "forign key",
    organisation_name string comment "",
    local_organisation_name string comment "",
    organisation_category string comment "",
    establish_date string comment " ",
    establish_country_code string comment "",
    udh_active_flag string comment "Default to Y. When record is not active change N",
    udh_insert_date timestamp comment "",
    udh_update_date timestamp comment "",
    source_system string comment "hard code value",
    dq_flag string comment ""
)
USING DELTA
partitioned By (source_system)
location '{nonnbm_organisation_table_loc}'
tblproperties (
    delta.enablechangedatafeed = true,
    delta.autooptimize.optimizewrite = true,
    delta.autooptimize.autocompact = true);
""")

# COMMAND ----------

