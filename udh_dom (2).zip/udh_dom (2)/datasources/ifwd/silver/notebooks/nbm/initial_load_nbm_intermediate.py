# Databricks notebook source
# DBTITLE 1,import packages
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,import aes notebook
# MAGIC %run  ../../../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,import common functions notebook
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,import config notebook
# MAGIC %run ../../../config/config_nbm_silver

# COMMAND ----------

# DBTITLE 1,import json_flatten notebook
# MAGIC %run ../../../../../tech_utility/json_flatten

# COMMAND ----------

# DBTITLE 1,read nbm_historical_target_path
#read data from delta table
try:
    nbm_historical_df = read_delta(location = nbm_historical_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#rename column names adding after
try:
    for column in nbm_historical_df.columns:
        if column  in ["Json_Data","udh_source_sys","udh_insert_timestamp","udh_batch_id"]:
            pass
        else:
            new_column = "after_"+column
            nbm_historical_df = nbm_historical_df.withColumnRenamed(column,new_column)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt Json_Data column
try:
    decrypted_df = nbm_historical_df.withColumn(encrypted_column,aes_decrypt(encrypted_column))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert string type col to json column
try:
    decrypted_df = string_to_json_column(df = decrypted_df, column = encrypted_column, schema = nbm_schema)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#flatten the dataframe
try:
    flatten_df = flatten_struct(decrypted_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# explode column Json_Data_policyData_insuredLives
try:
    flatten_df = flatten_df.withColumn("Json_Data_policyData_insuredLives", explode_outer("Json_Data_policyData_insuredLives"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# flatten the spark dataframe
try:
    flatten_explode_df = flatten_struct(flatten_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert column values to uppercase
try:
    upper_value_df = columnsValue_to_upper_case(flatten_explode_df, pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

for cols in upper_value_df.dtypes:  
    if 'array' in cols[1] or 'struct' in cols[1] or cols[1]=='timestamp':
        continue
    else:
        upper_value_df = upper_value_df.withColumn(cols[0],col(cols[0]).cast(StringType()))

# COMMAND ----------

# comnvert columns into upper case
try:
    upper_column_df = columnsNames_to_upper_case(upper_value_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# encrypt pii columns
try:
    encrypt_df = encrypt_column(upper_column_df, pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# cast column into string
try:
    cast_df = encrypt_df.withColumn("AFTER_LAST_UPDATED_TIME",col("AFTER_LAST_UPDATED_TIME").cast("string"))\
                                           .withColumn("AFTER_SUBMITTED_DATE",col("AFTER_SUBMITTED_DATE").cast("string"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#write into nbm_intermediate_silver_table_name
try:
    table = database_name + "." + table_name
    cast_df.write.format("delta")\
            .option("path",target_path)\
            .mode("append")\
            .option("partitionBy","UDH_BATCH_ID")\
            .saveAsTable(table)
except Exception as e:
    raise Exception(e)