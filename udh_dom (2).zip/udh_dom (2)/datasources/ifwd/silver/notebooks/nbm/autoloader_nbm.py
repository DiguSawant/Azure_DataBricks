# Databricks notebook source
# DBTITLE 1,running notebook data_quality_functions
# MAGIC %run ../../../../../tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,running notebook aes
# MAGIC %run  ../../../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_spark_functions
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook json_flatten
# MAGIC %run  ../../../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %run ../../../config/config_nbm_silver

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")

# COMMAND ----------

checkpointlocation =  '/mnt/dev/fwd_landing/silver/checkpoint/users_data_19_5_2023/'

# COMMAND ----------

source_s3_path = '/mnt/dev/fwd_landing/bronze/ifwd/nbm_fe_uat/TH.DEV.ODS.IFWD.dbo.Users_Data/year=2023/month=05/day=19/*.json'

# COMMAND ----------

# read json from s3 path
try:
    read_nbm = read_stream(source_path = source_s3_path, checkpoint_location = schemalocation, file_format = "json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert string to struct schema using from_json
try:
    struct_nbm = read_nbm.withColumn(flatten_column,from_json(flatten_column, column_schema)).dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt the json_data field of dataframe
try:
    decrypt_field = flatten_column + "." + encrypted_column
    decryptDf_1 = struct_nbm.withColumn(encrypted_column, aes_decrypt(decrypt_field))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#converting the string to schema using from_json function
try:
    nbm_extract_data = decryptDf_1.withColumn(encrypted_column,from_json(encrypted_column, nbm_schema))\
                                 .withColumn("udh_source_sys", lit('nbm'))\
                                 .withColumn("udh_insert_timestamp",current_timestamp())\
                                 .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# flatten the json_data column
try:
    flatten_df=flatten_struct(nbm_extract_data)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#  explode column json_data_policydata_insuredlives to convert string into objects
try:
    explode_df = flatten_df.withColumn("json_data_policydata_insuredlives", explode_outer("json_data_policydata_insuredlives"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# flatten the json_data_policydata_insuredlives column
try:
    flatten_explode_df = flatten_struct(explode_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

from pyspark.sql.functions import *
#calling encrypt_column method to encrypt the columns
try:
    encypt_df = encrypt_column(df = flatten_explode_df, columns = pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all string type column's value into upper case
table = database_name + "." + table_name
def process_batch(df,epoch_id):
    str_cols = [col_name for col_name, data_type in df.dtypes if data_type == "string"]
    for col_name in str_cols:
        if col_name not in pii_columns:
            df = df.withColumn(col_name, upper(col(col_name)))
    df.write.format("delta").mode("append").partitionBy("UDH_BATCH_ID").option("path",target_path).saveAsTable(table)

# COMMAND ----------

# convert all columns names in upper case
try:
    field_upper_df = columnsNames_to_upper_case(encypt_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate rows
try:
    field_upper_df = field_upper_df.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# write data into external delta table 
try:
    
    field_upper_df.writeStream\
                        .foreachBatch(process_batch)\
                        .option("checkpointLocation",checkpointlocation)\
                        .start()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # write data into external delta table 
# try:
#     table = database_name + "." + table_name
#     field_upper_df.writeStream.format("delta")\
#                         .outputMode("append")\
#                         .partitionBy("udh_batch_id")\
#                         .option("checkpointLocation",checkpointlocation)\
#                         .option("path",target_path)\
#                         .toTable(table)
# except Exception as e:
#     raise Exception(e)