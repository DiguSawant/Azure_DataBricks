# Databricks notebook source
# DBTITLE 1,running notebook config_non_nbm
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

# DBTITLE 1,Execute Data Quality Functions
# MAGIC %run ../../../../../tech_utility/data_quality_functions

# COMMAND ----------

# DBTITLE 1,running notebook aes_blz
# MAGIC %run  ../../../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,running notebook common_function
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,running notebook json_flatten
# MAGIC %run  ../../../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

nosqldata_s3_path = '/mnt/dev/fwd_landing/bronze/ifwd/jeeframework_la/TH.DEV.ODS.IFWD.dbo.NOSQLDATA/year=2023/month=05/day=19/*.json'

intermediate_checkpoint_path ='/mnt/dev/fwd_landing/silver/checkpoint/nosql_data_entity_1/nosqldata_19_5_2023/'


# COMMAND ----------

# DBTITLE 1,read nosqldata as streaming using read_stream method
#calling read_stream method to read source data using autoloader
try:
    nosqldata_stream = read_stream(source_path = nosqldata_s3_path, 
    checkpoint_location = nosqldata_schemalocation, file_format ="json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#calling read_stream method to read source data using autoloader
try:
    nosqlentity_stream = read_stream(source_path = nosqlentity_s3_path, checkpoint_location = nosqlentity_schemalocation,                                              file_format = "json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop rows if null found in all coumns
try:
    nosqlentity_stream = nosqlentity_stream.dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

##extract after column of nosqlentity table
try:
    nosqlentity_extract_data = nosqlentity_stream.withColumn(flatten_column,from_json(flatten_column, nosqlentity_column_schema))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#assgin flatten column
flatten_cols = flatten_column + "." + select_cols

#fetch the data of flatten columns and appending two column for partitioning
try:
    nosqlentity_flatten = nosqlentity_extract_data.select(col(flatten_cols))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,flatten all fields of select column and append column for partitioning
import datetime
#assgin flatten column
nosqldata_flatten_cols = flatten_column + "." + select_cols
try:
    #fetch the data of flatten columns and appending two column for partitioning
    nosqldata_extract_data = nosqldata_stream.withColumn(flatten_column,from_json(flatten_column, nosqldata_column_schema))

    #fetch the data of flatten columns and appending two column for partitioning
    nosqldata_flatten = nosqldata_extract_data.select(nosqldata_flatten_cols,col("ts_ms").cast("long"))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#apply watermark on ts_ms column for 5 hours
try:
    nosqldata_flatten = nosqldata_flatten\
                .withColumn("ts_ms", udf_epoch_to_date("ts_ms")\
                .cast(TimestampType()))\
                .withWatermark("ts_ms", "5 hours")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    # append dt_ with columns of nosqldata
    for cols in nosqldata_flatten.columns:
        nosqldata_flatten = nosqldata_flatten.withColumnRenamed(cols,'dt_'+cols.lower())

    # append et_ with columns of nosqlentity
    for cols in nosqlentity_flatten.columns:
        nosqlentity_flatten = nosqlentity_flatten.withColumnRenamed(cols,'et_'+cols.lower())
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# join nosqldata and nosqlentity on entityseq column
try:
    data_entity_join = nosqldata_flatten.join(nosqlentity_flatten,nosqldata_flatten.dt_entityseq == nosqlentity_flatten.et_entityseq,"inner")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt the encrypted column
try:
    decryptDf_1 = data_entity_join.withColumn(decrypted_column, aes_decrypt(encrypted_column)).dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#extract the data of decrypted column with non_nbm schema
try:
    struct_df = decryptDf_1.withColumn(decrypted_column,from_json(decrypted_column, non_nbm_schema))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#flatten the given dataframe
try:
    flatten_df = flatten_all_type_json(struct_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append the partition column udh_insert_dt and udh_insert_hr
try:
    partition_df = flatten_df.withColumn("udh_source_sys",lit('non_nbm'))\
                                .withColumn("udh_insert_timestamp",current_timestamp())\
                                .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # cast all columns into string
# try:
#     for cols in partition_df.dtypes:
#         if cols[1] in ['array','timestamp']:
#             continue
#         else:
#             partition_df = partition_df.withColumn(cols[0],col(cols[0]).cast(StringType()))
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# convert all columns values in upper case
try:
    value_upper_df = columnsValue_to_upper_case(partition_df,['dt_datavalue'])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#calling encrypt_column method to encrypt the columns
try:
    encrypt_df = encrypt_column(df = value_upper_df, columns = pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all columns names in upper case
try:
    field_upper_df = columnsNames_to_upper_case(encrypt_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# cdrop duplicate rows
try:
    field_upper_df = field_upper_df.dropDuplicates()
except Exception as e:
    raise Exception(e)


# COMMAND ----------

spark.sql("set spark.sql.files.ignoreMissingFiles=true")

# COMMAND ----------

# insert flatten data into external table
try:
    table = database_name + "." + intermediate_table_name
    field_upper_df.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation",intermediate_checkpoint_path)\
        .option("path",intermediate_external_path)\
        .partitionBy(["UDH_BATCH_ID"])\
        .toTable(table)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_party

# COMMAND ----------

# write merge using party_tbl_df in party_silver.party table
if party_flag == True:
    try:
        party_tbl_df.writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",party_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_individual

# COMMAND ----------

# write merge using individual_df in party_silver.individual_df table
if individual_flag == True:
    try:
        individual_df.writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",individual_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_identity

# COMMAND ----------

# write merge using identity_df in party_silver.identity table
if identity_flag == True:
    try:
        identity_df.writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",identity_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_organisation

# COMMAND ----------

# write merge using organisation_df in party_silver.organisation table
if organisation_flag == True:
    try:
        organisation_df.coalesce(1).writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",organisation_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_electronic_address

# COMMAND ----------

# write merge using party_tbl_df in party_silver.party table
if electronic_flag == True:
    try:
        electronic_df.writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",electronic_address_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
            raise Exception(e)

# COMMAND ----------

# MAGIC %run ./upsert_bank_account

# COMMAND ----------

# write merge using bank_account_df in party_silver.bank_account table
if bank_account_flag == True:
    try:
        bank_account_df.writeStream\
                .trigger(processingTime='60 seconds')\
                .option("checkpointLocation",bank_account_target_checkpointLocation)\
                .foreachBatch(user_mapping_upsert)\
                .start()
    except Exception as e:
        raise Exception(e)

# COMMAND ----------

