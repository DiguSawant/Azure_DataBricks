# Databricks notebook source
# DBTITLE 1,import packages
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %run  ../../../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,import config notebook
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

# DBTITLE 1,import common spark functions notebook
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# DBTITLE 1,import json flatten notebook
# MAGIC %run  ../../../../../tech_utility/json_flatten

# COMMAND ----------

#read data from non_nbm_historical_target_path
try:
    nonnbm_historical_df = read_delta(location = non_nbm_historical_path)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt dt_datavalues
try:
    decrypted_df = nonnbm_historical_df.withColumn(decrypted_column,aes_decrypt(encrypted_column))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert column type from string to json
try:
    decrypted_df = decrypted_df.withColumn(decrypted_column,from_json(decrypted_column,non_nbm_schema))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#flatten the dataframe
try:
    flatten_df = flatten_all_type_json(decrypted_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert values in columns to upper case
try:
    upper_value_df = columnsValue_to_upper_case(flatten_df,[encrypted_column])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

for cols in pii_columns:
    upper_value_df=upper_value_df.withColumn(cols,col(cols).cast(StringType()))


# COMMAND ----------

# encrypt the pii columns
try:
    encrypt_df = encrypt_column(upper_value_df, pii_columns)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#convert columns names to uppercase
try:
    upper_column_df = columnsNames_to_upper_case(encrypt_df)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    renamed_df = upper_column_df.withColumnRenamed("DT_DATAKEY_","DT_DATAKEY")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    renamed_df = renamed_df.withColumn("DT_TS_MS",unix_timestamp())
except Exception as e:
    raise Exception(e)

# COMMAND ----------

try:
    for column,types in target_schema.items():
        renamed_df = renamed_df.withColumn(column,col(column).cast(types))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#write data into non_nbm_intermediate_silver_table_name
try:
    table = database_name + "." + intermediate_table_name
    renamed_df.write.format("delta")\
              .mode("append").option("path",intermediate_external_path)\
              .saveAsTable(table)
except Exception as e:
    raise Exception(e)