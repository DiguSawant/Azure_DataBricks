# Databricks notebook source
import os
env = os.getenv("env").lower()
org_table_name = env + "_party_silver.organisation_silver"

# COMMAND ----------

# DBTITLE 1,running notebook config_non_nbm
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

#select the required column using col_standarization method
try:
    standDf = col_standarization(df = partition_df, columns = organisation_col_standarization)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#create party table dataframe with all columns of party table
try:
    organisation_df = standDf.select(*organisation_col_select).distinct()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# #drop rows if columns value found nul
# try:
#     organisation_df = organisation_df.dropna(subset=[*organisation_drop_cols])
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

# function for scd type-2 using merge
def user_mapping_upsert(microBatchOutputDF, batchId):
    microBatchOutputDF.createOrReplaceTempView("updates")
#     df=microBatchOutputDF._jdf.sparkSession().sql("select * from updates").show()
    microBatchOutputDF._jdf.sparkSession().sql(f"""
MERGE INTO {org_table_name}
USING (
   
  SELECT updates.party_id as mergeKey, updates.*
  FROM updates
  
  UNION ALL
    
  SELECT NULL as mergeKey, updates.*
  FROM updates JOIN {org_table_name}
  ON updates.party_id = {org_table_name}.party_id 
  WHERE {org_table_name}.udh_active_flag = "y"
  
) staged_updates
ON {org_table_name}.party_id = mergeKey
WHEN MATCHED AND {org_table_name}.udh_active_flag = "y" THEN  
  UPDATE SET udh_active_flag = "n", udh_update_date = staged_updates.udh_update_date    
WHEN NOT MATCHED THEN 
  INSERT(party_id,organisation_name,local_organisation_name,organisation_category,establish_date,establish_country_code,udh_active_flag,source_system,udh_insert_date,udh_update_date,dq_flag) 
  VALUES(staged_updates.party_id,staged_updates.organisation_name,staged_updates.local_organisation_name,staged_updates.organisation_category,staged_updates.establish_date,staged_updates.establish_country_code,staged_updates.udh_active_flag,staged_updates.source_system,staged_updates.udh_insert_date,staged_updates.udh_update_date,'pass')""")
