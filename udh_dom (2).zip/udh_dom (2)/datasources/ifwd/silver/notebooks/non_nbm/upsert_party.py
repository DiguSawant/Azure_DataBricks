# Databricks notebook source
# DBTITLE 1,running notebook config_non_nbm
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

import os
env = os.getenv("env").lower()
party_table_name = env + "_party_silver.party_silver"

# COMMAND ----------

#select the required column using col_standarization method
try:
    standDf = col_standarization(df = partition_df, columns = party_col_stand)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#create party table dataframe with all columns of party table
try:
    party_tbl_df = standDf.select(*party_col_select).distinct()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#drop rows if columns value found nul
try:
    party_tbl_df = party_tbl_df.dropna(subset=[*party_drop_cols])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# function for scd type-2 using merge
def user_mapping_upsert(microBatchOutputDF, batchId):
    microBatchOutputDF.createOrReplaceTempView("updates")
#     df=microBatchOutputDF._jdf.sparkSession().sql("select * from updates").show()
    microBatchOutputDF._jdf.sparkSession().sql(f"""
MERGE INTO {party_table_name}
USING (
   
  SELECT updates.party_id as mergeKey, updates.*
  FROM updates
  
  UNION ALL
    
  SELECT NULL as mergeKey, updates.*
  FROM updates JOIN {party_table_name}
  ON updates.party_id = {party_table_name}.party_id 
  WHERE {party_table_name}.udh_active_flag = "y"
  
) staged_updates
ON {party_table_name}.party_id = mergeKey
WHEN MATCHED AND {party_table_name}.udh_active_flag = "y" THEN  
  UPDATE SET udh_active_flag = "n", udh_update_date = staged_updates.udh_update_date    
WHEN NOT MATCHED THEN 
  INSERT(party_id,party_source,party_name,party_type_code,customer_flag,employee_flag,prospect_flag,agent_flag,email_address,udh_active_flag,udh_insert_date,udh_update_date,source_system,dq_flag) 
  VALUES(staged_updates.party_id,staged_updates.party_source,staged_updates.party_name,staged_updates.party_type_code,staged_updates.customer_flag,staged_updates.employee_flag,staged_updates.prospect_flag,staged_updates.agent_flag,staged_updates.email_address,staged_updates.udh_active_flag,staged_updates.udh_insert_date,staged_updates.udh_update_date,staged_updates.source_system,'pass')""")
