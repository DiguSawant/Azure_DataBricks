# Databricks notebook source
import os
env = os.getenv("env").lower()
bank_account_table_name = env+"_party_silver.bank_account_silver"

# COMMAND ----------

# DBTITLE 1,running notebook config_non_nbm
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

#select the required column using col_standarization method
try:
    standDf = col_standarization(df = partition_df, columns = bank_account_col_standarization)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#create party table dataframe with all columns of party table
try:
    bank_account_df = standDf.select(*bank_account_col_select).distinct()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#drop rows if columns value found nul
try:
    bank_account_df = bank_account_df.dropna(subset=[*bank_account_drop_cols])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# function for scd type-2 using merge
def user_mapping_upsert(microBatchOutputDF, batchId):
    microBatchOutputDF.createOrReplaceTempView("updates")
#     df=microBatchOutputDF._jdf.sparkSession().sql("select * from updates").show()
    microBatchOutputDF._jdf.sparkSession().sql(f"""
MERGE INTO {bank_account_table_name}
USING (
   
  SELECT updates.party_id as mergeKey, updates.*
  FROM updates
  
  UNION ALL
    
  SELECT NULL as mergeKey, updates.*
  FROM updates JOIN {bank_account_table_name}
  ON updates.party_id = {bank_account_table_name}.party_id 
  WHERE {bank_account_table_name}.udh_active_flag = "y"
  
) staged_updates
ON {bank_account_table_name}.party_id = mergeKey
WHEN MATCHED AND {bank_account_table_name}.udh_active_flag = "y" THEN  
  UPDATE SET udh_active_flag = "n", udh_update_date = staged_updates.udh_update_date    
WHEN NOT MATCHED THEN 
  INSERT(party_id,bank_account_number,bank_code,bank_name,bank_branch_code,bank_account_name,bank_account_type,main_currency,udh_active_flag,udh_insert_date,udh_update_date,source_system,dq_flag) 
  VALUES(staged_updates.party_id,staged_updates.bank_account_number,staged_updates.bank_code,staged_updates.bank_name,staged_updates.bank_branch_code,staged_updates.bank_account_name,staged_updates.bank_account_type,staged_updates.main_currency,staged_updates.udh_active_flag,staged_updates.udh_insert_date,staged_updates.udh_update_date,staged_updates.source_system,'pass')""")
