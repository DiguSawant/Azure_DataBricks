# Databricks notebook source
import os
env = os.getenv("env").lower()
individual_table_name = env + "_party_silver.individual_silver"

# COMMAND ----------

# DBTITLE 1,running notebook config_non_nbm
# MAGIC %run ../../../config/config_nonnbm_silver

# COMMAND ----------

#select the required column using col_standarization method
try:
    standDf = col_standarization(df = partition_df, columns = individual_col_standarization)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#create individual_df table dataframe with all columns of individual_df table
try:
    individual_df = standDf.select(*individual_col_select).distinct()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#drop rows if columns value found nul
try:
    individual_df = individual_df.dropna(subset=[*individual_drop_cols])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# function for scd type-2 using merge
def user_mapping_upsert(microBatchOutputDF, batchId):
    microBatchOutputDF.createOrReplaceTempView("updates")
#     df=microBatchOutputDF._jdf.sparkSession().sql("select * from updates").show()
    microBatchOutputDF._jdf.sparkSession().sql(f"""
MERGE INTO {individual_table_name}
USING (
   
  SELECT updates.party_id as mergeKey, updates.*
  FROM updates
  
  UNION ALL
    
  SELECT NULL as mergeKey, updates.*
  FROM updates JOIN {individual_table_name}
  ON updates.party_id = {individual_table_name}.party_id 
  WHERE {individual_table_name}.udh_active_flag = "y"
  
) staged_updates
ON {individual_table_name}.party_id = mergeKey
WHEN MATCHED AND {individual_table_name}.udh_active_flag = "y" THEN  
  UPDATE SET udh_active_flag = "n", udh_update_date = staged_updates.udh_update_date    
WHEN NOT MATCHED THEN 
  INSERT(party_id,full_name,first_name,middle_name,last_name,local_full_name,local_first_name,local_middle_name,local_last_name,salutation,occupation,occupation_class,annual_income,gender_code,birth_date,birth_place,nationality_code,marital_status_code,language_code,death_date,udh_active_flag,source_system,udh_insert_date,udh_update_date,dq_flag) 
  VALUES(staged_updates.party_id,staged_updates.full_name,staged_updates.first_name,staged_updates.middle_name,staged_updates.last_name,staged_updates.local_full_name,staged_updates.local_first_name,staged_updates.local_middle_name,staged_updates.local_last_name,staged_updates.salutation,staged_updates.occupation,staged_updates.occupation_class,staged_updates.annual_income,staged_updates.gender_code,staged_updates.birth_date,staged_updates.birth_place,staged_updates.nationality_code,staged_updates.marital_status_code,staged_updates.language_code,staged_updates.death_date,staged_updates.udh_active_flag,staged_updates.source_system,staged_updates.udh_insert_date,staged_updates.udh_update_date,'pass')""")
