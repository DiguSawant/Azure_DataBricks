# Databricks notebook source
# MAGIC %md
# MAGIC # Silver layer Notebooks

# COMMAND ----------

1. The scripts that are used for the silver layer