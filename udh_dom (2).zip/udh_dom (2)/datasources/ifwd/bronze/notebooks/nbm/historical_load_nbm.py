# Databricks notebook source
# DBTITLE 1,Importing common functions
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../../../../../tech_utility/aes

# COMMAND ----------

# DBTITLE 1,Importing config 
# MAGIC %run ../../../config/config_nbm_bronze

# COMMAND ----------

# MAGIC
# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

minus_2_time = timeinbankok - timedelta(hours=0, minutes=3)
minus_2_time = minus_2_time.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# try:
#     # query to get data from Users_Data
#     query=f""" (select  * from NBM_FE_UAT.dbo.Users_Data where Submitted_Date  >= '{minus_2_time}') as usersdata """
    

#     # gat minimum and maximum partition column from table
#     min_max_query = f"""SELECT MIN({partitionColumn}) as min, MAX({partitionColumn}) as max FROM {config["tablename"]}"""
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

try:
    # query to get data from Users_Data
    query=""" (select  * from NBM_FE_UAT.dbo.Users_Data where Submitted_Date  >= '2023-04-18' and 
               Submitted_Date  <= '2023-04-26 14:04:57') as usersdata """

    # gat minimum and maximum partition column from table
    min_max_query = f"""SELECT MIN({partitionColumn}) as min, MAX({partitionColumn}) as max FROM {config["tablename"]}"""
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read data from database using read_from_MSSQL
try:
    min_max_df = read_from_MSSQL(host = host,\
                                port = port,\
                                database_name = database_name,\
                                user_id = user_id,\
                                password = password,\
                                numPartitions = numPartitions,\
                                query = min_max_query,\
                                table = None,\
                                lowerBound = None,\
                                upperBound = None,\
                                partitionColumn = None)
    lowerBound, upperBound = min_max_df.collect()[0]
except Exception as e:
    raise Exception(e)


# COMMAND ----------

# DBTITLE 1,Reading the data from the source system
# read data from database
try:
    nbm_df = read_from_MSSQL(host = host,\
                            port = port,\
                            database_name = database_name,\
                            user_id = user_id,\
                            password = password,\
                            numPartitions = numPartitions,\
                            table = query,\
                            lowerBound = lowerBound,\
                            upperBound = upperBound,\
                            partitionColumn = partitionColumn)
except Exception as e:
    raise Exception(e)


# COMMAND ----------

# filter Email_Address 
try:
    nbm_df = nbm_df.filter(col("Email_Address").isNotNull())
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append column for partition
try:
    nbm_df = nbm_df.withColumn("udh_source_sys",lit('nbm'))\
                                .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType()))\
                                .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,encrypting the Json_Data column
# encrypt pii columns
try:
    nbm_df_encrypted = encrypt_column(nbm_df,["Json_Data"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------


# write data into give location
try:
    nbm_df_encrypted.write.format("delta")\
                    .option("path", target_path)\
                    .option("partitionBy","udh_batch_id")\
                    .mode("append")\
                    .saveAsTable(bronze_table)
except Exception as e:
    raise Exception(e)