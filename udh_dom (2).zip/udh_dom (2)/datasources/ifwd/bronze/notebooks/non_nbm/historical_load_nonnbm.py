# Databricks notebook source
# DBTITLE 1,Running common funtions notebook
# MAGIC %run ../../../../../tech_utility/common_functions

# COMMAND ----------

# MAGIC %run ../../../config/config_nonnbm_bronze

# COMMAND ----------

# MAGIC %run ../../../../../tech_utility/aes

# COMMAND ----------

# MAGIC
# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

minus_2_time=timeinbankok - timedelta(hours=0, minutes=3)
minus_2_time=minus_2_time.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# try:
#     # query to join nosqldata and nosqlentity for batch load
#     query = f""" ( select   a.entityseq as et_entityseq,a.entityname as et_entityname,a.indexkey as et_indexkey,a.sortkey as et_sortkey,a.versionid as  et_versionid ,a.guid as et_guid  ,a.application as  et_application,a.systemcreateddt as et_systemcreateddt ,a.systemupdateddt as et_systemupdateddt,b.dataseq as dt_dataseq,b.entityseq as dt_entityseq,b.datakey as dt_datakey_,b.datavalue as dt_datavalue ,b.versionid as dt_versionid,b.guid as dt_guid
#       from JEEFramework_La.dbo.NOSQLENTITY a, JEEFramework_La.dbo.NOSQLDATA b where  a.ENTITYSEQ = b.ENTITYSEQ and a.SYSTEMUPDATEDDT  > '{minus_2_time}') as non_nbm  """

#     # get minium and maximum entityseq from nosqldata
#     min_max_query = f"""SELECT MIN(ENTITYSEQ) as min, MAX(ENTITYSEQ) as max FROM dbo.NOSQLDATA"""
# except Exception as e:
#     raise Exception(e)

# COMMAND ----------

try:
    # query to join nosqldata and nosqlentity for batch load
    query = """ ( select a.entityseq as et_entityseq,a.entityname as et_entityname,a.indexkey as et_indexkey,a.sortkey as et_sortkey,a.versionid as  et_versionid ,a.guid as et_guid  ,a.application as  et_application,a.systemcreateddt as et_systemcreateddt ,a.systemupdateddt as et_systemupdateddt,b.dataseq as dt_dataseq,b.entityseq as dt_entityseq,b.datakey as dt_datakey_,b.datavalue as dt_datavalue ,b.versionid as dt_versionid,b.guid as dt_guid
      from JEEFramework_La.dbo.NOSQLENTITY a, JEEFramework_La.dbo.NOSQLDATA b where  a.ENTITYSEQ = b.ENTITYSEQ and a.SYSTEMUPDATEDDT  > '2023-03-10 13:10:00' and SYSTEMUPDATEDDT  <= '2023-04-05 13:10:00') as abc  """

    # get minium and maximum entityseq from nosqldata
    min_max_query =f"""SELECT MIN(entityseq) as min, MAX(entityseq) as max FROM {config["tablename"]}"""
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read data from source using read_from_MSSQL
try:
    min_max_df = read_from_MSSQL(host = host,
                                port = port,
                                database_name = database_name,
                                user_id = user_id,
                                password = password,
                                numPartitions = numPartitions,
                                query = min_max_query,
                                table = None,
                                lowerBound = None,
                                upperBound = None,
                                partitionColumn = None)

    # get lowerBound and upperBound for partition
    lowerBound, upperBound = min_max_df.collect()[0]
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# read data from database
try:
    jdbc_df = read_from_MSSQL(
                         host = host,\
                         port = port,\
                         database_name = database_name,\
                         user_id = user_id,\
                         password = password,\
                         numPartitions = numPartitions,\
                         table = query,
                         lowerBound = lowerBound,
                         upperBound = upperBound,
                         partitionColumn = config["partitionColumn"])
except Exception as e:
    raise Exception(e)


# COMMAND ----------

# DBTITLE 1,Encryption of PII-Columns
# encrypt the pii columns
try:
    encrypt_df = encrypt_column(jdbc_df,["dt_datavalue"])
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append audit columns
try:
    partition_df = encrypt_df.withColumn("udh_source_sys",lit('non_nbm'))\
                            .withColumn("udh_insert_timestamp",current_timestamp())\
                            .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Writing into bronze table

# write data into bronze layer
try:
    partition_df.write.format("delta")\
                .partitionBy("udh_batch_id")\
                .mode("append")\
                .option("path",target_path)\
                .saveAsTable(bronze_table)
    
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# # write data into bronze layer
# try:
#     df.write.format("delta")\
#                 .partitionBy("udh_batch_id")\
#                 .mode("append")\
#                 .option("path","/mnt/fwd_test/prashant_dev_1/telesales/bronze_data/")\
#                 .saveAsTable("dev_silver.telesales_stream")
    
# except Exception as e:
#     raise Exception(e)