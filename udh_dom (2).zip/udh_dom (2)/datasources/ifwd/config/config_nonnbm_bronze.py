# Databricks notebook source
import os
env = os.getenv("env").lower()
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %run ../../../tech_utility/secret_key_env_param

# COMMAND ----------

databaseconfig={
    "nonnbm":
{"host":"10.16.95.80",
"port":"1433",
"username":secret["producer.symbiosis.db.user"],
"password":secret["producer.symbiosis.db.password"],
"database_name":"JEEFramework_La",
"tablename":"dbo.NOSQLDATA",
"numPartitions" : 3,
"partitionColumn" : "et_entityseq",
"initial_bronze_non_nbm_table_name":f"{env}_initial_load_bronze.nosql_data_entity_bronze",
"non_nbm_historical_target_path":f"{path_prefix}/bronze/initial_load/initial_load_nosql_data_entity/"
}
}

# COMMAND ----------

# assign the vaiables
config = databaseconfig["nonnbm"]
partitionColumn = config["partitionColumn"]
table = config["tablename"]
host = config["host"]
port = config["port"]
database_name = config["database_name"]
user_id = config["username"]
password = config["password"]
numPartitions = config["numPartitions"]
target_path = config["non_nbm_historical_target_path"]
bronze_table = config["initial_bronze_non_nbm_table_name"]