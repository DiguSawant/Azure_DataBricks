# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze layer Notebooks

# COMMAND ----------

1. The scripts that are used for the common config for bronze layer