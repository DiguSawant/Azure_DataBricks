# Databricks notebook source
import os
env = os.getenv("env").lower()
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %run ../../../tech_utility/secret_key_env_param

# COMMAND ----------

databaseconfig={
"nbm":
{"host":"cathdbs00008.cgwhadxwjpnk.ap-southeast-1.rds.amazonaws.com",
"port":"48000",
"username":secret["producer.nbm_big3.db.user"],
"password":secret["producer.nbm_big3.db.password"],
"database_name":"NBM_FE_UAT",
"tablename":"dbo.Users_Data",
"partitionColumn" : "ID",
"numPartitions":3,
"initial_bronze_nbm_table_name":f"{env}_initial_load_bronze.users_data",
"nbm_historical_target_path":f"{path_prefix}/bronze/initial_load/initial_load_users_data/"
}
}

# COMMAND ----------

# assign the variables
config = databaseconfig["nbm"]
partitionColumn = config["partitionColumn"]
table = config["tablename"]
host = config["host"]
port = config["port"]
database_name = config["database_name"]
user_id = config["username"]
password = config["password"]
numPartitions = config["numPartitions"]
target_path = config["nbm_historical_target_path"]
bronze_table = config["initial_bronze_nbm_table_name"]