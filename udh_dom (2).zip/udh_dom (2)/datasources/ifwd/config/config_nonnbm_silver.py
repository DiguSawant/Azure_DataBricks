# Databricks notebook source
from pyspark.sql.types import *

# COMMAND ----------

import os
env = os.getenv("env").lower()
env = 'dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

#config for non_nbm with nosqldata and nosqlentity objects
config_non_nbm =  {
    "nosql_data": { 
     "s3_path": path_prefix + f"/bronze/ifwd/jeeframwork/TH.{u_env}.ODS.IFWD.dbo.NOSQLDATA/",
     "schemalocation_path": path_prefix + "/silver/schema/nosqldata_1/",
	  "column_schema":StructType([StructField('DATAKEY',StringType(),True),StructField('DATASEQ',StringType(),True),StructField('DATAVALUE',StringType(),True),StructField('ENTITYSEQ',StringType(),True),StructField('GUID',StringType(),True),StructField('VERSIONID',StringType(),True)]),
      "non_nbm_schema": StructType([StructField('addresses', StructType([StructField('current', StructType([StructField('district', StringType(), True), StructField('houseNumber', StringType(), True),StructField('village', StringType(), True), StructField('province', StringType(), True), StructField('road', StringType(), True), StructField('subDistrict', StringType(), True), StructField('zip', StringType(), True)]), True), StructField('documentAddressType', StringType(), True), StructField('workplace', StructType([StructField('district', StringType(), True), StructField('houseNumber', StringType(), True),StructField('village', StringType(), True), StructField('province', StringType(), True), StructField('road', StringType(), True), StructField('subDistrict', StringType(), True), StructField('zip', StringType(), True)]), True), StructField('home', StructType([StructField('district', StringType(), True), StructField('houseNumber', StringType(), True),StructField('village', StringType(), True), StructField('province', StringType(), True), StructField('road', StringType(), True), StructField('subDistrict', StringType(), True), StructField('zip', StringType(), True)]), True),StructField('workplaceName', StringType(), True),StructField('workplaceCountry', StringType(), True)]), True), StructField('aml', StructType([StructField('isPass', BooleanType(), True), StructField('isVerified', BooleanType(), True)]), True), StructField('beneficiary', StructType([StructField('beneficiaries', ArrayType(StructType([StructField('fullName', StringType(), True), StructField('index', StringType(), True), StructField('percentage', StringType(), True), StructField('relation', StringType(), True)]), True), True), StructField('benefitType', StringType(), True)]), True), StructField('consentCheckCd', ArrayType(StructType([StructField('key', StringType(), True), StructField('type', StringType(), True), StructField('value', StringType(), True)]), True), True), StructField('dataConsentTime', StringType(), True), StructField('deliverMode', StringType(), True), StructField('documentMode', StringType(), True), StructField('expireTime', StringType(), True), StructField('health', StructType([StructField('hasOtherInsurance', BooleanType(), True), StructField('height', StringType(), True), StructField('weight', StringType(), True)]), True), StructField('icp', StructType([StructField('accountName', StringType(), True), StructField('accountNumber', StringType(), True), StructField('bankName', StringType(), True)]), True), StructField('identity', StructType([StructField('cardExpireDate', StringType(), True), StructField('idCard', StringType(), True), StructField('laserId', StringType(), True)]), True), StructField('identityStatus', StringType(), True), StructField('isFatcaPass', BooleanType(), True), StructField('isInsureTechEnable', BooleanType(), True), StructField('isOtpVerify', BooleanType(), True), StructField('isPaymentComplete', BooleanType(), True), StructField('isSCBUserUpdatedMobile', BooleanType(), True), StructField('isTaxConsent', BooleanType(), True), StructField('partner', StringType(), True), StructField('paymentRecurring', BooleanType(), True), StructField('paymentType', StringType(), True), StructField('policyHolder', StructType([StructField('email', StringType(), True), StructField('firstName', StringType(), True), StructField('jobGroup', StringType(), True), StructField('jobName', StringType(), True), StructField('lastName', StringType(), True), StructField('mobileNumber', StringType(), True), StructField('status', StringType(), True), StructField('title', StringType(), True)]), True), StructField('policyNumber', StringType(), True), StructField('premiumInfo', StructType([StructField('baseAnnualPremium', StringType(), True), StructField('birthDate', StringType(), True), StructField('ehealthSelected', StructType([StructField('basePackage', StructType([StructField('packagePrice', StringType(), True), StructField('planCode', StringType(), True), StructField('premium', StringType(), True), StructField('productPlanOptionCd', StringType(), True), StructField('sumAssured', StringType(), True)]), True), StructField('ciPackage', StringType(), True), StructField('mainPackage', StructType([StructField('planCode', StringType(), True), StructField('premium', StringType(), True), StructField('sumAssured', StringType(), True)]), True), StructField('opdPackage', StringType(), True), StructField('sumPremium', StringType(), True)]), True), StructField('gender', StringType(), True), StructField('packagePrice', StringType(), True), StructField('paymentMode', StringType(), True), StructField('premium', StringType(), True), StructField('premiumDiscount', StructType([StructField('MONTHLY', StructType([StructField('annualizedModalPremium', StringType(), True), StructField('modalPremium', StringType(), True)]), True), StructField('YEARLY', StructType([StructField('annualizedModalPremium', StringType(), True), StructField('modalPremium', StringType(), True)]), True), StructField('discountType', StringType(), True), StructField('discountValue', DoubleType(), True), StructField('premium', StringType(), True)]), True), StructField('productPlanOptionCd', StringType(), True), StructField('sumAssured', StringType(), True)]), True), StructField('productId', StringType(), True), StructField('promoCode', StringType(), True), StructField('referenceId', StringType(), True), StructField('submitPayment', BooleanType(), True), StructField('utmTracking', StructType([StructField('flowId', StringType(), True), StructField('utmCampaign', StringType(), True), StructField('utmContent', StringType(), True), StructField('utmMedium', StringType(), True), StructField('utmSource', StringType(), True), StructField('utmSrc', StringType(), True), StructField('utmTerm', StringType(), True), StructField('uuid', StringType(), True)]), True)])
    },
    "nosql_entity": {
      "s3_path": path_prefix + f"/bronze/ifwd/jeeframwork/TH.{u_env}.ODS.IFWD.dbo.NOSQLENTITY/",
      "schemalocation_path": path_prefix + "/silver_intermediate/schema/nosqlentity/",
      "column_schema":StructType([StructField('APPLICATION',StringType(),True),StructField('ENTITYNAME',StringType(),True),StructField('ENTITYSEQ',StringType(),True),StructField('GUID',StringType(),True),StructField('INDEXKEY',StringType(),True),StructField('SORTKEY',StringType(),True),StructField('SYSTEMCREATEDDT',StringType(),True),StructField('SYSTEMUPDATEDDT',StringType(),True),StructField('VERSIONID',StringType(),True)])
    },
     "flatten_column": "after",
      "encrypted_column": "dt_datavalue",
      "select_cols": "*",
      "decrypted_column": "datavalue",
    "database_name":env + "_silver",
    "intermediate_table":"nosql_data_entity_silver",
    "non_nbm_historical_path": path_prefix +"/bronze/initial_load/initial_load_nosql_data_entity/",
    "intermediate_checkpoint_path": path_prefix + "/silver/checkpoint/nosql_data_entity_1/",
     "intermediate_target_path": path_prefix + "/silver/nosql_data_entity/",
    "party_flag":True,
    "individual_flag":True,
    "identity_flag":True,
    "organisation_flag":True,
    "electronic_flag":True,
    "bank_account_flag":True,
    "pii_columns":["dt_entityseq","datavalue_policyHolder_firstName","datavalue_policyHolder_lastName","datavalue_policyHolder_title","datavalue_policyHolder_jobName","datavalue_policyHolder_jobGroup","datavalue_premiumInfo_gender","datavalue_premiumInfo_birthDate","datavalue_policyHolder_status","datavalue_policyHolder_mobileNumber","datavalue_identity_idCard","datavalue_policyHolder_email","datavalue_icp_accountNumber","datavalue_icp_accountName","datavalue_addresses_current_province","datavalue_addresses_current_zip","datavalue_addresses_current_houseNumber","datavalue_addresses_current_village","datavalue_addresses_current_road","datavalue_addresses_current_subDistrict","datavalue_addresses_current_district","datavalue_addresses_workplace_province","datavalue_addresses_workplace_zip","datavalue_addresses_workplace_houseNumber","datavalue_addresses_workplace_village","datavalue_addresses_workplace_road","datavalue_addresses_workplace_subDistrict","datavalue_addresses_workplace_district","datavalue_addresses_home_province","datavalue_addresses_home_zip","datavalue_addresses_home_houseNumber","datavalue_addresses_home_village","datavalue_addresses_home_road","datavalue_addresses_home_subDistrict","datavalue_addresses_home_district"]
}

# COMMAND ----------

target_schema={'DT_DATAKEY': 'string', 'DT_DATASEQ': 'string', 'DT_DATAVALUE': 'string', 'DT_ENTITYSEQ': 'string', 'DT_GUID': 'string', 'DT_VERSIONID': 'string', 'DT_TS_MS': 'timestamp', 'ET_APPLICATION': 'string', 'ET_ENTITYNAME': 'string', 'ET_ENTITYSEQ': 'string', 'ET_GUID': 'string', 'ET_INDEXKEY': 'string', 'ET_SORTKEY': 'string', 'ET_SYSTEMCREATEDDT': 'string', 'ET_SYSTEMUPDATEDDT': 'string', 'ET_VERSIONID': 'string', 'DATAVALUE_DATACONSENTTIME': 'string', 'DATAVALUE_DELIVERMODE': 'string', 'DATAVALUE_DOCUMENTMODE': 'string', 'DATAVALUE_EXPIRETIME': 'string', 'DATAVALUE_IDENTITYSTATUS': 'string', 'DATAVALUE_ISFATCAPASS': 'boolean', 'DATAVALUE_ISINSURETECHENABLE': 'boolean', 'DATAVALUE_ISOTPVERIFY': 'boolean', 'DATAVALUE_ISPAYMENTCOMPLETE': 'boolean', 'DATAVALUE_ISSCBUSERUPDATEDMOBILE': 'boolean', 'DATAVALUE_ISTAXCONSENT': 'boolean', 'DATAVALUE_PARTNER': 'string', 'DATAVALUE_PAYMENTRECURRING': 'boolean', 'DATAVALUE_PAYMENTTYPE': 'string', 'DATAVALUE_POLICYNUMBER': 'string', 'DATAVALUE_PRODUCTID': 'string', 'DATAVALUE_PROMOCODE': 'string', 'DATAVALUE_REFERENCEID': 'string', 'DATAVALUE_SUBMITPAYMENT': 'boolean', 'DATAVALUE_ADDRESSES_DOCUMENTADDRESSTYPE': 'string', 'DATAVALUE_ADDRESSES_WORKPLACENAME': 'string', 'DATAVALUE_ADDRESSES_WORKPLACECOUNTRY': 'string', 'DATAVALUE_AML_ISPASS': 'boolean', 'DATAVALUE_AML_ISVERIFIED': 'boolean', 'DATAVALUE_BENEFICIARY_BENEFITTYPE': 'string', 'DATAVALUE_CONSENTCHECKCD_KEY': 'string', 'DATAVALUE_CONSENTCHECKCD_TYPE': 'string', 'DATAVALUE_CONSENTCHECKCD_VALUE': 'string', 'DATAVALUE_HEALTH_HASOTHERINSURANCE': 'boolean', 'DATAVALUE_HEALTH_HEIGHT': 'string', 'DATAVALUE_HEALTH_WEIGHT': 'string', 'DATAVALUE_ICP_ACCOUNTNAME': 'string', 'DATAVALUE_ICP_ACCOUNTNUMBER': 'string', 'DATAVALUE_ICP_BANKNAME': 'string', 'DATAVALUE_IDENTITY_CARDEXPIREDATE': 'string', 'DATAVALUE_IDENTITY_IDCARD': 'string', 'DATAVALUE_IDENTITY_LASERID': 'string', 'DATAVALUE_POLICYHOLDER_EMAIL': 'string', 'DATAVALUE_POLICYHOLDER_FIRSTNAME': 'string', 'DATAVALUE_POLICYHOLDER_JOBGROUP': 'string', 'DATAVALUE_POLICYHOLDER_JOBNAME': 'string', 'DATAVALUE_POLICYHOLDER_LASTNAME': 'string', 'DATAVALUE_POLICYHOLDER_MOBILENUMBER': 'string', 'DATAVALUE_POLICYHOLDER_STATUS': 'string', 'DATAVALUE_POLICYHOLDER_TITLE': 'string', 'DATAVALUE_PREMIUMINFO_BASEANNUALPREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_BIRTHDATE': 'string', 'DATAVALUE_PREMIUMINFO_GENDER': 'string', 'DATAVALUE_PREMIUMINFO_PACKAGEPRICE': 'string', 'DATAVALUE_PREMIUMINFO_PAYMENTMODE': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_PRODUCTPLANOPTIONCD': 'string', 'DATAVALUE_PREMIUMINFO_SUMASSURED': 'string', 'DATAVALUE_UTMTRACKING_FLOWID': 'string', 'DATAVALUE_UTMTRACKING_UTMCAMPAIGN': 'string', 'DATAVALUE_UTMTRACKING_UTMCONTENT': 'string', 'DATAVALUE_UTMTRACKING_UTMMEDIUM': 'string', 'DATAVALUE_UTMTRACKING_UTMSOURCE': 'string', 'DATAVALUE_UTMTRACKING_UTMSRC': 'string', 'DATAVALUE_UTMTRACKING_UTMTERM': 'string', 'DATAVALUE_UTMTRACKING_UUID': 'string', 'DATAVALUE_ADDRESSES_CURRENT_DISTRICT': 'string', 'DATAVALUE_ADDRESSES_CURRENT_HOUSENUMBER': 'string', 'DATAVALUE_ADDRESSES_CURRENT_VILLAGE': 'string', 'DATAVALUE_ADDRESSES_CURRENT_PROVINCE': 'string', 'DATAVALUE_ADDRESSES_CURRENT_ROAD': 'string', 'DATAVALUE_ADDRESSES_CURRENT_SUBDISTRICT': 'string', 'DATAVALUE_ADDRESSES_CURRENT_ZIP': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_DISTRICT': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_HOUSENUMBER': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_VILLAGE': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_PROVINCE': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_ROAD': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_SUBDISTRICT': 'string', 'DATAVALUE_ADDRESSES_WORKPLACE_ZIP': 'string', 'DATAVALUE_ADDRESSES_HOME_DISTRICT': 'string', 'DATAVALUE_ADDRESSES_HOME_HOUSENUMBER': 'string', 'DATAVALUE_ADDRESSES_HOME_VILLAGE': 'string', 'DATAVALUE_ADDRESSES_HOME_PROVINCE': 'string', 'DATAVALUE_ADDRESSES_HOME_ROAD': 'string', 'DATAVALUE_ADDRESSES_HOME_SUBDISTRICT': 'string', 'DATAVALUE_ADDRESSES_HOME_ZIP': 'string', 'DATAVALUE_BENEFICIARY_BENEFICIARIES_FULLNAME': 'string', 'DATAVALUE_BENEFICIARY_BENEFICIARIES_INDEX': 'string', 'DATAVALUE_BENEFICIARY_BENEFICIARIES_PERCENTAGE': 'string', 'DATAVALUE_BENEFICIARY_BENEFICIARIES_RELATION': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_CIPACKAGE': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_OPDPACKAGE': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_SUMPREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_DISCOUNTTYPE': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_DISCOUNTVALUE': 'double', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_PREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_BASEPACKAGE_PACKAGEPRICE': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_BASEPACKAGE_PLANCODE': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_BASEPACKAGE_PREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_BASEPACKAGE_PRODUCTPLANOPTIONCD': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_BASEPACKAGE_SUMASSURED': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_MAINPACKAGE_PLANCODE': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_MAINPACKAGE_PREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_EHEALTHSELECTED_MAINPACKAGE_SUMASSURED': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_MONTHLY_ANNUALIZEDMODALPREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_MONTHLY_MODALPREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_YEARLY_ANNUALIZEDMODALPREMIUM': 'string', 'DATAVALUE_PREMIUMINFO_PREMIUMDISCOUNT_YEARLY_MODALPREMIUM': 'string', 'UDH_SOURCE_SYS': 'string', 'UDH_INSERT_TIMESTAMP': 'timestamp', 'UDH_BATCH_ID': 'string'}

# COMMAND ----------

# assign the config variables
nosqldata_s3_path = config_non_nbm['nosql_data']['s3_path']
nosqldata_schemalocation = config_non_nbm['nosql_data']['schemalocation_path']
nosqldata_column_schema = config_non_nbm['nosql_data']['column_schema']
non_nbm_schema = config_non_nbm['nosql_data']['non_nbm_schema']
nosqlentity_s3_path = config_non_nbm['nosql_entity']['s3_path']
nosqlentity_schemalocation = config_non_nbm['nosql_entity']['schemalocation_path']
nosqlentity_column_schema = config_non_nbm['nosql_entity']['column_schema']
flatten_column = config_non_nbm['flatten_column']
encrypted_column = config_non_nbm['encrypted_column']
select_cols = config_non_nbm['select_cols']
decrypted_column = config_non_nbm['decrypted_column']
database_name = config_non_nbm['database_name']
intermediate_table_name = config_non_nbm['intermediate_table']
non_nbm_historical_path = config_non_nbm['non_nbm_historical_path']
intermediate_checkpoint_path = config_non_nbm['intermediate_checkpoint_path']
intermediate_external_path = config_non_nbm['intermediate_target_path']
party_flag = config_non_nbm['party_flag']
individual_flag = config_non_nbm['individual_flag']
identity_flag = config_non_nbm['identity_flag']
organisation_flag = config_non_nbm['organisation_flag']
electronic_flag = config_non_nbm['electronic_flag']
bank_account_flag = config_non_nbm['bank_account_flag']
pii_columns = config_non_nbm['pii_columns']

# COMMAND ----------

#config for party table
party_table = {
        "database_name":env + "_party_silver",
		"target_table":"party_silver",
		"partition_column":"source_system",
		"target_checkpointLocation":path_prefix + "/silver/customer/party_silver/party/checkpoint/",
        "col_stand":
    {
		"party_id":"dt_entityseq",
		"party_source":"'ecom'",
		"party_name":"concat_ws(' ',datavalue_policyHolder_firstName,datavalue_policyHolder_lastName)",
		"party_type_code":"'individual'",
		"customer_flag":"'y'",
		"employee_flag":"'n'",
		"prospect_flag":"'n'",
		"agent_flag":"'n'",
		"email_address":"datavalue_policyHolder_email",
		"udh_active_flag":"'y'",
		"source_system":"'ifwd'",
		"udh_insert_date":"current_timestamp()",
		"udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,party_source,party_name,party_type_code,customer_flag,employee_flag,prospect_flag,agent_flag,email_address,udh_active_flag,source_system,udh_insert_date,udh_update_date",
    "pii_column":[],
    "drop_cols":["party_name","email_address"]
	}

# COMMAND ----------

#extracting the config for party_table object
party_database_name = party_table['database_name']
party_target_table = party_table['target_table']
party_partition_column = party_table['partition_column']
party_target_checkpointLocation = party_table['target_checkpointLocation']
party_col_stand = party_table['col_stand']
party_col_select = party_table['col_sel'].split(",")
party_pii_columns = party_table['pii_column']
party_drop_cols = party_table['drop_cols']

# COMMAND ----------

#config for individual table
individual_table = {
    "database_name":env + "_party_silver",
		"target_table":"individual_silver",
		"partition_column":"source_system",
		"target_checkpointLocation":path_prefix + "/silver/customer/party_silver/individual/checkpoint/",
    "col_stand":
    {
    "party_id":"dt_entityseq",
    "full_name":"concat_ws(' ',datavalue_policyHolder_firstName,datavalue_policyHolder_lastName)",
    "first_name":"datavalue_policyHolder_firstName",
    "middle_name":"'null'",
    "last_name":"datavalue_policyHolder_lastName",
    "local_full_name":"'null'",
    "local_first_name":"'null'",
    "local_middle_name":"'null'",
    "local_last_name":"'null'",
    "salutation":"datavalue_policyHolder_title",
    "occupation":"datavalue_policyHolder_jobName",
    "occupation_class":"datavalue_policyHolder_jobGroup",
    "annual_income":"'null'",
    "gender_code":"datavalue_premiumInfo_gender",
    "birth_date":"datavalue_premiumInfo_birthDate",
    "birth_place":"'null'",
    "nationality_code":"'null'",
    "marital_status_code":"datavalue_policyHolder_status",
    "language_code":"'null'",
    "death_date":"null",
    "udh_active_flag":"'y'",
    "source_system":"'ifwd'",
    "udh_insert_date":"current_timestamp()",
    "udh_update_date":"current_timestamp()",
  },
    "col_sel":"party_id,full_name,first_name,middle_name,last_name,local_full_name,local_first_name,local_middle_name,local_last_name,salutation,occupation,occupation_class,annual_income,gender_code,birth_date,birth_place,nationality_code,marital_status_code,language_code,death_date,udh_active_flag,source_system,udh_insert_date,udh_update_date",
 "pii_column":[],
  "drop_cols":["full_name", "first_name", "middle_name", "last_name", "salutation", "occupation", "occupation_class", "gender_code", "birth_date", "marital_status_code"]
}

# COMMAND ----------

#extracting the individual_table for party_table object
individual_database_name = individual_table['database_name']
individual_target_table = individual_table['target_table']
individual_partition_column = individual_table['partition_column']
individual_target_checkpointLocation = individual_table['target_checkpointLocation']
individual_col_standarization = individual_table['col_stand']
individual_col_select = individual_table['col_sel'].split(",")
individual_pii_columns = individual_table['pii_column']
individual_drop_cols = individual_table['drop_cols']

# COMMAND ----------

#config for identity table
identity_table = {
       "database_name":env + "_party_silver",
		"target_table":"identity_silver",
		"partition_column":"source_system",
		"target_checkpointLocation":path_prefix + "/silver/customer/party_silver/identity/checkpoint/",
    "col_stand":
    {
    "party_id":"dt_entityseq",
    "ident_type":"'null'",
    "ident_number":"datavalue_identity_idCard",
    "ident_issue_country":"'null'",
    "ident_expiry_date":"datavalue_identity_cardExpireDate",
    "udh_active_flag":"'y'",
    "source_system":"'ifwd'",
    "udh_insert_date":"current_timestamp()",
    "udh_update_date":"current_timestamp()"   
    },
    "col_sel":"party_id,ident_type,ident_number,ident_issue_country,ident_expiry_date,udh_active_flag,source_system,udh_insert_date,udh_update_date",
   "pii_column":[],
    "drop_cols":["ident_number", "ident_expiry_date"]
} 

# COMMAND ----------

#extracting the identity_table from config table
identity_database_name = identity_table['database_name']
identity_target_table = identity_table['target_table']
identity_partition_column = identity_table['partition_column']
identity_target_checkpointLocation = identity_table['target_checkpointLocation']
identity_col_standarization = identity_table['col_stand']
identity_col_select = identity_table['col_sel'].split(",")
identity_pii_column = identity_table['pii_column']
identity_drop_cols = identity_table['drop_cols']

# COMMAND ----------

#config for electronic table
electronic_address_table = {
        "database_name":env + "_party_silver",
		"target_table":"electronic_address_silver",
		"partition_column":"source_system",
		"target_checkpointLocation":path_prefix + "/silver/customer/party_silver/electronic_address/checkpoint/",
        "col_stand":
        {
           "party_id":"dt_entityseq",
           "address_type":"'mobile'",
           "phone_country_code":"'66'",
           "phone_area_code":"'null'",
           "phone_number":"datavalue_policyHolder_mobileNumber",
           "contact_via_phone":"'y'",
           "udh_active_flag":"'y'",
		   "source_system":"'ifwd'",
		   "udh_insert_date":"current_timestamp()",
		   "udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,address_type,phone_country_code,phone_area_code,phone_number,contact_via_phone,udh_active_flag,source_system,udh_insert_date,udh_update_date",
    "pii_column":[],
    "drop_cols":["phone_number"]
	}

# COMMAND ----------

#extracting the config for electronic_address_table_config object
electronic_address_database_name = electronic_address_table['database_name']
electronic_address_target_table = electronic_address_table['target_table']
electronic_address_partition_column = electronic_address_table['partition_column']
electronic_address_target_checkpointLocation = electronic_address_table['target_checkpointLocation']
electronic_address_col_standarization = electronic_address_table['col_stand']
electronic_address_col_select = electronic_address_table['col_sel'].split(",")
electronic_address_pii_columns = electronic_address_table['pii_column']
electronic_address_drop_cols = electronic_address_table['drop_cols']

# COMMAND ----------

#config for bank_account_table
bank_account_table = {
        "database_name":env + "_party_silver",
        "target_table":"bank_account_silver",
        "partition_column":"source_system",
        "target_checkpointLocation":path_prefix + "/silver/customer/party_silver/bank_account/checkpoint/",
        "col_stand":
        {
            "party_id":"dt_entityseq",
            "bank_account_number":"datavalue_icp_accountNumber",
            "bank_code":"'null'",
            "bank_name":"datavalue_icp_bankName",
            "bank_branch_code":"'null'",
            "bank_account_name":"datavalue_icp_accountName",
            "bank_account_type":"'null'",
            "main_currency":"'null'",
            "udh_active_flag":"'y'",
            "udh_insert_date":"current_timestamp()",
            "udh_update_date":"current_timestamp()",
            "source_system":"'ifwd'"
        },
          "col_sel":"party_id,bank_account_number,bank_code,bank_name,bank_branch_code,bank_account_name,bank_account_type,main_currency,udh_active_flag,udh_insert_date,udh_update_date,source_system",
    "pii_column":[],
    "drop_cols":["bank_account_number","bank_name", "bank_account_name"]
}

# COMMAND ----------

#extracting the config for electronic_address_table_config object
bank_account_database_name = bank_account_table['database_name']
bank_account_target_table = bank_account_table['target_table']
bank_account_partition_column = bank_account_table['partition_column']
bank_account_target_checkpointLocation = bank_account_table['target_checkpointLocation']
bank_account_col_standarization = bank_account_table['col_stand']
bank_account_col_select = bank_account_table['col_sel'].split(",")
bank_account_pii_columns = bank_account_table['pii_column']
bank_account_drop_cols = bank_account_table['drop_cols']

# COMMAND ----------

#config for organisation table
organisation_table = {
        "database_name":env + "_party_silver",
		"target_table":"organisation_silver",
		"partition_column":"source_system",
		"target_checkpointLocation":path_prefix + "/silver/customer/party_silver/organisation/checkpoint/",
        "col_stand":
        {
           "party_id":"dt_entityseq",
           "organisation_name":"datavalue_addresses_workplaceName",
           "local_organisation_name":"'null'",
           "organisation_category":"'null'",
           "establish_date":"'null'",
           "establish_country_code":"datavalue_addresses_workplaceCountry",
           "udh_active_flag":"'y'",
		   "source_system":"'ifwd'",
		   "udh_insert_date":"current_timestamp()",
		   "udh_update_date":"current_timestamp()"
        },
    "col_sel":"party_id,organisation_name,local_organisation_name,organisation_category,establish_date,establish_country_code,udh_active_flag,source_system,udh_insert_date,udh_update_date",
    "pii_column":[],
    "drop_cols":["organisation_name", "establish_country_code"]
	}

# COMMAND ----------

#extracting the config for electronic_address_table_config object
organisation_database_name = organisation_table['database_name']
organisation_target_table = organisation_table['target_table']
organisation_partition_column = organisation_table['partition_column']
organisation_target_checkpointLocation = organisation_table['target_checkpointLocation']
organisation_col_standarization = organisation_table['col_stand']
organisation_col_select = organisation_table['col_sel'].split(",")
organisation_pii_columns = organisation_table['pii_column']
organisation_drop_cols = organisation_table['drop_cols']