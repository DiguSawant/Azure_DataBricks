# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "lead_info": { 
     "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.DWD.CLS_LEAD_INFO/",
     "checkpoint_location": path_prefix + "/silver/checkpoint/cube_fna/lead_info/",
	 "column_schema":"",
     "flatten_column": "",
     "encrypted_column":  ["GOVERNMENT_ID_NUM", "LEAD_BIRTH_DATE", "LEAD_EMAIL_ADDRESS", "LEAD_FIRST_NAME", "LEAD_FULL_NAME", "LEAD_LAST_NAME", "LEAD_MIDDLE_NAME", "MOBILE_PHONE_NUM"],
     "select_cols": ["ADDRESS_CITY", "ADDRESS_COUNTRY", "ADDRESS_LINE_1", "ADDRESS_LINE_2", "ADDRESS_LINE_3", "ADDRESS_LINE_4", "ADDRESS_LINE_5", "ADDRESS_POSTAL_CODE", "ADDRESS_PROVINCE", "ETL_CREATE_BY", "ETL_CREATE_TIME", "ETL_IS_CURRENT_FLAG", "ETL_SOURCE_BU", "ETL_SOURCE_SYSTEM", "ETL_SOURCE_SYSTEM_RECORD_TIME", "ETL_SOURCE_TABLE", "ETL_UPDATE_BY", "ETL_UPDATE_TIME", "ETL_VALID_END_TIME", "ETL_VALID_START_TIME", "GOVERNMENT_ID_NUM", "HOME_PHONE_AREA_CODE", "HOME_PHONE_COUNTRY_CODE", "HOME_PHONE_NUM", "INQUIRE_REASON", "IS_SMOKE", "LEAD_BIRTH_DATE", "LEAD_EMAIL_ADDRESS", "LEAD_FIRST_NAME", "LEAD_FULL_NAME", "LEAD_GENDER_CODE", "LEAD_ID", "LEAD_LAST_NAME", "LEAD_MIDDLE_NAME", "LEAD_NAME_LANG", "LEAD_SALUTATION", "LEAD_SCORE", "LEAD_TYPE", "LEAD_VALID_STATUS", "MARITAL", "MOBILE_PHONE_COUNTRY_CODE", "MOBILE_PHONE_NUM", "NUMBER_OF_KIDS", "OCCUPATION", "OCCUPATION_CODE", "OCCUPATION_GROUP", "OFFICE_PHONE_AREA_CODE", "OFFICE_PHONE_COUNTRY_CODE", "OFFICE_PHONE_NUM", "SOURCE_LEAD_ID", "SOURCE_SYSTEM", "TITLE", "TSR", "UDH_SOURCE_SYS", "UDH_INSERT_TIMESTAMP", "UDH_BATCH_ID"],
     "decrypted_column": "",
     "intermediate_table":"",
     "intermediate_checkpoint_path": path_prefix + "",
     "intermediate_target_path": path_prefix + "",
     "target_path" : path_prefix + '/silver/cube_fna/lead_info/',
     "database_name" :f"{env}_silver",
     "table_name" : "cls_lead_info_cube_fna_silver",     
     "schemalocation_path": path_prefix + "/silver/schema/cube_fna/lead_info/",
     "intermediate_checkpoint_location": path_prefix + "/silver_intermediate/checkpoint/cube_fna/lead_info/",
     "intermediate_target_path" : path_prefix + '/silver_intermediate/cube_fna/lead_info/',
     "intermediate_database_name" : f"{env}_cube_fna_silver",
     "intermediate_table_name" : "cls_lead_info_cube_fna_silver",     
     "pii_columns": ""
    }   
    
}

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['lead_info']['s3_path']
schemalocation = config_cube['lead_info']['schemalocation_path']
checkpointlocation = config_cube['lead_info']['checkpoint_location']
target_path = config_cube['lead_info']['target_path']
column_schema = config_cube['lead_info']['column_schema']
flatten_column = config_cube['lead_info']['flatten_column']
encrypted_column = config_cube['lead_info']['encrypted_column']
select_cols = config_cube['lead_info']['select_cols']
database_name = config_cube['lead_info']['database_name']
table_name = config_cube['lead_info']['table_name']
pii_columns = config_cube['lead_info']['pii_columns']
intermediate_target_path = config_cube['lead_info']['intermediate_target_path']
intermediate_database_name = config_cube['lead_info']['intermediate_database_name']
intermediate_table_name = config_cube['lead_info']['intermediate_table_name']
intermediate_checkpoint_location = config_cube['lead_info']['intermediate_checkpoint_location']


# COMMAND ----------

