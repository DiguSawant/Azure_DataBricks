# Databricks notebook source
# DBTITLE 1,import the python package we need
from confluent_kafka.schema_registry import SchemaRegistryClient
from pyspark.sql.types import IntegerType,StringType,StructType,StructField,DoubleType,TimestampType,ArrayType,BooleanType
from struct import pack, unpack
import ssl
import boto3
import base64
import json,time
from botocore.exceptions import ClientError
from delta.tables import *
import os

# COMMAND ----------

env = os.getenv("env")
land_db_name = os.getenv("land_db_name")
dlt_db_name = os.getenv("dlt_db_name")
delta_db_name = os.getenv("delta_db_name")
checkpoint_loc = os.getenv("checkpoint_loc")
delta_loc = os.getenv("delta_loc")

# COMMAND ----------

# DBTITLE 1,Use the dbutils module to get the secret 
aws_access_keyid = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-access-key-id")
aws_secret_access_key = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-secret-access-key")
aws_rolearn = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-rolearn")
kafka_bootstrap_servers = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-bootstrap-servers-url")
kafka_ca_path = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-saslssl-devcapem-location")
schemaRegistryURL = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "confluent-cloud-schemaregistry-url")
secretname = dbutils.secrets.get(scope = "databrick_gdmp_apsea1_fwdapp_01_scopename", key = "udh-aws-secretmanager-secretname")

# COMMAND ----------

# DBTITLE 1,put the columns of target table into the dictionary
target_cols={}

# COMMAND ----------

# DBTITLE 1,Connect to the Schema Registry, define the topic that we need and define the function to get the relative topic's schema and schema id
import json
try:
    schema_registry_conf = {
        'url':f'{schemaRegistryURL}',
        'ssl.ca.location':f'{kafka_ca_path}'
    }
except Exception as e:
    raise e
    
schema_registry_client = SchemaRegistryClient(schema_registry_conf)

#define the function to get relative topic's schema and schema_id
def get_key_schema(topic_name):
    try:
        schema_key = schema_registry_client.get_latest_version(f"{topic_name}-key")
    except Exception as e:
        raise e
    schema=schema_key.schema.schema_str
    schema_id=schema_key.schema_id
    return (schema,schema_id)

def get_value_schema(topic_name):
    try:
        schema_value = schema_registry_client.get_latest_version(f"{topic_name}-value")
    except Exception as e:
        raise e
    schema=schema_value.schema.schema_str
    schema_id=schema_value.schema_id
    return (schema,schema_id)
# schemakey_en = json.loads(get_value_schema('TH.UAT.ODS.LIFEPLAN.public.Entity')[0])

# COMMAND ----------

####create a connection for aws secret manage service
def get_secret(input_secret_name):
    secret_name = input_secret_name ####secert name
    region_name = "ap-southeast-1"
    # Create a Secrets Manager client
    #session = boto3.session.Session()
    client = boto3.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    # In this sample we only handle the specific exceptions for the 'GetSecretValue' API.
    # See https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
    # We rethrow the exception by default.
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS key.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
    return secret  

# COMMAND ----------

# DBTITLE 1,Define the function to acquire configuration of read stream and write stream
binary_to_string = udf(lambda x: str(int.from_bytes(x, byteorder='big')), StringType())
def read_conf(source_topic,startingOffsets,api_key,api_secret):
    conf={  
       "kafka.bootstrap.servers":f'{kafka_bootstrap_servers}',
       "kafka.security.protocol":'SASL_SSL',
       "kafka.sasl.jaas.config":"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(api_key, api_secret),
       "kafka.ssl.endpoint.identification.algorithm":'https',
       "kafka.sasl.mechanism":'PLAIN',
       "subscribe": f"{source_topic}",
       "startingOffsets": f"{startingOffsets}",
       "failOnDataLoss": "false"
    }
    return conf

def write_conf(target_topic,checkpoint,api_key,api_secret):
    conf={
       "kafka.bootstrap.servers":f'{kafka_bootstrap_servers}',
       "kafka.security.protocol":'SASL_SSL',
       "kafka.sasl.jaas.config": "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(api_key, api_secret),
       "kafka.ssl.endpoint.identification.algorithm": 'https',
       "kafka.sasl.mechanism": 'PLAIN',
       "topic": f"{target_topic}",
       "partitions": 3,
       "checkpointLocation": f"{checkpoint}"
    }
    return conf

# COMMAND ----------

# DBTITLE 1,Retrieve the secret from secret manger by using personal AccessKeyId and SecretKeyId of AWS to connect the secret manger
###use some account's credenctial first

aws_some_iamaccount = {
    'aws_access_key_id':aws_access_keyid,
    'aws_secret_access_key':aws_secret_access_key   
}
### get ENV token which the role will be switched to 

sts=boto3.client('sts', **aws_some_iamaccount)
stsresponse = sts.assume_role(
    RoleArn=aws_rolearn, 
    RoleSessionName='assumed'
)
aws_credentials_assumed_role = {
    'region_name':'ap-southeast-1',
    'aws_access_key_id':stsresponse["Credentials"]["AccessKeyId"],
    'aws_secret_access_key':stsresponse["Credentials"]["SecretAccessKey"],
    'aws_session_token':stsresponse["Credentials"]["SessionToken"]
}
###configure the token before calling aws'product api
boto3.setup_default_session(**aws_credentials_assumed_role)


secret=json.loads(get_secret(secretname)) ###return dict type
api_key=secret['kafka_api_key']
api_secret=secret['kafka_api_secret']
kafka_aes_key = secret['kafka_aes_key']


# COMMAND ----------

# topic_dict = {""}
# target_topic = topic_dict["Target"]
# startingOffsets = "earliest"
# entity = topic_dict["Entity"]
# entityversion = topic_dict["EntityVersion"]
# schemavalue_en = get_value_schema(entity)[0] #get the schema-value of entity
# schemakey_en = get_key_schema(entity)[0] #get the schema-key of entity
# schemavalue_enve = get_value_schema(entityversion)[0] #get the schema-value of entityversion
# schemakey_enve = get_key_schema(entityversion)[0] #get the schema-key of entityversion
# schemavalue_target = get_value_schema(target_topic)[0] #get the schema-value of target topic
# checkpoint = f"{checkpoint_loc}lifeplan/TB_LIFEPLAN_PRODUCT_RECOMMEND_DIM" #dbfs:/mnt/s3-udh-dev-databricks-log/
# checkpoint_del = f"{checkpoint_loc}lifeplan/TB_LIFEPLAN_PRODUCT_RECOMMEND_DIM_DELETED"
# header_logic='case when _change_type = "delete" THEN array(named_struct("key","is_deleted", "value", CAST("1" AS BINARY))) ELSE NULL END'
# filter_condition = """path like '/Apps/Flow/Cases/%'  
#                AND privacyLevel = 'Private' 
#                AND Type = 'Case' 
#                AND policyNumber is not null 
#                AND created > date'2022-08-01' """
# schema_key_target,schema_kid_target= get_key_schema(target_topic) 
# schema_value_target,schema_vid_target = get_value_schema(target_topic)
# value_header = pack('>bI',0,schema_vid_target)
# key_header = pack('>bI',0,schema_kid_target)
# fields=[]
# item=json.loads(schemavalue_target)["fields"]
# for i in item:
#     fields.append(i["name"]) 
# entity_conf = read_conf(entity,startingOffsets,api_key,api_secret)
# entityversion_conf = read_conf(entityversion,startingOffsets,api_key,api_secret)
# conf=write_conf(target_topic,checkpoint,api_key,api_secret)
# conf_def=write_conf(target_topic,checkpoint_del,api_key,api_secret)
# # delta_loc="/FileStore/delta/"
# # delta_db_name='delta'
# # unix_timestamp = str(time.time()*1000)
# delta_table="tb_lifeplan_product_recommend_dim"
# delta_table_tmp="tb_lifeplan_product_recommend_dim_tmp"
# df_to_delta=f"{checkpoint_loc}lifeplan/df_to_delta"
# df_to_delta_del=f"{checkpoint_loc}lifeplan/df_to_delta_del"
# delta_to_delta=f"{checkpoint_loc}lifeplan/delta_to_delta"
# # fields

# COMMAND ----------

# il_tb_agrt_coverage_curr_dim_update_config = {
#    "last_update_time" : "live.last_update_time"
#   ,"coverage_id": "live.coverage_id"
#   ,"policy_id": "live.policy_id"
#   ,"source_policy_id": "live.source_policy_id"
#   ,"life_id": "live.life_id"
#   ,"coverage_seq_id": "live.coverage_seq_id"
#   ,"rider_id": "live.rider_id"
#   ,"trailer_id": "live.trailer_id"
#   ,"plan_code": "live.plan_code"
#   ,"premium_end_date": "live.premium_end_date"
#   ,"premium_payment_duration": "live.premium_payment_duration"
#   ,"premium_next_due_date": "live.premium_next_due_date"
#   ,"sum_assured": "live.sum_assured"
#   ,"modal_premium": "live.modal_premium"
#   ,"single_premium": "live.single_premium"
#   ,"coverage_end_date": "live.coverage_end_date"
#   ,"expiration_desc": "live.expiration_desc"
#   ,"coverage_duration": "live.coverage_duration"
#   ,"basic_plan_indicator": "live.basic_plan_indicator"
#   ,"currency_code": "live.currency_code"
#   ,"etl_source_system_record_time": "live.etl_source_system_record_time"
#   ,"etl_create_time": "live.etl_create_time"
#   ,"etl_valid_start_time": "live.etl_create_time"       
#   ,"etl_update_time" : unix_timestamp
# }

# COMMAND ----------

# dbutils.fs.rm("/mnt/s3-udh-dev-databricks-log/checkpointLocation/LIFEPLAN",True)

# COMMAND ----------

def generate_insert_config(table_name):
    insert_config = {}
    
    table_cols = spark.sql(f"select * from {delta_db_name}.{table_name} limit 1").columns
    
    for col in table_cols:
            insert_config[col] = f"df.{col}"
    
    
    return insert_config

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.window import Window
# window = Window.partitionBy("entity_policyno").orderBy(col("entity_updateddate"))
def merge_delta_to_delta(df,batchId):
#     try:
        # get merge function's update config
#         update_config = merge_update_config[table_name]
        # get merge function's insert config
  
    window = Window.partitionBy("entity_policyno").orderBy(col("entity_updateddate").desc())
    
    df=df.withColumn("row",row_number().over(window))\
    .filter(col("row") == 1)\
    .drop("row")
    insert_config = generate_insert_config(delta_table) 

    delta_df = DeltaTable.forPath(spark, f'{delta_loc}/{delta_table_tmp}')

    delta_df.alias('delta') \
      .merge(source = df.alias('df'), condition = "delta.entity_policyno = df.entity_policyno" ) \
      .whenMatchedDelete(condition = "df.is_deleted = 1") \
      .whenMatchedUpdate(condition = "delta.entity_updateddate < df.entity_updateddate and df.is_deleted = 0",set = insert_config)\
      .whenNotMatchedInsert(condition="df.is_deleted = 0",values=insert_config) \
      .execute()
#         return True
#     except:
#         return False

# COMMAND ----------

def stream_df_to_delta(df,path):
    return df.writeStream \
              .format("delta") \
              .outputMode("append")\
              .option("checkpointLocation", path)\
              .start(f"{delta_loc}/{delta_table}")

# (events.writeStream
#    .format("delta")
#    .outputMode("append")
#    .option("checkpointLocation", "/tmp/delta/_checkpoints/")
#    .start("/delta/events")
# )