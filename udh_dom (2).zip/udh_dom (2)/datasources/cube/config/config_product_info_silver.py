# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "product_info": { 
     "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.DWD.CLS_PRODUCT_INFO/",
     "checkpoint_location": path_prefix + "/silver/checkpoint/cube_fna/product_info/",
	 "column_schema":"",
     "flatten_column": "",
     "encrypted_column": "",
     "select_cols": ["ETL_SOURCE_BU", "ETL_SOURCE_SYSTEM", "LEAD_ID", "PRODUCT_FACT_ID", "SOURCE_LEAD_ID", "PRODUCT_RECOMMENDED", "PRODUCT_RECOMMENDED_TYPE_CODE", "UDH_SOURCE_SYS", "UDH_INSERT_TIMESTAMP", "UDH_BATCH_ID"],
     "decrypted_column": "",
     "target_path" : path_prefix + '/silver/cube_fna/product_info/',
     "schemalocation_path": path_prefix + "/silver/schema/cube_fna/product_info/",
     "database_name" : f"{env}_silver",
     "table_name" : "cls_product_info_cube_fna_silver",
     "intermediate_checkpoint_location": path_prefix + "/silver_intermediate/checkpoint/cube_fna/product_info/",
     "intermediate_target_path" : path_prefix + '/silver_intermediate/cube_fna/product_info/',
     "intermediate_database_name" : f"{env}_cube_fna_silver",
     "intermediate_table_name" : "cls_product_info_cube_fna_silver",
     "pii_columns": ""
    }   
    
}

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['product_info']['s3_path']
schemalocation = config_cube['product_info']['schemalocation_path']
checkpointlocation = config_cube['product_info']['checkpoint_location']
target_path = config_cube['product_info']['target_path']
column_schema = config_cube['product_info']['column_schema']
flatten_column = config_cube['product_info']['flatten_column']
encrypted_column = config_cube['product_info']['encrypted_column']
select_cols = config_cube['product_info']['select_cols']
database_name = config_cube['product_info']['database_name']
table_name = config_cube['product_info']['table_name']
pii_columns = config_cube['product_info']['pii_columns']
intermediate_target_path = config_cube['product_info']['intermediate_target_path']
intermediate_database_name = config_cube['product_info']['intermediate_database_name']
intermediate_table_name = config_cube['product_info']['intermediate_table_name']
intermediate_checkpoint_location = config_cube['product_info']['intermediate_checkpoint_location']


# COMMAND ----------

