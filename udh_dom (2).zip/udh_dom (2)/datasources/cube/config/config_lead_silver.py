# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "lead": { 
     "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.ODS.IRIS_LEAD/",
     "checkpoint_location": path_prefix + "/silver/checkpoint/cube_fna/lead/",
	 "column_schema": StructType([ StructField('clientType', StringType(), True), StructField('leadStatusCode', StringType(), True), StructField('name',  StructType([StructField('en', StringType(), True) ])), StructField('preferredLang', StringType(), True), StructField('age', StringType(), True), StructField('productInterestedTypeCode', StringType(), True), StructField('productInterested',  StructType([StructField('th', StringType(), True), StructField('en_th', StringType(), True) ])), StructField('mobileNumber', StringType(), True),StructField('phoneMobile', StringType(), True), StructField('emailAddress', StringType(), True), StructField('createdTime', StringType(), True), StructField('updatedTime', StringType(), True), StructField('sourceTypeCode', StringType(), True), StructField('id', StringType(), True), StructField('acknowledged', StringType(), True), StructField('status', StringType(), True), StructField('agentCode', StringType(), True), StructField('birthDate', StringType(), True), StructField('contactedFlag', StringType(), True), StructField('appointmentFlag', StringType(), True), StructField('illustrationFlag', StringType(), True), StructField('submittedFlag', StringType(), True), StructField('activityLogList', StringType(), True)]),
     "flatten_column": "jsonValue",
     "encrypted_column": ["JSONVALUE_AGE","JSONVALUE_NAME_EN", "JSONVALUE_MOBILENUMBER", "JSONVALUE_PHONEMOBILE", "JSONVALUE_EMAILADDRESS", "JSONVALUE_BIRTHDATE"],
     "select_cols": ["JSONVALUE_CLIENTTYPE", "JSONVALUE_LEADSTATUSCODE", "JSONVALUE_PREFERREDLANG", "JSONVALUE_AGE", "JSONVALUE_PRODUCTINTERESTEDTYPECODE", "JSONVALUE_MOBILENUMBER", "JSONVALUE_PHONEMOBILE", "JSONVALUE_EMAILADDRESS", "JSONVALUE_CREATEDTIME", "JSONVALUE_UPDATEDTIME", "JSONVALUE_SOURCETYPECODE", "JSONVALUE_ID", "JSONVALUE_ACKNOWLEDGED", "JSONVALUE_STATUS", "JSONVALUE_AGENTCODE", "JSONVALUE_BIRTHDATE", "JSONVALUE_CONTACTEDFLAG", "JSONVALUE_APPOINTMENTFLAG", "JSONVALUE_ILLUSTRATIONFLAG", "JSONVALUE_SUBMITTEDFLAG", "JSONVALUE_ACTIVITYLOGLIST", "JSONVALUE_PRODUCTINTERESTED_TH", "JSONVALUE_PRODUCTINTERESTED_EN_TH", "JSONVALUE_NAME_EN", "UDH_SOURCE_SYS", "UDH_INSERT_TIMESTAMP", "UDH_BATCH_ID"],
     "decrypted_column": "",
     "target_path" : path_prefix + '/silver/cube_fna/lead/',
     "database_name" : f"{env}_silver",
     "table_name" : "iris_lead_cube_fna_silver",
     "schemalocation_path": path_prefix + "/silver/schema/cube_fna/lead/",
     "intermediate_checkpoint_location": path_prefix + "/silver_intermediate/checkpoint/cube_fna/lead/",
     "intermediate_target_path" : path_prefix + '/silver_intermediate/cube_fna/lead/',
     "intermediate_database_name" : f"{env}_cube_fna_silver",
     "intermediate_table_name" : "iris_lead_cube_fna_silver",
     "pii_columns": "",
     "kafka_checkpoint" : path_prefix + "/bronze/cube_fna/checkpoint/",
     "kafka_topic" : path_prefix + "/bronze/cube_fna/TH.DEV.ODS.IRIS_LEAD/"
    }   
    
}

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['lead']['s3_path']
schemalocation = config_cube['lead']['schemalocation_path']
checkpointlocation = config_cube['lead']['checkpoint_location']
target_path = config_cube['lead']['target_path']
column_schema = config_cube['lead']['column_schema']
flatten_column = config_cube['lead']['flatten_column']
encrypted_column = config_cube['lead']['encrypted_column']
select_cols = config_cube['lead']['select_cols']
database_name = config_cube['lead']['database_name']
table_name = config_cube['lead']['table_name']
pii_columns = config_cube['lead']['pii_columns']
intermediate_target_path = config_cube['lead']['intermediate_target_path']
intermediate_database_name = config_cube['lead']['intermediate_database_name']
intermediate_table_name = config_cube['lead']['intermediate_table_name']
intermediate_checkpoint_location = config_cube['lead']['intermediate_checkpoint_location']


# COMMAND ----------

