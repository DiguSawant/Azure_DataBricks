# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "lead_agent": { 
     "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.DWD.CLS_LEAD_AGENT/",
     "schemalocation_path": path_prefix + "/silver/schema/cube_fna/lead_agent/",
     "checkpoint_location": path_prefix + "/silver/checkpoint/cube_fna/lead_agent/",
	 "column_schema":"",
     "flatten_column": "",
     "encrypted_column": "",
     "select_cols": ["AGENT_CODE", "AGENT_REL_ID", "ASSIGN_DATE", "END_DATE", "ETL_SOURCE_BU", "ETL_SOURCE_SYSTEM", "IS_CURRENT", "LEAD_ID", "SOURCE_LEAD_ID", "START_DATE", "UPDATE_DATE", "UDH_SOURCE_SYS", "UDH_INSERT_TIMESTAMP", "UDH_BATCH_ID"],
     "decrypted_column": "",
     "intermediate_checkpoint_location": path_prefix + "/silver_intermediate/checkpoint/cube_fna/lead_agent/",
     "intermediate_target_path" : path_prefix + '/silver_intermediate/cube_fna/lead_agent/',
     "intermediate_database_name" : f"{env}_cube_fna_silver",
     "intermediate_table_name" : "cls_lead_agent_cube_fna_silver",
     "database_name" : f"{env}_silver",
     "table_name" : "cls_lead_agent_cube_fna_silver",
     "target_path" : path_prefix + '/silver/cube_fna/lead_agent/',
     "pii_columns": ""
    }   
    
}

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['lead_agent']['s3_path']
schemalocation = config_cube['lead_agent']['schemalocation_path']
checkpointlocation = config_cube['lead_agent']['checkpoint_location']
target_path = config_cube['lead_agent']['target_path']
column_schema = config_cube['lead_agent']['column_schema']
flatten_column = config_cube['lead_agent']['flatten_column']
encrypted_column = config_cube['lead_agent']['encrypted_column']
select_cols = config_cube['lead_agent']['select_cols']
database_name = config_cube['lead_agent']['database_name']
table_name = config_cube['lead_agent']['table_name']
pii_columns = config_cube['lead_agent']['pii_columns']
intermediate_target_path = config_cube['lead_agent']['intermediate_target_path']
intermediate_database_name = config_cube['lead_agent']['intermediate_database_name']
intermediate_table_name = config_cube['lead_agent']['intermediate_table_name']
intermediate_checkpoint_location = config_cube['lead_agent']['intermediate_checkpoint_location']
