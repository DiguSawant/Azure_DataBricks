# Databricks notebook source
import os
# env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

#config for cube
config_cube =  {
    "lead_status": { 
     "s3_path": path_prefix + f"/bronze/cube_fna/TH.DEV.DWD.CLS_LEAD_STATUS/",
     "checkpoint_location": path_prefix + "/silver/checkpoint/cube_fna/lead_status/",
	 "column_schema":"",
     "flatten_column": "",
     "encrypted_column": "",
     "select_cols": ["END_DATE", "ETL_SOURCE_BU", "ETL_SOURCE_SYSTEM", "IS_CURRENT", "LEAD_ID", "LEAD_STATUS", "LEAD_STATUS_ID", "SOURCE_LEAD_ID", "START_DATE", "STATUS_DATE", "UPDATE_DATE", "UDH_SOURCE_SYS", "UDH_INSERT_TIMESTAMP", "UDH_BATCH_ID"],
     "decrypted_column": "",
     "target_path" : path_prefix + '/silver/cube_fna/lead_status/',
     "database_name" : f"{env}_silver",
     "table_name" : "cls_lead_status_cube_fna_silver",
     "schemalocation_path": path_prefix + "/silver/schema/cube_fna/lead_status/",
     "intermediate_checkpoint_location": path_prefix + "/silver_intermediate/checkpoint/cube_fna/lead_status/",
     "intermediate_target_path" : path_prefix + '/silver_intermediate/cube_fna/lead_status/',
     "intermediate_database_name" : f"{env}_cube_fna_silver",
     "intermediate_table_name" : "cls_lead_status_cube_fna_silver",
     "pii_columns": ""
    }   
    
}

# COMMAND ----------

# extract variables from config
source_s3_path = config_cube['lead_status']['s3_path']
schemalocation = config_cube['lead_status']['schemalocation_path']
checkpointlocation = config_cube['lead_status']['checkpoint_location']
target_path = config_cube['lead_status']['target_path']
column_schema = config_cube['lead_status']['column_schema']
flatten_column = config_cube['lead_status']['flatten_column']
encrypted_column = config_cube['lead_status']['encrypted_column']
select_cols = config_cube['lead_status']['select_cols']
database_name = config_cube['lead_status']['database_name']
table_name = config_cube['lead_status']['table_name']
pii_columns = config_cube['lead_status']['pii_columns']
intermediate_target_path = config_cube['lead_status']['intermediate_target_path']
intermediate_database_name = config_cube['lead_status']['intermediate_database_name']
intermediate_table_name = config_cube['lead_status']['intermediate_table_name']
intermediate_checkpoint_location = config_cube['lead_status']['intermediate_checkpoint_location']
