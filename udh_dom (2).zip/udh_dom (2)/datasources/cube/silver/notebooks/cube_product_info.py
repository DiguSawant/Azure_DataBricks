# Databricks notebook source
"""
    Purpose : Load data for Product Info topic
    Input : s3 files(Topic : TH.DEV.DWD.CLS_PRODUCT_INFO)
    Output : Tables - dev_cube_fna_silver.cls_product_info_cube_fna_silver, dev_silver.cls_product_info_cube_fna_silver
"""

# COMMAND ----------

# MAGIC %run  ../../../../tech_utility/aes

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/common_functions
# MAGIC

# COMMAND ----------

# MAGIC %run ../../../../datasources/cube/config/config_product_info_silver

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

#calling read_stream method to read source data using autoloader
try:
    df_read_prod_info = read_stream(source_path = source_s3_path, checkpoint_location = checkpointlocation, file_format = "json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop rows if null found in all coumns
try:
    df_dropna_prod_info = df_read_prod_info.dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append the partition column udh_insert_dt and udh_insert_hr
try:
    partition_df_prod_info = df_dropna_prod_info.withColumn("udh_source_sys",lit('product_info'))\
                                .withColumn("udh_insert_timestamp",current_timestamp())\
                                .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicates
try:
    partition_df_prod_info_dup = partition_df_prod_info.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# insert flatten data into external table
try:
    table = intermediate_database_name + "." + intermediate_table_name
    partition_df_prod_info_dup.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation",intermediate_checkpoint_location)\
        .option("path",intermediate_target_path)\
        .partitionBy(["UDH_BATCH_ID"])\
        .toTable(table)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all columns names in upper case
try:
    prod_info_field_upper_df = columnsNames_to_upper_case(partition_df_prod_info_dup)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate rows
try:
    prod_info_df = prod_info_field_upper_df.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all string type column's value into upper case
table = database_name + "." + table_name
def process_batch(df,epoch_id):
    str_cols = [col_name for col_name, data_type in df.dtypes if data_type == "string"]
    for col_name in str_cols:
        if col_name not in pii_columns:
            df = df.withColumn(col_name, upper(col(col_name)))
    df.select(select_cols).write.format("delta").mode("append").partitionBy("UDH_BATCH_ID").option("path",target_path).saveAsTable(table)

# COMMAND ----------

# write data into external delta table 
try:
    
    prod_info_df.writeStream\
                        .foreachBatch(process_batch)\
                        .option("checkpointLocation",schemalocation)\
                        .start()
except Exception as e:
    raise Exception(e)