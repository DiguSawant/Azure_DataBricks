# Databricks notebook source
"""
    Purpose : Load data for Lead Info topic
    Input : s3 files(Topic : TH.DEV.DWD.CLS_LEAD_INFO)
    Output : Tables - dev_cube_fna_silver.cls_lead_info_cube_fna_silver, dev_silver.cls_lead_info_cube_fna_silver
"""

# COMMAND ----------

# MAGIC %run  ../../../../tech_utility/aes

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/json_flatten

# COMMAND ----------

# MAGIC %run ../../../../tech_utility/common_functions
# MAGIC

# COMMAND ----------

# MAGIC %run ../../../../datasources/cube/config/config_lead_info_silver

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

#calling read_stream method to read source data using autoloader
try:
    df_read_lead_info = read_stream(source_path = source_s3_path, checkpoint_location = checkpointlocation, file_format = "json")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop rows if null found in all coumns
try:
    df_dropna_lead_info = df_read_lead_info.dropna(how="all")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# append the partition column udh_insert_dt and udh_insert_hr
try:
    partition_df_lead_info = df_dropna_lead_info.withColumn("udh_source_sys",lit('lead_info'))\
                                .withColumn("udh_insert_timestamp",current_timestamp())\
                                .withColumn("udh_batch_id",lit(curr_date))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicates
try:
    partition_df_lead_info_dup = partition_df_lead_info.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# insert flatten data into external table
try:
    table = intermediate_database_name + "." + intermediate_table_name
    partition_df_lead_info_dup.writeStream.format("delta")\
        .outputMode("append")\
        .option("checkpointLocation",intermediate_checkpoint_location)\
        .option("path",intermediate_target_path)\
        .partitionBy(["UDH_BATCH_ID"])\
        .toTable(table)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all columns names in upper case
try:
    lead_info_field_upper_df = columnsNames_to_upper_case(partition_df_lead_info_dup)
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# filter out the corrupted data
try:
    lead_info_field_filter_df = lead_info_field_upper_df.filter("lead_id not in ('DH-00be4112-40be-44d7-b1f4-9323a43e749c', 'DH-10001', 'DH-123', 'Marketing-00be4112-40be-44d7-b1f4-9323a43e749c', 'Marketing-10001', 'DH-0000123') ").filter("government_id_num not in ('Utj6fOgudgDqsUbe8g/IfA==' ,'wer567')").filter("lead_birth_date not in ('tR5hvhfmgyIIKncRf17Nmg==') ")
except Exception as e:
    raise Exception(e)

# COMMAND ----------

#decrypt the json_data field of dataframe
try:
    decryptDf = lead_info_field_filter_df 
    for field in  encrypted_column :   
        decryptDf = decryptDf.withColumn(field, when(decryptDf[field].isNull(),lit(None)).otherwise(aes_decrypt(field)))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all string type column's value into upper case
df = decryptDf
str_cols = [col_name for col_name, data_type in df.dtypes if data_type == "string"]
for col_name in str_cols:        
    df = df.withColumn(col_name, upper(col(col_name)))

# COMMAND ----------

#encrypt the json_data field of dataframe
try:
    encryptDf = df 
    for field in  encrypted_column :   
        encryptDf = encryptDf.withColumn(field, when(encryptDf[field].isNull(),lit(None)).otherwise(aes_encrypt(field)))
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# drop duplicate rows
try:
    encryptDf_lead_info = encryptDf.dropDuplicates()
except Exception as e:
    raise Exception(e)

# COMMAND ----------

# convert all string type column's value into upper case
table = database_name + "." + table_name
def process_batch(df,epoch_id):    
    df.select(select_cols).write.format("delta").mode("append").partitionBy("UDH_BATCH_ID").option("path",target_path).saveAsTable(table)

# COMMAND ----------

# write data into external delta table 
try:    
    encryptDf_lead_info.writeStream\
                        .foreachBatch(process_batch)\
                        .option("checkpointLocation",schemalocation)\
                        .start()
except Exception as e:
    raise Exception(e)