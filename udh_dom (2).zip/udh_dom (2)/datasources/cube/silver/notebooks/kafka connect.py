# Databricks notebook source
"""
    Purpose : Load data for Lead
    Input : kafka topic
    Output : s3 files(Topic : TH.DEV.ODS.IRIS_LEAD)
"""

# COMMAND ----------

# MAGIC %run ../../../../datasources/cube/config/cube_env_param

# COMMAND ----------

# MAGIC %run ../../../../datasources/cube/config/config_lead_silver

# COMMAND ----------

iris_conf = read_conf("TH.DEV.ODS.IRIS_LEAD",startingOffsets,api_key,api_secret)

# COMMAND ----------

schemavalue_en = get_value_schema("TH.DEV.ODS.IRIS_LEAD")[0] 

# COMMAND ----------

from pyspark.sql.functions import expr
from pyspark.sql.avro.functions import from_avro, to_avro


# COMMAND ----------

df_iris = spark.readStream\
  .format("kafka")\
  .options(**iris_conf)\
  .load()\
  .withColumn('valueSchemaId', binary_to_string(expr("substring(value, 2, 4)")))\
  .withColumn('fixedValue', expr("substring(value, 6, length(value)-5)"))\
  .withColumn('fixedKey', expr("substring(key, 6, length(key)-5)"))\
  .select(from_avro('fixedValue', schemavalue_en,{'mode' :'PERMISSIVE'}).alias('jsonValue'),'topic', 'partition', 'offset', 'timestamp', 'timestampType', 'fixedKey', 'valueSchemaId','fixedValue')

# COMMAND ----------

df_iris.display()

# COMMAND ----------

df_iris_write = df_iris.select("jsonValue").writeStream.format("json")\
                  .outputMode("append")\
                  .option("checkpointLocation",kafka_checkpoint)\
                  .trigger(processingTime='1 minutes')\
                  .start(kafka_topic)