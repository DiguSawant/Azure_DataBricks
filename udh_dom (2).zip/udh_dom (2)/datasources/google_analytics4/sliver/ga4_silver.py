# Databricks notebook source
df=spark.read.json('/FileStore/tables/fwd/ga/*.json')

# COMMAND ----------

df.display()

# COMMAND ----------

