# Databricks notebook source
# MAGIC %run /Shared/udh_dom/datasources/google_analytics4/config/config_google_analytics

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta,date
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# Daily_Load - load the data upto T-1 day 
end_date=date.today()

# COMMAND ----------

# Print the path of the latest file
if latest_file:
    print(f"latest Files Present in target ( {latest_file.path} ")
else:
    raise Exception("No files found.")

# COMMAND ----------

#Get the start date from latest_file
last_file=("").join([i.split("=")[1] for i in latest_file.path.split("/") if '=' in i])
last_date=datetime.strptime(last_file, '%Y%m%d').date()
start_date=last_date+timedelta(days=1)

# COMMAND ----------

year=start_date.strftime("%Y")
month=start_date.strftime("%m")
day=start_date.strftime("%d")

# COMMAND ----------

def data_load(start_date,end_date):
    while start_date<end_date:
        print(f""" Started Data Loading for event_date {start_date.strftime("%Y%m%d")} """)
        
        try:
                #reading data from bigquery 
                ga_df=spark.read.format("bigquery") \
                        .option("parentProject", parentProject) \
                        .option("project", project) \
                        .option("table", table+start_date.strftime("%Y%m%d")).load()

                # Adding Auditing Columns-Data Load information 
                ga_df = ga_df.withColumn("udh_source_sys",lit('ga4')) \
                        .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType())) \
                        .withColumn("udh_batch_id",lit(curr_date))

                
                # Creating Partitioning Columns - storing Data in "Year=/month=/Day="
                ga_df=ga_df.withColumn('year',substring('event_date',1,4)) \
                        .withColumn('month',substring('event_date',5,2)) \
                        .withColumn('day',substring('event_date',7,2))
                
                # data writing into json format 
                ga_df.repartition(15) \
                    .write \
                    .partitionBy('year','month','day') \
                    .format("json") \
                    .mode("append") \
                    .option('ignoreNullFields','false') \
                    .option("path", target_path) \
                    .save()

                

        except Exception as e:
            raise Exception(e)

        print(f""" Data Load is completed Sucessfully for event_date {start_date.strftime("%Y%m%d")} """)
        start_date+=timedelta(days=1)
        


# COMMAND ----------

if start_date==end_date:
    raise Exception(f"""The Data is already Present for given event_date '{last_date.strftime("%Y-%m-%d")}' """)
                        #Please Check in Location '{target_path}/year={year}/month={month}/day={day}' 
else :
    data_load(start_date,end_date)
    print(f"  Daily Data load is completed for GA4 ")
