# Databricks notebook source
# MAGIC %run /Shared/udh_dom/datasources/google_analytics4/config/config_google_analytics

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %sql SET TIME ZONE 'Asia/Bangkok';

# COMMAND ----------

from datetime import datetime, timedelta,date
import pytz

bankokTz = pytz.timezone('Asia/Bangkok')
timeinbankok = datetime.now(bankokTz)
curr_date = timeinbankok.strftime("%Y%m%d")
curr_hour = timeinbankok.strftime("%H")
curr_date_hr = timeinbankok.strftime("%Y%m%d%H")
curr_date_time = timeinbankok.strftime("%Y-%m-%d %H:%M:%S")

# COMMAND ----------

# Sequentially fetching each day's data by providing the date 
# for Historical load fetching data from date "2022-september-12"  
start_date =datetime(2023,5,10)
end_date =datetime(2023,5,11)

# COMMAND ----------

while start_date<=end_date:
    try:
            #Reading Data from source
            ga_df=spark.read.format("bigquery") \
                    .option("parentProject", parentProject) \
                    .option("project", project) \
                    .option("table", table+start_date.strftime("%Y%m%d")).load()

            

            #Adding Auditing Columns
            ga_df = ga_df.withColumn("udh_source_sys",lit('ga4')) \
                    .withColumn("udh_insert_timestamp",lit(curr_date_time).cast(TimestampType())) \
                    .withColumn("udh_batch_id",lit(curr_date))
                    

            #Adding Partitioning Columns
            ga_df=ga_df.withColumn('year',substring('event_date',1,4)) \
                    .withColumn('month',substring('event_date',5,2)) \
                    .withColumn('day',substring('event_date',7,2))
            
            #for Historical load - mode -> overwrite
            ga_df.repartition(15) \
                .write \
                .partitionBy('year','month','day') \
                .format("json") \
                .mode("overwrite") \
                .option('ignoreNullFields','false') \
                .option("path", target_path) \
                .save()

    except Exception as e:
        raise Exception(e)
    
    start_date+=timedelta(days=1)
