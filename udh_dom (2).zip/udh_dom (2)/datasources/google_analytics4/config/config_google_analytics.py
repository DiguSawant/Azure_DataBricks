# Databricks notebook source
import os
#env = os.getenv("env").lower()
env='dev'
u_env = env.upper()
path_prefix = f"/mnt/{env}/fwd_landing"

# COMMAND ----------

google_analytics_config={
'ga':{
"parentProject":"thai-project-292010",
"project":"thai-project-292010",
"tablename":"thai-project-292010.analytics_227136479.events_",
"numPartitions":15,
"target_table_name":f"{env}_ga4_bronze.google_analytics",
"target_path":f"{path_prefix}/bronze/ga4/TH.DEV.GBQ.GA4.GOOGLE_ANALYTICS" 
}
}

# COMMAND ----------

# assign the variables
config = google_analytics_config["ga"]
parentProject = config["parentProject"]
project=config["project"]
table = config["tablename"]
numPartitions = config["numPartitions"]
target_path = config["target_path"]
bronze_table = config["target_table_name"]

# COMMAND ----------

# Function to recursively find the latest file
def find_latest_file(folder):
    latest_file = None
    latest_time = 0

    # List files in the current folder
    file_list = dbutils.fs.ls(folder)

    file_list=[i for i in file_list if i.name !='_SUCCESS']

    for file in file_list:
        if file.isDir() :
            # Recursively search subfolders
            subfolder_path = file.path
            subfolder_latest_file = find_latest_file(subfolder_path)

            # Check if subfolder has a later file
            if subfolder_latest_file and subfolder_latest_file.modificationTime > latest_time :
                latest_file = subfolder_latest_file
                latest_time = subfolder_latest_file.modificationTime
        else:
            # Check if file is the latest
            if file.modificationTime > latest_time:
                latest_file = file
                latest_time = file.modificationTime

    return latest_file

# Find the latest file
latest_file = find_latest_file(target_path)