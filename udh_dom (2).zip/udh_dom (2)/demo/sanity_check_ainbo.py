# Databricks notebook source
# MAGIC %sql select * from dev_ainbo_gold.vw_campaign_ainbo_conversion