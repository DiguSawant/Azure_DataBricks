-- Databricks notebook source
select * from dev_cube_fna_silver.cls_product_rec_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.cls_product_rec_cube_fna_silver

-- COMMAND ----------

select * from dev_cube_fna_silver.cls_product_info_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.cls_product_info_cube_fna_silver

-- COMMAND ----------

select * from dev_cube_fna_silver.cls_lead_status_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.cls_lead_status_cube_fna_silver

-- COMMAND ----------

select * from dev_cube_fna_silver.cls_lead_agent_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.cls_lead_agent_cube_fna_silver

-- COMMAND ----------

select * from dev_cube_fna_silver.cls_lead_info_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.cls_lead_info_cube_fna_silver

-- COMMAND ----------

select * from dev_cube_fna_silver.iris_lead_cube_fna_silver

-- COMMAND ----------

select * from dev_silver.iris_lead_cube_fna_silver