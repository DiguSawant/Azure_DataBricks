# Databricks notebook source
# MAGIC %run  /Shared/udh_dom/nbo/notebook/aes

# COMMAND ----------

# MAGIC %sql select * from dev_silver.nbo_silver where ID='5499F011-1D56-415D-BE2B-E206A3B2ABB0'

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from 
# MAGIC       dev_silver.nosql_data_entity_silver where DATAVALUE_UTMTRACKING_UTMCONTENT='5499F011-1D56-415D-BE2B-E206A3B2ABB0'

# COMMAND ----------

# MAGIC %sql
# MAGIC select *
# MAGIC from 
# MAGIC       dev_ainbo_silver.nbm_vw as s
# MAGIC join  dev_silver.nosql_data_entity_silver as l
# MAGIC on
# MAGIC       upper(l.DATAVALUE_UTMTRACKING_UTMCONTENT) = upper(s.OFFER_KEY)
# MAGIC     and 
# MAGIC       l.DATAVALUE_POLICYNUMBER IS NOT NULL

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dev_ainbo_gold.vw_campaign_ainbo_conversion

# COMMAND ----------

# MAGIC %sql select * from dev_ainbo_silver.vw_campaign_ainbo_demographics

# COMMAND ----------

spark.sql(f"""
select *
from 
      dev_silver.nbo_silver as s
join  dev_silver.nosql_data_entity_silver as l
on
      upper(l.DATAVALUE_UTMTRACKING_UTMCONTENT) = upper(s.OFFER_KEY)
    and s.UDH_BATCH_ID='20230515'
""").display()

# COMMAND ----------

spark.sql(f"""
select *
from 
      dev_silver.nbo_silver as s
join  dev_silver.users_data_silver as l
on
      upper(l.JSON_DATA_OTHERS_UTMCONTENT) = upper(s.OFFER_KEY)
    and s.UDH_BATCH_ID='20230515'
""").display()

# COMMAND ----------

# MAGIC %sql select * from dev_silver.nosql_data_entity_silver where  DATAVALUE_UTMTRACKING_UTMCONTENT="0004439C-5D17-4816-A6E7-6F4A12492F08"

# COMMAND ----------

# %sql select * from dev_vnb.vnb_rates_silver where Product_ID in('WPK','WPFREE','WN90N','WN20N','WN20B','WN10N' ,'WD20A' ,'W05A' ,'RHEA' ,'RC1A' ,'PPO44' ,'PPO33' ,'PPO22' ,'PPO1' ,'OPD2' ,'HB2' ,'EC150R' ,'E159K1' ,'CIYRT5' ,'CIYRT4' ,'AI21' ,'AI11' ,'ADDP2' ,'ADDP1' ,'ADD1')


# COMMAND ----------

# %sql SELECT count(*)FROM sorDB_view s join la t on s.policy_id = t.policy_id;
# -- where policy_id in ("LA-D24245324" ,"LA-D01105216" ,"LA-D21678909" ,"LA-B00822631" ,"LA-D21621350" ,"LA-D21982477" ,"LA-D21252628" ,"LA-T03702991" ,"LA-D20544171","IL-40983127")

# COMMAND ----------

# MAGIC %sql select * from dev_silver.users_data_silver limit 5

# COMMAND ----------

# MAGIC %sql select * from dev_silver.nosql_data_entity_silver where dt_entityseq = '1036120'