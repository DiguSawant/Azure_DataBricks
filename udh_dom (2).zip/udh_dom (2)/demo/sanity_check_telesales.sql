-- Databricks notebook source
select * from dev_telesales_silver.leads_received

-- COMMAND ----------

select * from dev_telesales_silver.leads_passed_to_telesales

-- COMMAND ----------

select * from dev_telesales_silver.total_leads_passed_telesales

-- COMMAND ----------

select * from dev_telesales_silver.cust_sold_sum_ape_policy

-- COMMAND ----------

select * from dev_telesales_gold.vw_telesales_conversion