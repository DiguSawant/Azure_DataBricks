-- Databricks notebook source
select * from dev_cube_silver.product_rec_silver

-- COMMAND ----------

select * from dev_silver.product_rec_silver

-- COMMAND ----------

select * from dev_cube_silver.product_info_silver

-- COMMAND ----------

select * from dev_silver.product_info_silver

-- COMMAND ----------

select * from dev_cube_silver.lead_status_silver

-- COMMAND ----------

select * from dev_silver.lead_status_silver

-- COMMAND ----------

select * from dev_cube_silver.lead_agent_silver

-- COMMAND ----------

select * from dev_silver.lead_agent_silver

-- COMMAND ----------

select * from dev_silver.lead_info_silver

-- COMMAND ----------

select * from dev_cube_silver.lead_info_silver

-- COMMAND ----------

select * from dev_silver.lead_info_silver

-- COMMAND ----------

select * from dev_cube_silver.lead_silver

-- COMMAND ----------

select * from dev_silver.lead_silver