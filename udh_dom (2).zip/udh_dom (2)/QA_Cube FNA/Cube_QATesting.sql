-- Databricks notebook source
select count(DISTINCT JSONVALUE_AGENTCODE) from dev_silver.iris_lead_cube_fna_silver

-- COMMAND ----------

SELECT COUNT (DISTINCT JSONVALUE_AGENTCODE) FROM dev_silver. lead_silver 

-- COMMAND ----------

Select created_time,LEVEL,count (DISTINCT JSONVALUE_AGENTCODE) from dev_cube_silver.agent_mvp_silver 
group by CREATED_TIME,LEVEL having CREATED_TIME='02/03/2023'

-- COMMAND ----------

SELECT * FROM dev_silver.iris_lead_cube_fna_silver where JSONVALUE_ID =10257

-- COMMAND ----------

desc

-- COMMAND ----------

select count(distinct JSONVALUE_LEADSTATUSCODE) FROM dev_silver.iris_lead_cube_fna_silver where JSONVALUE_LEADSTATUSCODE='s'

-- COMMAND ----------

select count(distinct JSONVALUE_LEADSTATUSCODE) FROM dev_silver.iris_lead_cube_fna_silver where JSONVALUE_LEADSTATUSCODE='s'

-- COMMAND ----------

select count(distinct JSONVALUE_LEADSTATUSCODE) from dev_cube_silver.leads_mvp_silver where JSONVALUE_LEADSTATUSCODE ='S'

-- COMMAND ----------

--%sql select level, sum(count) from dev_cube_gold. vw_cube_fna_mvp group by LEVEL 
select level, sum(count) from dev_cube_gold.vw_cube_fna_mvp group by LEVEL
having level IN ('JUVENILE','ADULT')

-- COMMAND ----------

select count(distinct JSONVALUE_ID) FROM dev_silver.iris_lead_cube_fna_silver where JSONVALUE_STATUS='A'

-- COMMAND ----------

select count(distinct JSONVALUE_ID) from dev_cube_silver.leads_mvp_silver


-- COMMAND ----------

select count (distinct JSONVALUE_ID) FROM dev_silver.iris_lead_cube_fna_silver WHERE JSONVALUE_STATUS='A'

-- COMMAND ----------

-- MAGIC %sql select * from dev_mvp_silver.leads_silver

-- COMMAND ----------

-- MAGIC %sql select Created_time,"LEADS" as Schema, Level, count(Level) as Count
-- MAGIC from dev_mvp_silver.leads_silver
-- MAGIC where Level is not null
-- MAGIC group by 1,2,3

-- COMMAND ----------

-- MAGIC %sql select COUNT(JSONVALUE_ID) from dev_silver.lead_silver where JSONVALUE_STATUS ='A'
-- MAGIC

-- COMMAND ----------

-- MAGIC %sql select * from dev_mvp_gold.vw_cube_fna_mvp_source WHERE SCHEMA='LEADS'